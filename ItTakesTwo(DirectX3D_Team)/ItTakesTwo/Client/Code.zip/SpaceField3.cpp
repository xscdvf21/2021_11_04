#include "stdafx.h"
#include "SpaceField3.h"
#include "Export_Function.h"
#include "UI.h"
#include "Cody.h"
#include "May.h"
#include "CodyCamera.h"
#include "MayCamera.h"
#include "StaticObject.h"
#include "SpaceField3.h"
#include "Map.h"
#include "SceneChangeSpace.h"
#include "DeadSpace.h"
#include "Cody_Space.h"
#include "May_Space.h"
#include "GeneratorBattery.h"
#include "SpaceTube.h"
#include "Player.h"
#include "SpaceSpringBoardSpring.h"


CSpaceField3::CSpaceField3(LPDIRECT3DDEVICE9 pDevice)
	: CScene(pDevice)
{
}

CSpaceField3::~CSpaceField3()
{
}

HRESULT CSpaceField3::Ready_Scene()
{
	Engine::Set_SoundScene(RESOURCE_SF);

	Engine::Start_Split();
	g_bMenu = false;
	g_bSlideFinal = false;
	auto* pPhysics = Engine::Get_Physics();
	auto* pDispatcher = Engine::Get_Dispatcher();
	auto* pCudaMgr = Engine::Get_CudaMgr();
	CScene::Ready_PhysX(this, pPhysics, pDispatcher, pCudaMgr);


	if (!m_pScene)
		return E_FAIL;

	//pPlane->setGlobalPose(PxTransform(0, 0.f, 0));

	//auto* pPlane = PxCreatePlane(*pPhysics, PxPlane(0, 1, 0, 1), *pPhysics->createMaterial(0.5f, 0.5f, 0.f));

	//pPlane->setName((char*)pPlane);
	//setupFiltering(Engine::Get_Allocator(), pPlane, FilterGroup::eGround, FilterGroup::eCody | FilterGroup::eMay);
	//m_pScene->addActor(*pPlane);
	m_pScene->setGravity(PxVec3(0.0f, -20.f, 0.0f));
	FAILED_CHECK_RETURN(Ready_Environment_Layer(L"Environment"), E_FAIL);
	FAILED_CHECK_RETURN(Ready_GameObject_Layer(L"GameObject"), E_FAIL);
	FAILED_CHECK_RETURN(Ready_Interact_Layer(L"Interact"), E_FAIL);

	//FAILED_CHECK_RETURN(Ready_LoadMap_Layer(L"LoadObject", L"../../Data/ITT_Test/Test.dat"), E_FAIL);

	if (!Engine::Is_LightExsist())
		Ready_LightInfo();


	return S_OK;
}

_int CSpaceField3::Update_Scene(const _float & fTimeDelta)
{
	if (m_bStart)
	{
		
		m_bStart = false;
	}

	m_pScene->simulate(fTimeDelta);

	m_pScene->fetchResults(true);
	_int iExit = Engine::CScene::Update_Scene(fTimeDelta);



	if (Engine::Key_Down(DIK_Y))
	{

		CHANGE_SCENE(m_pGraphicDev, SCENE_SB, OBJ_NOEVENT);
		return 0;
	}
	return iExit;
}

_int CSpaceField3::LateUpdate_Scene(const _float & fTimeDelta)
{
	_int iExit = Engine::CScene::LateUpdate_Scene(fTimeDelta);

	return iExit;
}

void CSpaceField3::Render_Scene()
{

}

void CSpaceField3::onConstraintBreak(PxConstraintInfo* constraints, PxU32 count)
{

	return;
}

void CSpaceField3::onWake(PxActor** actors, PxU32 count)
{
	OutputDebugString(L"����");
	return;
}

void CSpaceField3::onSleep(PxActor** actors, PxU32 count)
{
	OutputDebugString(L"���");

	return;
}

void CSpaceField3::onContact(const PxContactPairHeader& pairHeader, const PxContactPair* pairs, PxU32 nbPairs)
{
	OutputDebugString(L"�浹����\n");
	for (PxU32 i = 0; i < nbPairs; ++i)
	{

		/*if ((!strcmp(pairHeader.actors[0]->getName(), "Cody") && !strcmp(pairHeader.actors[1]->getName(), "Wall")) ||
			(!strcmp(pairHeader.actors[1]->getName(), "Cody") && !strcmp(pairHeader.actors[0]->getName(), "Wall")))
		{
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Set_Climbing(true);
		}*/

	}
}

void CSpaceField3::onTrigger(PxTriggerPair* pairs, PxU32 count)
{
	for (PxU32 i = 0; i < count; ++i)
	{
		if (pairs[i].triggerShape->getSimulationFilterData().word0 == FilterGroup::eWall &&
			pairs[i].otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
		{
			pairs[i].triggerActor->getGlobalPose();
			CCody* pCody = (CCody*)Engine::Get_GameObject(L"GameObject", L"Cody");
		}
		auto Trigger = pairs[i];
		if (Trigger.otherShape->getSimulationFilterData().word0 &(FilterGroup::eCody | FilterGroup::eMay))
		{
			auto* pTrigger = ToTrigger(Trigger.triggerShape->getName());

			if (Trigger.status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
				pTrigger->Set_Active(true);
			else if (Trigger.status == PxPairFlag::eNOTIFY_TOUCH_LOST)
				pTrigger->Set_Active(false);


			if (!pTrigger)
				return;
			switch (pTrigger->Get_Type())
			{
			case TRIGGER_SCENE_CHANGE:
				Event_Scene_Change(&Trigger);
				break;
			case TRIGGER_SPACE_TUBE:
				Event_Tube(&Trigger);
				break;
			case TRIGGER_SPACE_GENERATOR_BATTERY:
				Event_Generator_Battery(&Trigger);
				break;
			default:
				break;
			}


		}
	}
}

void CSpaceField3::onAdvance(const PxRigidBody*const* bodyBuffer, const PxTransform* poseBuffer, const PxU32 count)
{
	OutputDebugString(L"������Ʈ");
}


void CSpaceField3::Event_Scene_Change(PxTriggerPair* pairs)
{
	//ToTrigger(pairs->triggerActor->getName())->Activate();
}

void CSpaceField3::Event_Tube(PxTriggerPair * pairs)
{
	CSpaceTube* pTube = ToTrigger(pairs->triggerShape->getActor()->getName())->Is<CSpaceTube>();
	if (nullptr == pTube)
		return;

	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	{
		if (pairs->otherShape->getSimulationFilterData().word0 & FilterGroup::eMay)
		{
			OutputDebugString(L"Ʃ�� ���� \n");
			auto* pMay = (CMay*)Engine::Get_GameObject(L"GameObject", L"May")->Is<CMay>();
			pMay->Set_TubeJumping();
			pTube->Set_SizeChange();

		}
		else if (pairs->otherShape->getSimulationFilterData().word0 & FilterGroup::eCody)
		{
			OutputDebugString(L"Ʃ�� ���� \n");
			auto* pCody = (CCody*)Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>();
			pCody->Set_TubeJumping();
			pTube->Set_SizeChange();
		}
	}


}

void CSpaceField3::Event_Generator_Battery(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());
	CGeneratorBattery*		pBattery = pTrigger->Is<CGeneratorBattery>();

	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		CCody_Space* pCody = ToObj<CCody_Space>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pCody, );

		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
		{
			OutputDebugString(L"�ڵ� ���͸��� ���� �� ����");
			pCody->Set_Push(true, pBattery, pBattery->Get_Push_StartPos(), CCody_Space::GENERATOR_BATTERY);
		}
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
		{
			pCody->Set_Push(false);
		}
	}
}


void CSpaceField3::Event_Bounce_Switch(PxTriggerPair* pairs)
{

}



void CSpaceField3::Event_Float(PxTriggerPair* pairs)
{
	//CFan* pFan = ToTrigger(pairs->triggerShape->getActor()->getName())->Is<CFan>();
	//_float3 vPos = ToTrigger(pairs->triggerShape->getActor()->getName())->Get_Pos();
	//NULL_CHECK_RETURN(pFan, );

	//if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	//{
	//	CCody* pCody = ToObj<CCody>(pairs->otherShape->getName());
	//	NULL_CHECK_RETURN(pCody, );

	//	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	//		pCody->Set_Float(true, pFan->Get_Up(), pFan, vPos, 20.f);

	//	else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
	//		pCody->Set_Float(false, pFan->Get_Up(), nullptr, vPos);
	//}
	//else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	//{
	//	CMay* pMay = (CMay*)Engine::Get_GameObject(L"GameObject", L"May");
	//	NULL_CHECK_RETURN(pMay, );

	//	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	//		pMay->Set_Float(true, pFan->Get_Up(), pFan, vPos, 20.f);

	//	else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
	//		pMay->Set_Float(false, pFan->Get_Up(), nullptr, vPos);
	//}
}

void CSpaceField3::Event_Dead(PxTriggerPair * pairs)
{
	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		CCody* pCody = ToObj<CCody>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pCody, );

		pCody->Set_PlayerDead();
	}
	else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	{
		CMay* pMay = ToObj<CMay>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pMay, );
		pMay->Set_PlayerDead();
	}
}

HRESULT CSpaceField3::Ready_Environment_Layer(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;

	OBJINFO tInfo;
	_int iX = 0, iY = 0, iZ = 0, iScale = 0;


	m_mapLayer.emplace(pLayerTag, pLayer);
	return S_OK;
}
//#��������	�����̽� �ʵ�3
HRESULT CSpaceField3::Ready_GameObject_Layer(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_SF3;
	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;
	tObj.vScale = { 0.01f, 0.01f ,0.01f };

	// CodyCamera
	pGameObject = CCodyCamera::Create(m_pGraphicDev, &_vec3(0.f, 10.f, -5.f), &_vec3(0.f, 0.f, 1.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"CodyCamera", pGameObject, this), E_FAIL);

	// MayCamera
	pGameObject = CMayCamera::Create(m_pGraphicDev, &_vec3(0.f, 10.f, -5.f), &_vec3(0.f, 0.f, 1.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MayCamera", pGameObject, this), E_FAIL);
	//780.886, 10794.9, 2694.33
	tObj.vPos = { 97.97f,22.59f,37.8f };//��������
	tObj.vPos = { 7.8f,26.9f,107.19f };//��ó��
	tObj.vPos = { 0.f,5.f,0.f };
	tObj.vPos = { 161.6f ,25.f, -17.f }; //���׷����� 1��.
	tObj.vPos = { 170.f ,40.f, -165.f }; //���׷����� 2��.
	tObj.vPos = { 147.31f,2.f,14.15f }; //������

	pGameObject = CCody_Space::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Cody", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eCody, FilterGroup::eGround | FilterGroup::eWall);


	pGameObject = CMay_Space::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"May", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eMay, FilterGroup::eGround | FilterGroup::eWall);

	//������
	tObj.vPos = { 147.31f,-2.f,14.15f };
	tObj.vAngle = { 0.f,90.f,0.f };
	tObj.vScale = { 0.01f, 0.01f ,0.01f };
	pGameObject = CSpaceSpringBoardSpring::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceSpring", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eRideObj, FilterGroup::eCody | FilterGroup::eMay);

	//�ü�


	//�����ڽ� 

	//��ư����

	//Ʃ��
	tObj.vScale = _vec3{ 0.01f,0.01f,0.01f };
	tObj.vAngle = { 0.f, 0.f, 0.f };
	tObj.vPos = { 42.f ,-3.f, 2.f };

	pGameObject = CSpaceTube::Create(m_pGraphicDev, &tObj, TubeColor_Blue);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"TubeColor_Blue", pGameObject, this), E_FAIL);

	tObj.vPos = { 52.f ,-1.f, 6.f };
	pGameObject = CSpaceTube::Create(m_pGraphicDev, &tObj, TubeColor_Orange);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"TubeColor_Orange", pGameObject, this), E_FAIL);

	tObj.vPos = { 50.f ,-2.f, -2.f };
	pGameObject = CSpaceTube::Create(m_pGraphicDev, &tObj, TubeColor_Purple);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"TubeColor_Purple", pGameObject, this), E_FAIL);

	tObj.vPos = { 62.f , 0.f, -8.f };
	pGameObject = CSpaceTube::Create(m_pGraphicDev, &tObj, TubeColor_Blue);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"TubeColor_Blue2", pGameObject, this), E_FAIL);

	tObj.vPos = { 62.f , 1.f, 10.f };
	pGameObject = CSpaceTube::Create(m_pGraphicDev, &tObj, TubeColor_Purple);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"TubeColor_Purple2", pGameObject, this), E_FAIL);

	tObj.vPos = { 72.f ,-3.f, 6.f };
	pGameObject = CSpaceTube::Create(m_pGraphicDev, &tObj, TubeColor_Blue);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"TubeColor_Blue3", pGameObject, this), E_FAIL);


	tObj.vPos = { 72.f ,-3.f, -2.f };
	pGameObject = CSpaceTube::Create(m_pGraphicDev, &tObj, TubeColor_Orange);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"TubeColor_Orange2", pGameObject, this), E_FAIL);


	//���׷����� ���͸� ù��°.
	tObj.vScale = _vec3{ 0.01f,0.01f,0.01f };
	tObj.vAngle = { 0.f, 20.f, 0.f };
	tObj.vTriggerScale = { 0.3f, 0.3f, 0.2f };
	tObj.vPos = { 159.55f ,19.05f, -16.05f };
	_vec3 TriggerPos = tObj.vPos + _vec3(-0.2f, -0.115f, -0.75f);
	_vec3 StartPos = tObj.vPos + _vec3(-0.45f, -0.14f, -0.756f);
	pGameObject = CGeneratorBattery::Create(m_pGraphicDev, &tObj, TriggerPos, StartPos);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"GeneratorBattery", pGameObject, this), E_FAIL);

	tObj.vScale = _vec3{ 0.01f,0.01f,0.01f };
	tObj.vAngle = { 0, 0.f, 0.f};

	tObj.eMeshType = 1;
	tObj.eRenderType = RENDER_NONALPHA;
	tObj.vPos = { 0.f,0.f,0.f };

	lstrcpy(tObj.tagMesh, L"Area1_Platform");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area1_Generator");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field2", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area1_Gravity");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field3", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area1_GravityCorner");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field4", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area1_Window");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field5", pGameObject, this), E_FAIL);


	lstrcpy(tObj.tagMesh, L"Area2_Platform");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field6", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area2_Generator");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field7", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area2_Gravity");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field8", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area2_GravityCorner");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field9", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Area2_Alpha");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field10", pGameObject, this), E_FAIL);

	m_mapLayer.emplace(pLayerTag, pLayer);


	return S_OK;
}

HRESULT CSpaceField3::Ready_LightInfo(void)
{
	D3DLIGHT9				tLightInfo;
	ZeroMemory(&tLightInfo, sizeof(D3DLIGHT9));

	tLightInfo.Type = D3DLIGHT_DIRECTIONAL;
	tLightInfo.Diffuse = D3DXCOLOR(1.f, 1.f, 1.f, 1.f);
	tLightInfo.Specular = D3DXCOLOR(1.f, 1.f, 1.f, 1.f);
	tLightInfo.Ambient = D3DXCOLOR(0.3f, 0.3f, 0.3f, 1.f);
	tLightInfo.Direction = _vec3(-1.f, -1.f, 1.f);

	FAILED_CHECK_RETURN(Engine::Ready_Light(m_pGraphicDev, &tLightInfo, 0), E_FAIL);

	return S_OK;
}

CSpaceField3 * CSpaceField3::Create(LPDIRECT3DDEVICE9 pGraphicDev)
{
	CSpaceField3*		pInstance = new CSpaceField3(pGraphicDev);

	if (FAILED(pInstance->Ready_Scene()))
		Safe_Release(pInstance);

	return pInstance;
}

void CSpaceField3::Free(void)
{
	// ����

	for (_uint i = 0; i < m_vecObject.size(); ++i)
		Safe_Delete_Array(m_vecObject[i]);

	m_vecObject.clear();
	m_vecObject.shrink_to_fit();
	Engine::Delete_AllResource(RESOURCE_SF3);
	Engine::CScene::Free();
}


HRESULT CSpaceField3::Ready_Interact_Layer(const _tchar* szLayer)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_SF3;
	// ������Ʈ �߰�
	tObj.vPos = {0.f,0.f ,0.f };
	tObj.vScale = { 0.01f,0.01f ,0.01f };
	Engine::CGameObject*		pGameObject = nullptr;
	Engine::CGameObject*		pButton = nullptr;
	
	//pGameObject = CMiniVacuum::Create(m_pGraphicDev, DIRRIGHT, &tObj);
	//NULL_CHECK_RETURN(pGameObject, E_FAIL);
	//FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Minivacuum", pGameObject, this), E_FAIL);
	
	//pButton = CPowerButton::Create(m_pGraphicDev, &tObj);
	//NULL_CHECK_RETURN(pButton, E_FAIL);
	//FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"PowerButton1", pButton, this), E_FAIL);
	//pButton->Set_InteractObj(pGameObject);


	m_mapLayer.emplace(szLayer, pLayer);

	return S_OK;
}
