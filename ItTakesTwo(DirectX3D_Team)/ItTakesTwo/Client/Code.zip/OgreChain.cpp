#include "stdafx.h"
#include "OgreChain.h"

#include "Export_Function.h"

COgreChain::COgreChain(LPDIRECT3DDEVICE9 pGraphicDev)
	:CGameObject(pGraphicDev)
	, m_bMoveStart(false),m_iAniIndex(0)
	, m_bOgreCol(false)
{
}

COgreChain::~COgreChain()
{
}

HRESULT COgreChain::Ready_Object(void * pArg)
{
	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);

	OBJINFO tTemp;
	ZeroMemory(&tTemp, sizeof(OBJINFO));

	if (nullptr != pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	m_pTransformCom->Set_Scale(tTemp.vScale);
	//m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(35.f));
	m_pTransformCom->Set_Pos(tTemp.vPos);

	return S_OK;
}

_int COgreChain::Update_Object(const _float & fTimeDelta)
{
	if (m_bOgreCol && !m_bMoveStart)
		Move(fTimeDelta);

	Engine::CGameObject::Update_Object(fTimeDelta);
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	return OBJ_NOEVENT;
}

_int COgreChain::LateUpdate_Object(const _float & fTimeDelta)
{
	return _int();
}

void COgreChain::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes_VTF(pEffect,0);

	pEffect->End();

	Safe_Release(pEffect);
}

void COgreChain::Set_Sound()
{
}

HRESULT COgreChain::Add_Component(void * pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO tTemp;
	if (pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	pComponent = m_pMeshCom = static_cast<Engine::CDynamicMesh*>(Engine::Clone_Resource(tTemp.eSceneID, L"OgreChain"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = static_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = static_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_fColDis, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_VTF"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);


	m_pTransformCom->Set_Scale(tTemp.vScale);
	m_pTransformCom->Rotation(ROT_X, D3DXToRadian(tTemp.vAngle.x));
	m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(tTemp.vAngle.y));
	m_pTransformCom->Rotation(ROT_Z, D3DXToRadian(tTemp.vAngle.z));
	m_pTransformCom->Set_Pos(tTemp.vPos);

	auto* pPhysics = Engine::Get_Physics();
	_vec3 vPos = m_pTransformCom->Get_Position();

	PxTransform tTransform(vPos.x, vPos.y, vPos.z);

	PxMaterial* pMaterial = pPhysics->createMaterial(0.5f, 0.5f, 0.0f);

	PxShape* pTrigger = pPhysics->createShape(PxBoxGeometry(1, 1, 1), *pMaterial, true);

	pTrigger->setFlag(PxShapeFlag::eSIMULATION_SHAPE, false);
	pTrigger->setFlag(PxShapeFlag::eTRIGGER_SHAPE, true);
	pTrigger->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);;

	m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pTrigger, 1);

	auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	pBody->setRigidBodyFlag(PxRigidBodyFlag::eKINEMATIC, false);
	// �׷���Ƽ�� ����.
	pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, true);
	// ��������
	pBody->setMass(0);
	//�̵� ������
	pBody->setName((char*)this);

	PxTransform Transform = pBody->getGlobalPose();

	PxQuat pxQ = Transform.q;

	PxTransform TriggerTransform(0, 0, 0);

	pTrigger->setLocalPose(TriggerTransform);

	return S_OK;
}

HRESULT COgreChain::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{

	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);

	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	pEffect->SetVector("g_vColor", &_vec4(255.f, 255.f, 255.f, 255.f));
	pEffect->SetFloat("g_fAmount", 0.f);
	pEffect->CommitChanges();

	return S_OK;
}

void COgreChain::Move(const _float & fTimeDelta)
{

	//_vec3 vPos;
	//vPos = m_pTransformCom->Get_Position();

	//PxTransform pxTransform = m_pRigidActor->getGlobalPose();
	//pxTransform.p.x = vPos.x;
	//pxTransform.p.y = vPos.y;
	//pxTransform.p.z = vPos.z;
	//_vec3 vRot = m_pTransformCom->Get_Angle();
	//pxTransform.q = PxQuat(vRot.x, { 1.f,0.f,0.f })*PxQuat(vRot.y, { 0.f,1.f,0.f })*PxQuat(vRot.z, { 0.f,0.f,1.f });
	//m_pRigidActor->setGlobalPose(pxTransform);


	m_iAniIndex = m_pMeshCom->Get_AniIndex();
	m_pMeshCom->Set_Animationset(animID::ToyChain_Break);
	m_pMeshCom->Play_Animationset(fTimeDelta);
	if (!m_bSound[Sound_break])
	{
		StopSound(CSoundMgr::CHANNELID::OgreChain);
		PlaySoundW(L"Ogre_ChainBreak.wav", CSoundMgr::CHANNELID::OgreChain, 0.2f);
		m_bSound[Sound_break] = true;
	}
	if (m_iAniIndex == animID::ToyChain_Break && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_bMoveStart = true;
	}
}

COgreChain * COgreChain::Create(LPDIRECT3DDEVICE9 pGraphicDev, void * pArg)
{
	COgreChain*	pInstance = new COgreChain(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void COgreChain::Free(void)
{
	Engine::CGameObject::Free();
}
