#include "stdafx.h"
#include "IceBullet.h"
#include "CollisionMgr.h"
#include "MainCamera.h"

#include "Export_Function.h"


CIceBullet::CIceBullet(LPDIRECT3DDEVICE9 pGraphicDev)
	: CEnermy(pGraphicDev)
	, m_fScale(0.001f)
{
}

CIceBullet::~CIceBullet()
{
}

HRESULT CIceBullet::Ready_Object(_vec3 vPos, _vec3 vDir)
{
	m_fColDis = 0.8f;

	// �ݶ��̴�
	ZeroMemory(&m_tColInfo, sizeof(SPHERE_INFO));
	m_tColInfo.fRadius = m_fColDis;

	FAILED_CHECK_RETURN(Add_Component(), E_FAIL);

	m_pTransformCom->Set_Scale(_vec3(m_fScale, m_fScale, m_fScale));
	m_pTransformCom->Set_Pos(vPos);

	m_vDir = vDir;
	D3DXVec3Normalize(&m_vDir, &m_vDir); //Ȥ�� ���� �ѹ�������, ���ʿ� ���ڷ� ������ �븻������ ���ֱ��Ұ�.

	return S_OK;
}

_int CIceBullet::Update_Object(const _float & fTimeDelta)
{
	m_pTransformCom->Set_Scale(_vec3(m_fScale, m_fScale, m_fScale));

	
	m_fScale += 0.001f;
	if (m_fLifeTime > 2.f) // ����� ������Ÿ��  2�ʷ� �����ص�. ���߿� �÷��̾ ���浹�ϸ� ���������ؾ��ҵ�
	{
		m_bDead = true;
	}
	if (m_bDead)
		return OBJ_DEAD;

	
	if (m_fScale > 0.01f)
	{
		m_fLifeTime += fTimeDelta;
		m_pTransformCom->Move_Pos(&m_vDir, 5.f, fTimeDelta);
		m_fScale = 0.01f;
		CCollisionMgr::GetInstance()->Add_EnermyBulletList(this);
	}
	m_pTransformCom->Set_Scale(_vec3(m_fScale, m_fScale, m_fScale));

	Engine::CGameObject::Update_Object(fTimeDelta);

	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);
	
	return OBJ_NOEVENT;
}

_int CIceBullet::LateUpdate_Object(const _float & fTimeDelta)
{
	return _int();
}

void CIceBullet::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes(pEffect, 8);

	pEffect->End();

	Safe_Release(pEffect);

	CMainCamera* pCamera = (CMainCamera*)Engine::Get_GameObject(L"GameObject", L"MainCamera");
	pCamera->Update_View_Proj();

	//Spine2
	m_tColInfo.matWorld = *m_pTransformCom->Get_WorldMatrix();
	m_pColliderCom->Render_Collider(m_tColInfo.matWorld, false);
}

HRESULT CIceBullet::Add_Component()
{
	Engine::CComponent*		pComponent = nullptr;

	// CStaticMesh
	pComponent = m_pMeshCom = dynamic_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(RESOURCE_CF, L"ToyMage_Bullet"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = dynamic_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_fColDis, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = dynamic_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	return S_OK;
}

HRESULT CIceBullet::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	return S_OK;
}

void CIceBullet::Move(const _float & fTimeDelta)
{
}

CIceBullet * CIceBullet::Create(LPDIRECT3DDEVICE9 pGraphicDev, _vec3 vPos, _vec3 vDir)
{
	CIceBullet*	pInstance = new CIceBullet(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(vPos, vDir)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void CIceBullet::Free(void)
{
	CEnermy::Free();
}
