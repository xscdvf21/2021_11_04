#include "stdafx.h"
#include "TriggerView.h"
#include "BoundingBox.h"
#include "TestMove.h"

CTriggerView::CTriggerView(LPDIRECT3DDEVICE9 pGraphicDev)
	: Engine::CGameObject(pGraphicDev)
{
}


CTriggerView::~CTriggerView()
{
}

HRESULT CTriggerView::Ready_Object(TRIGGERTYPE eType, void * pArg)
{
#ifdef _DEBUG
	//CTestMove::GetInstance()->Set(L"CmeraTrigger1", true);
#endif // _DEBUG

	m_eTriggerType = eType;

	OBJINFO tTemp;
	if (pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}
	m_tObjInfo = tTemp;

	Engine::CComponent*		pComponent = nullptr;

	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

#ifdef _DEBUG

	// Collider
	pComponent = m_pBox = CBoundingBox::Create(m_pGraphicDev, tTemp.vTriggerScale * 2.0f, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);
	m_pBox->Set_Pos(tTemp.vTriggerPos);

#endif // _DEBUG

	return S_OK;
}

Engine::_int CTriggerView::Update_Object(const _float& fTimeDelta)
{
#ifdef _DEBUG
	//CTestMove::GetInstance()->MoveTrigger(m_pBox, fTimeDelta, L"CmeraTrigger1");
#endif // _DEBUG

	if (m_bStart)
	{
		m_pTrigger = CTrigger::CreateBoxTrigger(m_pScene, this, m_tObjInfo.vTriggerPos, m_tObjInfo.vTriggerScale.x, m_tObjInfo.vTriggerScale.y, m_tObjInfo.vTriggerScale.z, m_eTriggerType);
		m_pTrigger->Set_Rotation(m_tObjInfo.vTriggerAngle);
		m_bStart = false;
	}

	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);
	return 0;
}

Engine::_int CTriggerView::LateUpdate_Object(const _float & fTimeDelta)
{
	return 0;
}

void CTriggerView::Render_Object(const _int& iIndex /*= 0*/)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);

#ifdef _DEBUG
	m_pBox->Render_Collider(g_bRenderBox, pEffect);
#endif // _DEBUG
}

CGameObject * CTriggerView::Create(LPDIRECT3DDEVICE9 pGraphicDev ,TRIGGERTYPE eType, void * pArg)
{
	CTriggerView* pInstance = new CTriggerView(pGraphicDev);
	if (FAILED(pInstance->Ready_Object(eType, pArg)))
	{
		Safe_Release(pInstance);
	}
	return pInstance;
}

void CTriggerView::Free()
{
	Engine::CGameObject::Free();
}
