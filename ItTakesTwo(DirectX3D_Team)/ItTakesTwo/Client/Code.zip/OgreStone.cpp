#include "stdafx.h"
#include "OgreStone.h"
#include "Export_Function.h"


COgreStone::COgreStone(LPDIRECT3DDEVICE9 pGraphicDev)
	:CGameObject(pGraphicDev)
{
}

COgreStone::~COgreStone()
{
}

HRESULT COgreStone::Ready_Object(void* pArg, _vec3 vRot)
{
	FAILED_CHECK_RETURN(Add_Component(pArg),E_FAIL);

	OBJINFO tTemp;
	if (pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	m_vRot = vRot;
	return S_OK;
}

_int COgreStone::Update_Object(const _float & fTimeDelta)
{
	if (m_bStart)
	{
		m_pTrigger = CTrigger::CreateSphereTirgger(m_pScene, this, m_pTransformCom->Get_Position(), 2.f, TRIGGER_CHESS_OGRE_STONE, FilterGroup::eDefaultTrigger);
		m_bStart = false;
	}

	_vec3 vPos;
	vPos = m_pTransformCom->Get_Position();
	m_pTrigger->Set_Pos(m_pTransformCom->Get_Position());

	if (m_bDead)
	{
		//StopSound(CSoundMgr::CHANNELID::MonsterEffect);
		PlaySoundW(L"OgreStone.wav", CSoundMgr::CHANNELID::OgreStone, 0.3f);
		
		m_pTrigger->Set_Interactable(false);

		return OBJ_DEAD;
	}
	Engine::CGameObject::Update_Object(fTimeDelta);

	Move(fTimeDelta);

	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	return OBJ_NOEVENT;
}

_int COgreStone::LateUpdate_Object(const _float & fTimeDelta)
{
	return _int();
}

void COgreStone::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes(pEffect, 8);

	pEffect->End();

	Safe_Release(pEffect);

}

HRESULT COgreStone::Add_Component(void* pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO tTemp;
	if (pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	// CStaticMesh
	pComponent = m_pMeshCom = dynamic_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(tTemp.eSceneID, L"OgreStone"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = dynamic_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_fColDis, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = dynamic_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);


	m_pTransformCom->Set_Scale(tTemp.vScale);
	m_pTransformCom->Rotation(ROT_X, D3DXToRadian(tTemp.vAngle.x));
	m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(tTemp.vAngle.y));
	m_pTransformCom->Rotation(ROT_Z, D3DXToRadian(tTemp.vAngle.z));
	m_pTransformCom->Set_Pos(tTemp.vPos);

	return S_OK;
}

HRESULT COgreStone::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	return S_OK;
}

void COgreStone::Move(const _float & fTimeDelta)
{
	m_pTransformCom->Move_Pos(&_vec3(0.f, 1.f, 0.f), -8.f, fTimeDelta);
	m_pTransformCom->Rotation(ROT_X, D3DXToRadian(m_vRot.x));
	m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(m_vRot.y));
	m_pTransformCom->Rotation(ROT_Z, D3DXToRadian(m_vRot.z));

	if (m_pTransformCom->Get_Position().y <= 0.f)
	{
		m_bDead = true;
	}

}

COgreStone * COgreStone::Create(LPDIRECT3DDEVICE9 pGraphicDev, void* pArg, _vec3 vRot)
{
	COgreStone*	pInstance = new COgreStone(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg,vRot)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void COgreStone::Free(void)
{
	Engine::CGameObject::Free();
}
