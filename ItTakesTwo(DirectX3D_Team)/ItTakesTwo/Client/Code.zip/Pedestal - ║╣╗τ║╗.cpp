#include "stdafx.h"
#include "Pedestal.h"
#include "Export_Function.h"
#include "MainCamera.h"
#include "PhysXMesh.h"
#include "BoundingBox.h"
#include "TestMove.h"


CPedestal::CPedestal(LPDIRECT3DDEVICE9 pGraphicDev)
	: Engine::CGameObject(pGraphicDev)
{

}

CPedestal::~CPedestal(void)
{
}

HRESULT CPedestal::Ready_Object(void* pArg)
{
#ifdef _DEBUG
	//CTestMove::GetInstance()->Set(L"CircleSaw", true);
#endif// _DEBUG
	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);

	OBJINFO Temp;
	if (pArg)
	{
		memcpy(&Temp, pArg, sizeof(OBJINFO));
	}
	m_tObjInfo = Temp;

	return S_OK;
}

Engine::_int CPedestal::Update_Object(const _float& fTimeDelta)
{
#ifdef _DEBUG
	//CTestMove::GetInstance()->MoveTrigger(m_pBox, fTimeDelta, L"CircleSaw");
#endif // _DEBUG

	if (m_bDead)
		return OBJ_DEAD;

	if (m_bStart)
	{
		m_pTrigger = CTrigger::CreateBoxTrigger(m_pScene, this, m_tObjInfo.vTriggerPos, m_tObjInfo.vTriggerScale.x, m_tObjInfo.vTriggerScale.y, m_tObjInfo.vTriggerScale.z, TRIGGERTYPE::TRIGGER_SAW_SLIDING);
		m_pTrigger->Set_Rotation(m_tObjInfo.vTriggerAngle);
		m_bStart = false;
	}

	//#�ٿ� �׽�Ʈ Ʈ���� ��ġ�̵�
	if (Engine::Key_Pressing(DIK_5))
	{
		if (!g_bTriggerTest)
			m_tObjInfo.vTriggerPos.x += 1.0f * fTimeDelta;
		else
			m_pBox->Add_ScaleX(0.1f);
	}
	else if (Engine::Key_Pressing(DIK_6))
	{
		if (!g_bTriggerTest)
			m_tObjInfo.vTriggerPos.x += -1.0f * fTimeDelta;
		else
			m_pBox->Add_ScaleX(-0.1f);
	}
	else if (Engine::Key_Pressing(DIK_7))
	{
		if (!g_bTriggerTest)
			m_tObjInfo.vTriggerPos.y += 1.0f * fTimeDelta;
		else
			m_pBox->Add_ScaleY(0.1f);
	}
	else if (Engine::Key_Pressing(DIK_8))
	{
		if (!g_bTriggerTest)
			m_tObjInfo.vTriggerPos.y += -1.0f * fTimeDelta;
		else
			m_pBox->Add_ScaleY(-0.1f);
	}
	else if (Engine::Key_Pressing(DIK_9))
	{
		if (!g_bTriggerTest)
			m_tObjInfo.vTriggerPos.z += 1.0f * fTimeDelta;
		else
			m_pBox->Add_ScaleZ(0.1f);
	}
	else if (Engine::Key_Pressing(DIK_0))
	{
		if (!g_bTriggerTest)
			m_tObjInfo.vTriggerPos.z += -1.0f * fTimeDelta;
		else
			m_pBox->Add_ScaleZ(-0.1f);
	}

	if (Engine::Key_Down(DIK_L))
	{
		g_bTriggerTest = !g_bTriggerTest;
	}

	CGameObject::Update_Object(fTimeDelta);
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);
	return OBJ_NOEVENT;
}

_int CPedestal::LateUpdate_Object(const _float & fTimeDelta)
{
	_matrix matWorld;
	m_pTransformCom->Get_WorldMatrix(&matWorld);
	PxTransform cTrans = m_pRigidActor->getGlobalPose();
	cTrans.p.x = matWorld._41;
	cTrans.p.y = matWorld._42;
	cTrans.p.z = matWorld._43;

	//PxTransform cTrans = m_pRigidActor->getGlobalPose();
	_vec3 vRot = m_pTransformCom->Get_Angle();

	auto* pBody = m_pRigidActor->is<PxRigidDynamic>();
	cTrans.q = PxQuat(vRot.y, { 0.f,1.f,0.f });
	pBody->setKinematicTarget(cTrans);
	return _int();
}

void CPedestal::Render_Object(const _int& iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes(pEffect, 8);

	pEffect->End();

#ifdef _DEBUG
	m_pBox->Render_Collider(g_bRenderBox, pEffect);
#endif // _DEBUG

	Safe_Release(pEffect);
}

CPedestal* CPedestal::Create(LPDIRECT3DDEVICE9 pGraphicDev, void* pArg)
{
	CPedestal*	pInstance = new CPedestal(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg)))
		Safe_Release(pInstance);

	return pInstance;
}

void CPedestal::Free(void)
{
	Engine::CGameObject::Free();
}

HRESULT CPedestal::Add_Component(void* pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO tTemp;
	ZeroMemory(&tTemp, sizeof(OBJINFO));
	if (nullptr != pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	//pComponent = m_pBox = 

	// CStaticMesh
	pComponent = m_pMeshCom = dynamic_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(tTemp.eSceneID, L"Pedestal"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);
	m_pTransformCom->Set_Scale(_float3(0.01f, 0.01f, 0.01f));
	m_pTransformCom->Set_Pos(tTemp.vPos);
	//m_pTransformCom->Set_AddAngleX(D3DXToRadian(-90.0f));
	//m_pTransformCom->Set_AddAngleY(D3DXToRadian(90.0f));

	// Shader
	pComponent = m_pShaderCom = dynamic_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

#ifdef _DEBUG

	// Collider
	pComponent = m_pBox = CBoundingBox::Create(m_pGraphicDev, tTemp.vTriggerScale * 2.0f, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);
	m_pBox->Set_Pos(tTemp.vTriggerPos);
	m_pBox->Set_Angle(tTemp.vTriggerAngle);

#endif // _DEBUG

	auto* pPhysics = Engine::Get_Physics();
	_vec3 vPos = m_pTransformCom->Get_Position();

	PxTransform tTransform(vPos.x, vPos.y, vPos.z, PxQuat(m_pTransformCom->Get_Angle().y, { 0.f,1.f,0.f }));
	PxMaterial* pMaterial = pPhysics->createMaterial(0.5f, 0.5f, 0.0f);
	PxTriangleMeshGeometry pMeshGeo;
	pMeshGeo.triangleMesh = m_pMeshCom->Get_PxMesh();
	_vec3 vScale = m_pTransformCom->Get_Scale();
	pMeshGeo.scale = PxMeshScale(PxVec3(vScale.x, vScale.y, vScale.z));

	PxShape* pShape = pPhysics->createShape(pMeshGeo, *pMaterial, true);

	pShape->setFlag(PxShapeFlag::eSIMULATION_SHAPE, false);
	pShape->setFlag(PxShapeFlag::eTRIGGER_SHAPE, false);
	pShape->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);

	m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pShape, 1);

	auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	// Ʈ�������� ������������ �������� �ʴ¾ֵ�
	pBody->setRigidBodyFlag(PxRigidBodyFlag::eKINEMATIC, true);
	//pBody->setKinematicTarget()
	// �׷���Ƽ�� ����.
	pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, true);
	// ��������
	pBody->setMass(0);
	//�̵� ������
	pBody->setName((char*)this);
	return S_OK;
}

HRESULT CPedestal::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	return S_OK;
}