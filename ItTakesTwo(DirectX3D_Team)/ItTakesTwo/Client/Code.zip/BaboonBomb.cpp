#include "stdafx.h"
#include "BaboonBomb.h"
#include "CollisionMgr.h"
#include "Export_Function.h"
CBaboonBomb::CBaboonBomb(LPDIRECT3DDEVICE9 pGraphicDev)
	:CEnermy(pGraphicDev)
	, m_bTram(false), m_bTramStart(true), m_fTramPower(0.f)
	, m_fTramTime(0.f), m_fTramHeight(0.f), m_fDuration(3.f)
	, m_bAnglecheck(false)
{
}

CBaboonBomb::~CBaboonBomb()
{
}

HRESULT CBaboonBomb::Ready_Object(void * pArg, CGameObject * pPlayer)
{
	m_tColInfo.fRadius = 1.f;
	
	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);


	if (nullptr != pPlayer)
	{
		m_pTarget = pPlayer;
		m_pTarget->AddRef();
	}

	
	PhyscisCreate();
	return S_OK;
}

_int CBaboonBomb::Update_Object(const _float & fTimeDelta)
{
	if (m_bDead)
	{
		return OBJ_DEAD;
	}

	_vec3 vPos;
	vPos = m_pTransformCom->Get_Position();

	PxTransform pxTransform = m_pRigidActor->getGlobalPose();
	pxTransform.p.x = vPos.x;
	pxTransform.p.y = vPos.y;
	pxTransform.p.z = vPos.z;

	m_pRigidActor->setGlobalPose(pxTransform);


	Move(fTimeDelta);

	CCollisionMgr::GetInstance()->Add_EnermyBulletList(this);

	Engine::CGameObject::Update_Object(fTimeDelta);
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	return OBJ_NOEVENT;
}

_int CBaboonBomb::LateUpdate_Object(const _float & fTimeDelta)
{
	return _int();
}

void CBaboonBomb::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes(pEffect, 8);

	pEffect->End();

	Safe_Release(pEffect);

	m_tColInfo.matWorld = *m_pTransformCom->Get_WorldMatrix();
	m_pColliderCom->Render_Collider(m_tColInfo.matWorld, false);
}

HRESULT CBaboonBomb::Add_Component(void * pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO tTemp;
	ZeroMemory(&tTemp, sizeof(OBJINFO));

	if (nullptr != pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	// CStaticMesh
	pComponent = m_pMeshCom = static_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(tTemp.eSceneID, L"VacuumDebris01"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = static_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = static_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_tColInfo.fRadius, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	m_pTransformCom->Set_Scale(tTemp.vScale);
	m_pTransformCom->Rotation(ROT_X, D3DXToRadian(tTemp.vAngle.x));
	m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(tTemp.vAngle.y));
	m_pTransformCom->Rotation(ROT_Z, D3DXToRadian(tTemp.vAngle.z));
	m_pTransformCom->Set_Pos(tTemp.vPos);

	return S_OK;
}

HRESULT CBaboonBomb::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	return S_OK;
}

void CBaboonBomb::Move(const _float & fTimeDelta)
{
	if (m_bTramStart)
	{
		CTransform*		pTarget = (CTransform*)m_pTarget->Get_Component(L"Com_Transform", ID_DYNAMIC);
		_vec3 vTargetPos = pTarget->Get_Position();
		m_vSetPos = pTarget->Get_Position();
		m_vTramDir = vTargetPos - m_pTransformCom->Get_Position();
		D3DXVec3Normalize(&m_vTramDir, &m_vTramDir);

		m_fTramPower = ((m_vTramDir.y + 1.f) - m_pTransformCom->Get_Position().y - (m_fDuration * m_fDuration) * -GRAVITY) / m_fDuration;

		m_vTramDis = vTargetPos - m_pTransformCom->Get_Position();
		m_vTramDis.y = 0.f;
		m_fTramHeight = m_pTransformCom->Get_Position().y;
		m_bTramStart = false;
	}

	m_fTramTime += fTimeDelta;

	_float fHeight = m_fTramHeight + ((m_fTramTime * m_fTramTime) * (-GRAVITY) / 1) + (m_fTramTime * m_fTramPower);
	_vec3 vDstPos = m_pTransformCom->Get_Position() + (m_vTramDir * D3DXVec3Length(&m_vTramDis) * fTimeDelta / m_fDuration);

	m_pTransformCom->Set_Pos(_vec3(vDstPos.x, fHeight, vDstPos.z));
}

void CBaboonBomb::PhyscisCreate()
{
	auto* pPhysics = Engine::Get_Physics();
	_vec3 vPos = m_pTransformCom->Get_Position();
	PxTransform tTransform(vPos.x, vPos.y, vPos.z);

	PxMaterial* pMaterial = pPhysics->createMaterial(0.1f, 0.1f, 0.1f);

	PxShape* pShape = pPhysics->createShape(PxBoxGeometry(0.01f, 0.01f, 0.01f), *pMaterial, true);
	//�� �ΰ��� �ϳ��� false �Ѵ� true��?
	pShape->setFlag(PxShapeFlag::eSIMULATION_SHAPE, true);
	pShape->setFlag(PxShapeFlag::eTRIGGER_SHAPE, false);
	pShape->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);
	m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pShape, 1);

	auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	// Ʈ�������� ������������ �������� �ʴ¾ֵ�
	pBody->setRigidBodyFlag(PxRigidBodyFlag::eKINEMATIC, false);

	// �׷���Ƽ�� ����.

	pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, false);

	// ��������
	pBody->setMass(5);
	pBody->setName((char*)this);
	pShape->setName((char*)this);
	pBody->setRigidDynamicLockFlags(PxRigidDynamicLockFlag::eLOCK_ANGULAR_X | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z);
	//�̵� ������
	pBody->setLinearDamping(0.05f);
}

CBaboonBomb * CBaboonBomb::Create(LPDIRECT3DDEVICE9 pGraphicDev, void * pArg, CGameObject * pPlayer)
{
	CBaboonBomb*	pInstance = new CBaboonBomb(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg, pPlayer)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void CBaboonBomb::Free(void)
{
	m_pTarget->Release();
	CEnermy::Free();
}
