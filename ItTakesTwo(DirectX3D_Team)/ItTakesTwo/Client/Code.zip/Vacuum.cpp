#include "stdafx.h"
#include "Vacuum.h"
#include "VacuumBomb.h"
#include "VacuumCircle.h"
#include "VacuumMine.h"
#include "VacuumStone.h"
#include "VacuumFieldPart.h"
#include "VacuumFieldPart2.h"
#include "VacuumFieldPart3.h"
#include "VacuumFieldPart4.h"
#include "VacuumFieldPart5.h"
#include "CollisionMgr.h"
#include "Export_Function.h"
#include "BoundingBox.h"
#include "Cody.h"
#include "May.h"


//���� �� ���̸� Neck (������)
//LeftHandBottomLips1 //��Ŭ
//RightHandBottomLips1 // ��Ŭ
//RightHandJaw, LeftHandJaw (����) ���� 16 ���� 6(���ȴ� 3��) z�� ���� 24 ������ -24 �� 48 x�� +25 ~ -12 �׷��� �Ƹ� x���� +12 - 12 �������µ�. 
CVacuum::CVacuum(LPDIRECT3DDEVICE9 pGraphicDev)
	: CEnermy(pGraphicDev)
	, m_fMineX(0.f), m_fMineX2(9.f), m_fMineX3(18.f)
	, m_fMineX4(0.f), m_fMineX5(-9.f), m_fMineX6(-18.f)
	, m_fMineZ(-24.f)
	, m_fMineZ3(-21.f)
	, m_iStoneCount(0)
	, m_bStun(false), m_bStunFirst(false), m_bCreateTrigger(false)
	, m_bCodyRide(false), m_bMayRide(false)
	, m_bAniStop(false), m_fDelta(0.f)
{
}

CVacuum::~CVacuum()
{
}

HRESULT CVacuum::Ready_Object(void * pArg)
{
	m_iHP = 10;
	m_iHPMax = 10;
	FAILED_CHECK_RETURN(Add_Component(), E_FAIL);


	if (nullptr != pArg)
	{

	}

	m_vNextPos = { m_fMineX, 0.f, m_fMineZ };
	m_vNextPos2 = { m_fMineX2, 0.f, m_fMineZ };
	m_vNextPos3 = { m_fMineX3, 0.f, m_fMineZ3 };
	m_vNextPos4 = { m_fMineX4, 0.f, m_fMineZ };
	m_vNextPos5 = { m_fMineX5, 0.f, m_fMineZ };
	m_vNextPos6 = { m_fMineX6, 0.f, m_fMineZ3 };



	m_pMeshCom->Set_Animationset(0);
	Create_Bomb(pArg);

	return S_OK;
}

_int CVacuum::Update_Object(const _float & fTimeDelta)
{
	if (!m_bTrigger)
	{
		_vec3 vPos = m_pTransformCom->Get_Position();
		_vec3 vTriggerPos = { vPos.x, vPos.y + 10.f, vPos.z };

		m_pTrigger[TriggerID::Vacuum] = m_pTrigger[TriggerID::Vacuum] = CTrigger::CreateSphereTirgger(m_pScene, this, m_pTransformCom->Get_Position(), 7.f, TRIGGER_VACUUMBOSS_VACUUM, FilterGroup::eDefaultTrigger);
		m_pTrigger[TriggerID::Vacuum]->Set_Pos(vTriggerPos);

		m_bTrigger = true;
	}

	for (auto& iter = m_vecActiveBomb.begin();  iter != m_vecActiveBomb.end();)
	{
		if (OBJ_DEAD == (*iter)->Update_Object(fTimeDelta))
		{
			m_vecBomb.emplace_back(*iter);
			iter =m_vecActiveBomb.erase(iter);
			continue;
		}
		++iter;
	}

	m_fDelta = fTimeDelta;
	if (m_iAniIndex == animID::VacuumBoss_End_ArmsOverride_75 ||
		m_iAniIndex == animID::VacuumBoss_End_EyePoppedOut_Enter ||
		m_iAniIndex == animID::VacuumBoss_End_ArmsOverride_Preview)
	{
		m_fDelta = m_fDelta / 2;
	}
	if (m_iHP <= 0)
	{
		m_bStun = true;
	}

	if (m_bDead)
		return OBJ_DEAD;

	if (Engine::Key_Down(DIK_O))
	{
		m_iHP = 0;
		/*	m_bPartUp = true;*/

	}
	if (Engine::Key_Down(DIK_P))
	{
		m_bPartDown = true;
	}


	if (m_bDead)
		return OBJ_DEAD;

	if (m_bPartUp)
		PartUp(fTimeDelta);

	if (m_bPartDown)
		PartDown(fTimeDelta);



	Engine::CGameObject::Update_Object(fTimeDelta);


	if (!m_bStun)
		Move(fTimeDelta);
	else if (m_bStun)
		Stun(fTimeDelta);


	if (!m_bAniStop)
		m_pMeshCom->Play_Animationset(m_fDelta);

	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	return OBJ_NOEVENT;
}

_int CVacuum::LateUpdate_Object(const _float & fTimeDelta)
{
	for (auto& iter = m_vecActiveBomb.begin(); iter != m_vecActiveBomb.end();)
	{
		if (OBJ_DEAD == (*iter)->LateUpdate_Object(fTimeDelta))
		{
			m_vecBomb.emplace_back(*iter);
			iter = m_vecActiveBomb.erase(iter);
			continue;
		}
		++iter;
	}

	if (m_bStart)
	{
		Create_UI(L"VB_UI");
		m_bStart = false;
		return 0;
	}

	Update_UI(fTimeDelta);

	return _int();
}

void CVacuum::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes_VTF(pEffect, 0);

	pEffect->End();

	Safe_Release(pEffect);

}

void* CVacuum::On_Trigger_Active(void* pTrigger)
{
	Set_Damage(-1);
	return nullptr;
}

HRESULT CVacuum::Add_Component()
{
	Engine::CComponent*		pComponent = nullptr;

	// CDynamicMesh
	pComponent = m_pMeshCom = static_cast<Engine::CDynamicMesh*>(Engine::Clone_Resource(RESOURCE_VB, L"VacuumBoss"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = static_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);


	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_VTF"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);


	m_pTransformCom->Set_Scale(_vec3(0.01f, 0.01f, 0.01f));
	m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(-90.f));
	m_pTransformCom->Set_Pos(_vec3(30.f, 0.f, 0.f));

	return S_OK;
}

HRESULT CVacuum::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	pEffect->SetVector("g_vColor", &_vec4(255.f, 255.f, 255.f, 255.f));
	pEffect->CommitChanges();

	return S_OK;
}

void CVacuum::Move(const _float & fTimeDelta)
{
	m_iAniIndex = m_pMeshCom->Get_AniIndex();

	Engine::CTransform*		pMayTransformCom = static_cast<Engine::CTransform*>(Engine::Get_Component(L"GameObject", L"May", L"Com_Transform", Engine::ID_DYNAMIC));
	Engine::CTransform*		pCodyTransformCom = static_cast<Engine::CTransform*>(Engine::Get_Component(L"GameObject", L"Cody", L"Com_Transform", Engine::ID_DYNAMIC));
	if (!pMayTransformCom || !pCodyTransformCom)
		return;
	_vec3 vMayPos; //���� ��ġ
	_vec3 vCodyPos; //�ڵ� ��ġ
	_vec3 vPos; //���� ����(�ڽ�)	��ġ.
	_vec3 vLook; //���� ����(�ڽ�)	�����
	_vec3 vRight; //���� ����(�ڽ�) ����Ʈ
	_vec3 vLeft; //���� ����(�ڽ�) ����Ʈ

	m_pTransformCom->Get_Info(INFO_LOOK, &vLook);
	m_pTransformCom->Get_Info(INFO_RIGHT, &vRight);

	vMayPos = pMayTransformCom->Get_Position();
	vCodyPos = pCodyTransformCom->Get_Position();
	vPos = m_pTransformCom->Get_Position();

	_vec3 vMayDir;	//���̿��� �Ÿ�
	_vec3 vCodyDir; //�ڵ���� �Ÿ�

	_float fMayDir;
	_float fCodyDir;

	vMayDir = vMayPos - vPos;
	vCodyDir = vCodyPos - vPos;

	fMayDir = D3DXVec3Length(&vMayDir);
	fCodyDir = D3DXVec3Length(&vCodyDir);


	D3DXVec3Normalize(&vLook, &vLook);
	D3DXVec3Normalize(&vRight, &vRight);
	vLeft = vRight * -1.f;

	if (fMayDir < fCodyDir)
	{
		m_pTargetPlayer = static_cast<CGameObject*>(Engine::Get_GameObject(L"GameObject", L"May"));
	}
	else if (fCodyDir <= fMayDir)
	{
		m_pTargetPlayer = static_cast<CGameObject*>(Engine::Get_GameObject(L"GameObject", L"Cody"));
	}
	if (!m_pTargetPlayer)
		return;
	if (!m_bPattrunSelect)
	{
		m_pMeshCom->Set_Animationset(8);
		m_fPattrunDelta += fTimeDelta;
	}

	if (m_bPartPatturn && m_fPattrunDelta > 20.f)
		//if (m_bPartPatturn && m_fPattrunDelta > 13.f)
	{
		if (!m_bDownOne)
		{
			m_bPartDown = true;
			m_bDownOne = true;
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Force_Ride_Off();
			Engine::Get_GameObject(L"GameObject", L"May")->Is<CMay>()->Force_Ride_Off();
		}
	}
	if (m_bPartPatturn && m_fPattrunDelta > 27.f)
	{
		m_bBombCheck = false;
		m_iPatturnSelect = rand() % 5 + 1;
		m_fPattrunDelta = 0.f;
		m_bPartPatturn = false;
		m_bDownOne = false;
		m_bPattrunSelect = true;
	}

	if (!m_bPartPatturn && m_fPattrunDelta > 3.f)
	{
		m_bBombCheck = false;
		m_iPatturnSelect = rand() % 5 + 1;
		m_fPattrunDelta = 0.f;
		m_bPattrunSelect = true;
	}

	m_iPatturnSelect = 3;


	//if (!m_bPattrunSelect)
	//{
	//	m_bBombCheck = false;
	//	m_iPatturnSelect = rand() % 5 + 1;
	//	m_bPattrunSelect = true;
	//}

	if (m_bPattrunSelect)
	{
		//������
		if (m_iPatturnSelect == 1)
		{
			m_fStoneTime += fTimeDelta;

			m_bSound[Sound_Stone] = false;

			if (m_fStoneTime > 1.f)
			{
				if (!m_bSound[Sound_Stone])
				{
					Engine::StopSound(CSoundMgr::CHANNELID::Vacuum_Stone);
					Engine::PlaySoundW(L"Vacuum_StoneReady.wav", CSoundMgr::CHANNELID::Vacuum_Stone, 0.2f);

					m_bSound[Sound_Stone] = true;
				}


				CTransform*		pTargetTransCom = static_cast<CTransform*>(m_pTargetPlayer->Get_Component(L"Com_Transform", Engine::ID_DYNAMIC));

				_vec3 vTargetPos;
				vTargetPos = pTargetTransCom->Get_Position();
				m_pMeshCom->Set_Animationset(11);

				CLayer*				pLayer = nullptr;
				pLayer = Engine::Get_Layer(L"GameObject");
				Engine::CGameObject*		pGameObject = nullptr;

				const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("Neck");

				_matrix matBoneWorld, matWorld;
				matBoneWorld = pFrame->CombinedTranformationMatrix;
				matWorld = *(m_pTransformCom->Get_WorldMatrix());

				matWorld = matBoneWorld * matWorld;

				_tchar tagTemp[MAX_PATH];
				wsprintf(tagTemp, L"VacuumStone %d", m_iStoneCount);



				_float fX;
				_float fZ;
				_float fAngle;
				_float fScale;
				_float fRotX;
				_float fRotY;
				_float fRotZ;

				CRandoms CRandom;
				fX = CRandom(-5.f, 5.f);
				fZ = CRandom(-5.f, 5.f);
				fScale = CRandom(0.004f, 0.007f);
				fAngle = CRandom(0.f, 360.f);
				fRotX = CRandom(-1.f, 1.f);
				fRotY = CRandom(-1.f, 1.f);
				fRotZ = CRandom(-1.f, 1.f);

				OBJINFO tTemp;
				tTemp.vPos = { matWorld._41, matWorld._42, matWorld._43 };
				tTemp.vScale = { fScale, fScale, fScale };
				tTemp.vAngle = { fAngle,fAngle,fAngle };

				vTargetPos.x = vTargetPos.x + fX;
				vTargetPos.z = vTargetPos.z + fZ;

				pGameObject = CVacuumStone::Create(m_pGraphicDev, &tTemp, vTargetPos);
				NULL_CHECK_RETURN(pGameObject, );
				FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject, Engine::Get_Scene()), );

				m_iStoneCount++;

				wsprintf(tagTemp, L"VacuumStone %d", m_iStoneCount);

				vTargetPos = pTargetTransCom->Get_Position();


				fX = CRandom(-10.f, 10.f);
				fZ = CRandom(-10.f, 10.f);
				fScale = CRandom(0.004f, 0.007f);
				fAngle = CRandom(0.f, 360.f);
				fRotX = CRandom(-1.f, 1.f);
				fRotY = CRandom(-1.f, 1.f);
				fRotZ = CRandom(-1.f, 1.f);


				tTemp.vPos = { matWorld._41, matWorld._42, matWorld._43 };
				tTemp.vScale = { fScale, fScale, fScale };
				tTemp.vAngle = { fAngle,fAngle,fAngle };

				vTargetPos.x = vTargetPos.x + fX;
				vTargetPos.z = vTargetPos.z + fZ;

				pGameObject = CVacuumStone::Create(m_pGraphicDev, &tTemp, vTargetPos);
				NULL_CHECK_RETURN(pGameObject, );
				FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject, Engine::Get_Scene()), );

				m_iStoneCount++;


				m_fStoneTime = 0.f;
			}

			if (m_iStoneCount >= 20)
			{
				m_iStoneCount = 0; m_bPattrunSelect = false;

				return;
			}
		}

		//���� ����
		if (m_iPatturnSelect == 2)
		{
			m_fMineTime += fTimeDelta;
			//���� �ϼ�
			if (!m_bRandomNum)
			{
				for (i = 0; i < 6; ++i)
				{
					data[i] = rand() % 6 + 1;
					for (sub_i = 0; sub_i < i; ++sub_i)
					{
						if (data[i] == data[sub_i])
						{
							i--;
							break;
						}
					}
				}

				m_bRandomNum = true;
			}
			if (!m_bMineSelect)
			{
				m_iMineSelect = data[m_iMinePatturnCount];
				m_iMinePatturnCount++;
				m_bMineSelect = true;
			}

			if (m_iMinePatturnCount > 6)
			{
				m_fMineTime = 0.f;
				m_bMineSelect = false;
				m_pMeshCom->Set_Animationset(11);
				m_iMinePatturnCount = 0;
				m_bRandomNum = false;
				m_bPattrunSelect = false;
				return;
			}
			m_fMineCreateTime += fTimeDelta;
			m_pMeshCom->Set_Animationset(25);

			CLayer*				pLayer = nullptr;
			pLayer = Engine::Get_Layer(L"GameObject");
			Engine::CGameObject*		pGameObject = nullptr;


			if (m_iMineSelect == 1)
			{
				//ù���� ����
				if (m_fMineCreateTime < 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX += m_fMineDis;
					if (m_fMineX > 6.f)
					{
						m_fMineX = 0.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos = { m_fMineX , 0.f, m_fMineZ };

					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos = { m_fMineX  , 0.f, m_fMineZ };
					}
				}
				else if (m_fMineCreateTime > 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX += m_fMineDis;
					if (m_fMineX > 6.f)
					{
						m_fMineX = 0.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos = { m_fMineX, 0.f, m_fMineZ };
					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos = { m_fMineX , 0.f, m_fMineZ };
						//m_fMineTime = 0.f;
						m_bMineSelect = false;
						m_fMineCreateTime = 0.f;
						m_pMeshCom->Set_Animationset(11);
					}
				}
			}

			if (m_iMineSelect == 2)
			{
				//ù���� ����
				if (m_fMineCreateTime < 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos2); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX2 += m_fMineDis;
					if (m_fMineX2 > 15.f)
					{
						m_fMineX2 = 9.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos2 = { m_fMineX2 , 0.f, m_fMineZ };

					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos2 = { m_fMineX2  , 0.f, m_fMineZ };
					}
				}
				else if (m_fMineCreateTime > 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos2); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX2 += m_fMineDis;
					if (m_fMineX2 > 15.f)
					{
						m_fMineX2 = 9.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos2 = { m_fMineX2, 0.f, m_fMineZ };
					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos2 = { m_fMineX2 , 0.f, m_fMineZ };
						//m_fMineTime = 0.f;
						m_bMineSelect = false;
						m_fMineCreateTime = 0.f;
						m_pMeshCom->Set_Animationset(11);
					}
				}
			}

			if (m_iMineSelect == 3)
			{
				//ù���� ����
				if (m_fMineCreateTime < 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos3); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX3 += m_fMineDis;
					if (m_fMineX3 > 24.f)
					{
						m_fMineX3 = 18.f;
						m_fMineZ3 += m_fMineDis;
					}

					m_vNextPos3 = { m_fMineX3 , 0.f, m_fMineZ3 };

					if (m_fMineZ3 > 21.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ3 = -21.f;
						m_vNextPos3 = { m_fMineX3  , 0.f, m_fMineZ3 };
					}
				}
				else if (m_fMineCreateTime > 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos3); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX3 += m_fMineDis;
					if (m_fMineX3 > 24.f)
					{
						m_fMineX3 = 18.f;
						m_fMineZ3 += m_fMineDis;
					}

					m_vNextPos3 = { m_fMineX3, 0.f, m_fMineZ3 };
					if (m_fMineZ3 > 21.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ3 = -21.f;
						m_vNextPos3 = { m_fMineX3 , 0.f, m_fMineZ3 };
						//m_fMineTime = 0.f;
						m_bMineSelect = false;
						m_fMineCreateTime = 0.f;
						m_pMeshCom->Set_Animationset(11);
					}
				}
			}

			if (m_iMineSelect == 4)
			{
				//ù���� ����
				if (m_fMineCreateTime < 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos4); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX4 += -m_fMineDis;
					if (m_fMineX4 < -6.f)
					{
						m_fMineX4 = 0.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos4 = { m_fMineX4 , 0.f, m_fMineZ };

					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos4 = { m_fMineX4  , 0.f, m_fMineZ };
					}
				}
				else if (m_fMineCreateTime > 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos4); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX4 += -m_fMineDis;
					if (m_fMineX4 < -6.f)
					{
						m_fMineX4 = 0.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos4 = { m_fMineX4, 0.f, m_fMineZ };
					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos4 = { m_fMineX4 , 0.f, m_fMineZ };
						//m_fMineTime = 0.f;
						m_bMineSelect = false;
						m_fMineCreateTime = 0.f;
						m_pMeshCom->Set_Animationset(11);
					}
				}
			}

			if (m_iMineSelect == 5)
			{
				//ù���� ����
				if (m_fMineCreateTime < 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos5); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX5 += -m_fMineDis;
					if (m_fMineX5 < -15.f)
					{
						m_fMineX5 = -9.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos5 = { m_fMineX5 , 0.f, m_fMineZ };

					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos5 = { m_fMineX5  , 0.f, m_fMineZ };
					}
				}
				else if (m_fMineCreateTime > 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos5); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX5 += -m_fMineDis;
					if (m_fMineX5 < -15.f)
					{
						m_fMineX5 = -9.f;
						m_fMineZ += m_fMineDis;
					}

					m_vNextPos5 = { m_fMineX5, 0.f, m_fMineZ };
					if (m_fMineZ > 24.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ = -24.f;
						m_vNextPos5 = { m_fMineX5 , 0.f, m_fMineZ };
						//m_fMineTime = 0.f;
						m_bMineSelect = false;
						m_fMineCreateTime = 0.f;
						m_pMeshCom->Set_Animationset(11);
					}
				}
			}

			if (m_iMineSelect == 6)
			{
				//ù���� ����
				if (m_fMineCreateTime < 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos6); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX6 += -m_fMineDis;
					if (m_fMineX6 < -24.f)
					{
						m_fMineX6 = -18.f;
						m_fMineZ3 += m_fMineDis;
					}

					m_vNextPos6 = { m_fMineX6 , 0.f, m_fMineZ3 };

					if (m_fMineZ3 > 21.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ3 = -21.f;
						m_vNextPos6 = { m_fMineX6  , 0.f, m_fMineZ3 };
					}
				}
				else if (m_fMineCreateTime > 0.8f)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandJaw");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumMine %d", m_iMineCount);

					_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };

					pGameObject = CVacuumMine::Create(m_pGraphicDev, vTemp, m_vNextPos6); //������ġ, ��������ġ.
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iMineCount++;
					m_fMineX6 += -m_fMineDis;
					if (m_fMineX6 < -24.f)
					{
						m_fMineX6 = -18.f;
						m_fMineZ3 += m_fMineDis;
					}

					m_vNextPos6 = { m_fMineX6, 0.f, m_fMineZ3 };
					if (m_fMineZ3 > 21.f) //�ʱ�ȭ �ܰ�
					{
						m_fMineZ3 = -21.f;
						m_vNextPos6 = { m_fMineX6 , 0.f, m_fMineZ3 };
						//m_fMineTime = 0.f;
						m_bMineSelect = false;
						m_fMineCreateTime = 0.f;
						m_pMeshCom->Set_Animationset(11);
					}
				}
			}
			//LeftHandJaw, RightHandJaw


		}

		//��(�����Ҽ��ִ� ��ź).
		if (m_iPatturnSelect == 3)
		{
			m_fBombTime += fTimeDelta;
			m_bSound[Sound_Stone] = false;
			if (m_fBombTime > 1.f)
			{

				if (!m_bSound[Sound_Stone])
				{
					Engine::StopSound(CSoundMgr::CHANNELID::Vacuum_Stone);
					Engine::PlaySoundW(L"Vacuum_StoneReady.wav", CSoundMgr::CHANNELID::Vacuum_Stone, 0.2f);

					m_bSound[Sound_Stone] = true;
				}


				CTransform*		pTargetTransCom = static_cast<CTransform*>(m_pTargetPlayer->Get_Component(L"Com_Transform", Engine::ID_DYNAMIC));

				_vec3 vTargetPos;
				vTargetPos = pTargetTransCom->Get_Position();
				m_pMeshCom->Set_Animationset(11);

				CLayer*				pLayer = nullptr;
				pLayer = Engine::Get_Layer(L"GameObject");
				Engine::CGameObject*		pGameObject = nullptr;

				const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("Neck");

				_matrix matBoneWorld, matWorld;
				matBoneWorld = pFrame->CombinedTranformationMatrix;
				matWorld = *(m_pTransformCom->Get_WorldMatrix());

				matWorld = matBoneWorld * matWorld;

				_tchar tagTemp[MAX_PATH];
				wsprintf(tagTemp, L"VacuumBomb %d", m_iBombCount);

				_vec3 vTemp = { matWorld._41, matWorld._42, matWorld._43 };
				_float fX;
				_float fZ;
				/*	fX = rand()*/
				CRandoms CRandom;
				fX = CRandom(-5.f, 5.f);
				fZ = CRandom(-5.f, 5.f);

				vTargetPos.x = vTargetPos.x + fX;
				vTargetPos.z = vTargetPos.z + fZ;
				auto* pBomb = m_vecBomb.front();
				pBomb->Set_Move(vTemp, vTargetPos);
				m_vecActiveBomb.emplace_back(pBomb);
				m_vecBomb.pop_front();

				m_iBombCount++;
				m_iBombMaxCount++;

				wsprintf(tagTemp, L"VacuumBomb %d", m_iBombCount);

				vTargetPos = pTargetTransCom->Get_Position();
				fX = CRandom(-5.f, 5.f);
				fZ = CRandom(-5.f, 5.f);

				vTargetPos.x = vTargetPos.x + fX;
				vTargetPos.z = vTargetPos.z + fZ;

				m_vecBomb.front()->Set_Move(vTemp, vTargetPos);
				m_vecActiveBomb.emplace_back(m_vecBomb.front());
				m_vecBomb.pop_front();

				m_iBombMaxCount++;
				m_iBombCount++;
				m_fBombTime = 0.f;
			}

			if (m_iBombMaxCount >= 10)
			{
				m_bPartPatturn = true;
				m_bPartUp = true;
				m_bBombCheck = true;
				m_iBombMaxCount = 0;
				m_fBombTime = 0.f;
				m_bPattrunSelect = false;
				return;
			}
		}

		//��� 
		if (m_iPatturnSelect == 4)
		{
			m_pMeshCom->Set_Animationset(5);
			m_fTwoHandCircleTime += fTimeDelta;

			CLayer*				pLayer = nullptr;
			pLayer = Engine::Get_Layer(L"GameObject");
			Engine::CGameObject*		pGameObject = nullptr;

			if (!m_bSound[Sound_Double])
			{
				Engine::StopSound(CSoundMgr::CHANNELID::Vacuum_Double);
				Engine::PlaySoundW(L"Vacuum_Double.wav", CSoundMgr::CHANNELID::Vacuum_Double);

				m_bSound[Sound_Double] = true;
			}


			if (m_fTwoHandCircleTime > 1.f)
			{

				if (m_iTwoHandCircleMax == 0)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandBottomLips1");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_vec3 vPos;
					vPos = { matWorld._41, matWorld._42 + 1.5f, matWorld._43 };

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumCircle %d", m_iTwoHandCircle);

					pGameObject = CVacuumCircle::Create(m_pGraphicDev, vPos);
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iTwoHandCircle++;
					m_iTwoHandCircleMax++;
				}
				if (m_iTwoHandCircleMax == 1)
				{

					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandBottomLips1");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_vec3 vPos;
					vPos = { matWorld._41, matWorld._42 + 1.2f, matWorld._43 + 0.5f };

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumCircle %d", m_iTwoHandCircle);

					pGameObject = CVacuumCircle::Create(m_pGraphicDev, vPos);
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iTwoHandCircleMax++;
					m_iTwoHandCircle++;

				}
			}

			if (m_iTwoHandCircleMax >= 2)
			{
				m_iTwoHandCircleMax = 0;
				m_fTwoHandCircleTime = 0.f;
				m_bPattrunSelect = false;
				m_bSound[Sound_Double] = false;
				return;
			}
		}

		//�Ѽ�
		if (m_iPatturnSelect == 5)
		{
			m_pMeshCom->Set_Animationset(6);
			m_fOneHandCircleTime += fTimeDelta;

			CLayer*				pLayer = nullptr;
			pLayer = Engine::Get_Layer(L"GameObject");
			Engine::CGameObject*		pGameObject = nullptr;

			if (!m_bSound[Sound_Single])
			{
				Engine::StopSound(CSoundMgr::CHANNELID::Vacuum_Single);
				Engine::PlaySoundW(L"Vacuum_Single.wav", CSoundMgr::CHANNELID::Vacuum_Single);

				m_bSound[Sound_Single] = true;
			}

			if (m_fOneHandCircleTime > 1.f)
			{
				if (m_iOneHandCircleMax == 0)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandBottomLips1");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_vec3 vPos;
					vPos = { matWorld._41, matWorld._42 + 1.5f, matWorld._43 };

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumOneHandCircle %d", m_iOneHandCircle);

					pGameObject = CVacuumCircle::Create(m_pGraphicDev, vPos);
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iOneHandCircle++;
					m_iOneHandCircleMax++;
				}
			}

			if (m_fOneHandCircleTime > 2.5f)
			{
				if (m_iOneHandCircleMax == 1)
				{
					const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("RightHandBottomLips1");

					_matrix matBoneWorld, matWorld;
					matBoneWorld = pFrame->CombinedTranformationMatrix;
					matWorld = *(m_pTransformCom->Get_WorldMatrix());

					matWorld = matBoneWorld * matWorld;

					_vec3 vPos;
					vPos = { matWorld._41, matWorld._42 + 1.2f, matWorld._43 + 0.5f };

					_tchar tagTemp[MAX_PATH];
					wsprintf(tagTemp, L"VacuumOneHandCircle %d", m_iOneHandCircle);

					pGameObject = CVacuumCircle::Create(m_pGraphicDev, vPos);
					NULL_CHECK_RETURN(pGameObject, );
					FAILED_CHECK_RETURN(pLayer->Add_GameObject(tagTemp, pGameObject), );

					m_iOneHandCircle++;
					m_iOneHandCircleMax++;
				}
			}

			if (m_iOneHandCircleMax >= 2)
			{
				m_iOneHandCircleMax = 0;
				m_fOneHandCircleTime = 0.f;
				m_bPattrunSelect = false;
				m_bSound[Sound_Single] = false;
				return;
			}
		}
	}
}

void CVacuum::Stun(const _float & fTimeDelta)
{

	m_iAniIndex = m_pMeshCom->Get_AniIndex();
	CCody*	pCody = (CCody*)Engine::Get_GameObject(L"GameObject", L"Cody");
	CMay*	pMay = (CMay*)Engine::Get_GameObject(L"GameObject", L"May");

	if (pCody)
		m_bCodyRide = pCody->Get_RideEnd();
	//if(pMay)//����Ÿ�°ŵǸ� �̰��������.
		//m_bMayRide = pMay->Get_RideEnd();

	//�̰� ��ſ� Ÿ�������� bool�� ������ �Ѵ� Ʈ��� ����
	if (Key_Down(DIK_7))
	{
		m_bMayRide = true;
		m_bCodyRide = true;
	}

	if (m_bCodyRide && m_bMayRide)
	{
		Dead(fTimeDelta);
		return;
	}

	if (!m_bStunFirst)
	{
		m_pMeshCom->Set_Animationset(animID::VacuumBoss_Stunned_Enter);
		if (m_iAniIndex == animID::VacuumBoss_Stunned_Enter && m_pMeshCom->Is_AnimationSetEnd(0.1f))
		{
			m_pMeshCom->Set_Animationset(animID::VacuumBoss_Stunned, 1.0f, 0.05f);
			m_bStunFirst = true;

			//Ʈ���� ����.
			if (!m_bCreateTrigger)
			{
				const Engine::D3DXFRAME_DERIVED* pFrame = m_pMeshCom->Get_FrameByName("LeftHandBend");
				const _matrix*	m_pParentBoneMatrix = &pFrame->CombinedTranformationMatrix;
				const _matrix*  m_pParentWorldMatrix = m_pTransformCom->Get_WorldMatrix();

				_matrix matWorld;
				matWorld = *m_pParentBoneMatrix * *m_pParentWorldMatrix;
				_vec3 vPos = { matWorld._41, matWorld._42, matWorld._43 };
				m_pTrigger[TriggerID::LeftHand] = CTrigger::CreateBoxTrigger(m_pScene, L"LeftHandBend", vPos, 1.f, TRIGGER_VACUUM_LEFT, FilterGroup::eInteractItem);


				pFrame = m_pMeshCom->Get_FrameByName("RightHandBend");
				const _matrix*	m_pParentBoneMatrix2 = &pFrame->CombinedTranformationMatrix;
				const _matrix*  m_pParentWorldMatrix2 = m_pTransformCom->Get_WorldMatrix();

				_matrix matWorld2;
				matWorld2 = *m_pParentBoneMatrix2 * *m_pParentWorldMatrix2;
				vPos = { matWorld2._41, matWorld2._42, matWorld2._43 };

				m_pTrigger[TriggerID::RightHand] = CTrigger::CreateBoxTrigger(m_pScene, L"RightHandBend", vPos, 1.f, TRIGGER_VACUUM_RIGHT, FilterGroup::eInteractItem);
				m_bCreateTrigger = true;
			}
		}
	}

}

void CVacuum::Dead(const _float & fTimeDelta)
{
	if (m_iAniIndex == animID::VacuumBoss_Stunned)
		m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_ArmsOverride_Preview);

	//if (m_iAniIndex == animID::VacuumBoss_End_ArmsOverride_Preview && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	//{
	//	m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_ArmsOverride_50, 1.f, 0.1f);
	//}
	//else if (m_iAniIndex == animID::VacuumBoss_End_ArmsOverride_50 && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	//{
	//	m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_ArmsOverride_75);
	//}
	//else if (m_iAniIndex == animID::VacuumBoss_End_ArmsOverride_75 && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	//{
	//	m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_EyePoppedOut);
	//}
	//else if (m_iAniIndex == animID::VacuumBoss_End_EyePoppedOut && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	//{
	//	m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_EyePoppedOut_Enter);
	//}
	//else if (m_iAniIndex == animID::VacuumBoss_End_EyePoppedOut_Enter && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	//{
	//	m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_Death);
	//}
	//else if (m_iAniIndex == animID::VacuumBoss_End_Death && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	//{
	//	m_bAniStop = true;
	//}


	if (m_iAniIndex == animID::VacuumBoss_End_ArmsOverride_Preview && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_ArmsOverride_75, 1.f, 0.1f);
	}
	else if (m_iAniIndex == animID::VacuumBoss_End_ArmsOverride_75 && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_EyePoppedOut);
	}
	else if (m_iAniIndex == animID::VacuumBoss_End_EyePoppedOut && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_EyePoppedOut_Enter);
	}
	else if (m_iAniIndex == animID::VacuumBoss_End_EyePoppedOut_Enter && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::VacuumBoss_End_Death);
	}
	else if (m_iAniIndex == animID::VacuumBoss_End_Death && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_bAniStop = true;
	}


}


void CVacuum::Create_UI(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, );

	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;
	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_STATIC;

	pGameObject = CImageUI::Create(m_pGraphicDev, &tObj);
	m_pBossName = pGameObject->Is<CImageUI>();
	m_pBossName->Set_Image(L"BossName");
	m_pBossName->Set_Size(_vec3{ 185.f, 24.f, 0.f });
	m_pBossName->Set_Pos(_vec3{ 180.f, -65.f, 0.f });
	m_pBossName->Set_RenderID(RENDER_UI);
	m_pBossName->Set_PassIndex(2);
	m_pBossName->Set_TextureIndex(0);
	NULL_CHECK_RETURN(pGameObject, );
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"BossName", pGameObject), );
	m_pBossName->AddRef();

	pGameObject = CImageUI::Create(m_pGraphicDev, &tObj);
	m_pBossHp = pGameObject->Is<CImageUI>();
	m_pBossHp->Set_Image(L"HP");
	m_pBossHp->Set_Size(_vec3{ 1600.f, 50.f, 0.f });
	m_pBossHp->Set_Pos(_vec3{ 160.f, -90.f, 0.f });
	m_pBossHp->Set_RenderID(RENDER_MENUUI);
	m_pBossHp->Set_PassIndex(4);
	m_pBossHp->Set_TextureIndex(0);
	NULL_CHECK_RETURN(pGameObject, );
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"BossHP", pGameObject), );
	m_pBossHp->AddRef();

	pGameObject = CImageUI::Create(m_pGraphicDev, &tObj);
	m_pBossHpbg = pGameObject->Is<CImageUI>();
	m_pBossHpbg->Set_Image(L"HP");
	m_pBossHpbg->Set_Size(_vec3{ 1600.f, 50.f, 0.f });
	m_pBossHpbg->Set_Pos(_vec3{ 160.f, -90.f, 0.f });
	m_pBossHpbg->Set_RenderID(RENDER_UI);
	m_pBossHpbg->Set_PassIndex(5);
	m_pBossHpbg->Set_TextureIndex(0);
	NULL_CHECK_RETURN(pGameObject, );
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"BossHPBG", pGameObject), );
	m_pBossHpbg->AddRef();

	Engine::Add_Layer(pLayerTag, pLayer);
}

void CVacuum::Update_UI(const _float & fTimeDelta)
{
	HP_UI(fTimeDelta);
}

void CVacuum::HP_UI(const _float & fTimeDelta)
{
	if (m_iHP <= 0)
	{
		m_pBossHp->Set_Visible(false);
		m_pBossHpbg->Set_Visible(false);
		m_pBossName->Set_Visible(false);
	}

	m_pBossHp->Set_Amount((_float)m_iHP / (_float)m_iHPMax);
}

CVacuum * CVacuum::Create(LPDIRECT3DDEVICE9 pGraphicDev, void * pArg)
{
	CVacuum*	pInstance = new CVacuum(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void CVacuum::Free(void)
{
	for (auto& pBomb : m_vecActiveBomb)
		Safe_Release(pBomb);
	for (auto& pBomb : m_vecBomb)
		Safe_Release(pBomb);

	Safe_Release(m_pBossHp);
	Safe_Release(m_pBossHpbg);
	Safe_Release(m_pBossName);

	CEnermy::Free();
}



void CVacuum::Create_Bomb(void * pArg)
{
	CVacuumBomb* pGameObject = nullptr;
	_vec3 vPos = { 0.f,-10000.f,0.f };
	for (int i = 0; i < 20; ++i)
	{
		pGameObject = CVacuumBomb::Create(m_pGraphicDev, vPos, vPos);
		NULL_CHECK_RETURN(pGameObject, );
		m_vecBomb.emplace_back(pGameObject);
	}
}

#pragma region �������� ���� �� �ٿ�

void CVacuum::All_FrontDoorOpen(_bool bState)
{
	CVacuumFieldPart4*	pPart4_1 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_1");
	CVacuumFieldPart4*	pPart4_2 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_2");

	pPart4_1->Set_MoveOpenCheck(true);
	pPart4_2->Set_MoveOpenCheck(true);
	CVacuumFieldPart5*	pHead = (CVacuumFieldPart5*)Engine::Get_GameObject(L"Interact", L"VacuumFieldHead_2");
	if (bState)
		pHead->Set_MoveUpCheckFront(bState);

}

void CVacuum::All_BackDoorOpen()
{
	CVacuumFieldPart4*	pPart4_3 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_3");
	CVacuumFieldPart4*	pPart4_4 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_4");

	pPart4_3->Set_MoveOpenCheck(true);
	pPart4_4->Set_MoveOpenCheck(true);
}

void CVacuum::All_FrontDoorCloes()
{
	CVacuumFieldPart4*	pPart4_1 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_1");
	CVacuumFieldPart4*	pPart4_2 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_2");

	pPart4_1->Set_MoveCloseCheck(true);
	pPart4_2->Set_MoveCloseCheck(true);
}

void CVacuum::All_BackDoorCloes()
{
	CVacuumFieldPart4*	pPart4_3 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_3");
	CVacuumFieldPart4*	pPart4_4 = (CVacuumFieldPart4*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart4_4");

	pPart4_3->Set_MoveCloseCheck(true);
	pPart4_4->Set_MoveCloseCheck(true);
}


void CVacuum::All_PartUp()
{
	CVacuumFieldPart*	pPart1 = (CVacuumFieldPart*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart_1");
	CVacuumFieldPart*	pPart2 = (CVacuumFieldPart*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart_2");
	CVacuumFieldPart2*	pPart2_1 = (CVacuumFieldPart2*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart2_1");
	CVacuumFieldPart3*	pPart3_1 = (CVacuumFieldPart3*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart3_1");
	CVacuumFieldPart3*	pPart3_2 = (CVacuumFieldPart3*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart3_2");
	CVacuumFieldPart5*	pHeadPart = (CVacuumFieldPart5*)Engine::Get_GameObject(L"Interact", L"VacuumFieldHead_1");

	pPart1->Set_MoveUpCheck(true);
	pPart2->Set_MoveUpCheck(true);
	pPart2_1->Set_MoveUpCheck(true);
	pPart3_1->Set_MoveUpCheck(true);
	pPart3_2->Set_MoveUpCheck(true);
	pHeadPart->Set_MoveUpCheck(true);
}

void CVacuum::All_PartDown()
{
	CVacuumFieldPart*	pPart1 = (CVacuumFieldPart*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart_1");
	CVacuumFieldPart*	pPart2 = (CVacuumFieldPart*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart_2");
	CVacuumFieldPart2*	pPart2_1 = (CVacuumFieldPart2*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart2_1");
	CVacuumFieldPart3*	pPart3_1 = (CVacuumFieldPart3*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart3_1");
	CVacuumFieldPart3*	pPart3_2 = (CVacuumFieldPart3*)Engine::Get_GameObject(L"GameObject", L"VacuumFieldPart3_2");
	CVacuumFieldPart5*	pHeadPart = (CVacuumFieldPart5*)Engine::Get_GameObject(L"Interact", L"VacuumFieldHead_1");
	CVacuumFieldPart5*	pHead = (CVacuumFieldPart5*)Engine::Get_GameObject(L"Interact", L"VacuumFieldHead_2");

	pPart1->Set_MoveDownCheck(true);
	pPart2->Set_MoveDownCheck(true);
	pPart2_1->Set_MoveDownCheck(true);
	pPart3_1->Set_MoveDownCheck(true);
	pPart3_2->Set_MoveDownCheck(true);
	pHeadPart->Set_MoveDownCheck(true);
	pHead->Set_MoveDownCheckFront(true);
}

void CVacuum::PartUp(const _float& fTimeDelta)
{

	m_fPartUpDelta += fTimeDelta;


	if (!m_bSound[Sound_PartUp])
	{
		Engine::StopSound(CSoundMgr::CHANNELID::Vacuum_Part);
		Engine::PlaySoundW(L"Play_World_Shed_Vacuum_Platform_BossBack_Down.bnk_1.wav", CSoundMgr::CHANNELID::Vacuum_Part, 0.2f);

		m_bSound[Sound_PartUp] = true;
	}
	if (0 == m_iPartUpSelect && m_fPartUpDelta > 0.f)
	{
		All_BackDoorOpen();
		m_iPartUpSelect++;
	}

	if (1 == m_iPartUpSelect && m_fPartUpDelta > 0.5f)
	{
		All_PartUp();
		m_iPartUpSelect++;
	}

	if (2 == m_iPartUpSelect && m_fPartUpDelta > 4.5f)
	{
		All_FrontDoorOpen(true);
		m_iPartUpSelect++;
	}

	if (3 == m_iPartUpSelect && m_fPartUpDelta > 6.5f)
	{
		All_FrontDoorCloes();
		m_iPartUpSelect++;

		m_fPartUpDelta = 0.f;
		m_iPartUpSelect = 0;
		m_bPartUp = false;
		m_bSound[Sound_PartUp] = false;
	}

}

void CVacuum::PartDown(const _float& fTimeDelta)
{
	m_fPartDownDelta += fTimeDelta;

	if (!m_bSound[Sound_PartDown])
	{
		Engine::StopSound(CSoundMgr::CHANNELID::Vacuum_Part);
		Engine::PlaySoundW(L"Play_World_Shed_Vacuum_Platform_BossBack_Down.bnk_1.wav", CSoundMgr::CHANNELID::Vacuum_Part, 0.2f);

		m_bSound[Sound_PartDown] = true;
	}

	if (0 == m_iPartDownSelect && m_fPartDownDelta > 0.f)
	{
		All_FrontDoorOpen(false);
		m_iPartDownSelect++;
	}

	if (1 == m_iPartDownSelect && m_fPartDownDelta > 0.5f)
	{
		All_PartDown();
		m_iPartDownSelect++;
	}

	if (2 == m_iPartDownSelect && m_fPartDownDelta > 2.0f)
	{
		All_FrontDoorCloes();
		m_iPartDownSelect++;

	}
	if (3 == m_iPartDownSelect && m_fPartDownDelta > 6.5f)
	{
		All_BackDoorCloes();
		m_iPartDownSelect++;

		m_fPartDownDelta = 0.f;
		m_iPartDownSelect = 0;
		m_bPartDown = false;
		m_bSound[Sound_PartDown] = false;
	}

}

#pragma endregion 

