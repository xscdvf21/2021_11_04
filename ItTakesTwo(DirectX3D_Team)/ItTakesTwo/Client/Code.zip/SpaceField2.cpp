#include "stdafx.h"
#include "SpaceField2.h"
#include "Export_Function.h"
#include "UI.h"
#include "Cody.h"
#include "May.h"
#include "CodyCamera.h"
#include "MayCamera.h"
#include "StaticObject.h"
#include "SpaceField2.h"
#include "Map.h"
#include "SceneChangeSpace.h"
#include "DeadSpace.h"
#include "May_Space.h"
#include "Cody_Space.h"
#include "GroundBounce.h"
#include "SpaceCup.h"
#include "SpaceWall.h"
#include "SpacePlatform.h"
#include "SpaceValve.h"
#include "SpaceValveSpring.h"
#include "GroundBouncePanel.h"
#include "GeneratorBattery.h"
#include "SpacePlatformWall.h"
#include "Lever.h"
#include "SpaceLever.h"

CSpaceField2::CSpaceField2(LPDIRECT3DDEVICE9 pDevice)
	: CScene(pDevice)
{
}

CSpaceField2::~CSpaceField2()
{
}

HRESULT CSpaceField2::Ready_Scene()
{
	Engine::Set_SoundScene(RESOURCE_SF);

	//Engine::End_Split();
	Engine::Start_Split();
	g_bMenu = false;
	g_bSlideFinal = false;
	auto* pPhysics = Engine::Get_Physics();
	auto* pDispatcher = Engine::Get_Dispatcher();
	auto* pCudaMgr = Engine::Get_CudaMgr();
	CScene::Ready_PhysX(this, pPhysics, pDispatcher, pCudaMgr);

	if (!m_pScene)
		return E_FAIL;

	//pPlane->setGlobalPose(PxTransform(0, 0.f, 0));

	auto* pPlane = PxCreatePlane(*pPhysics, PxPlane(0, 1, 0, 1), *pPhysics->createMaterial(0.5f, 0.5f, 0.f));

	pPlane->setName((char*)pPlane);
	setupFiltering(Engine::Get_Allocator(), pPlane, FilterGroup::eGround, FilterGroup::eCody | FilterGroup::eMay);
	m_pScene->addActor(*pPlane);
	m_pScene->setGravity(PxVec3(0.0f, -20.f, 0.0f));
	FAILED_CHECK_RETURN(Ready_Environment_Layer(L"Environment"), E_FAIL);
	FAILED_CHECK_RETURN(Ready_GameObject_Layer(L"GameObject"), E_FAIL);
	FAILED_CHECK_RETURN(Ready_Interact_Layer(L"Interact"), E_FAIL);
	FAILED_CHECK_RETURN(Ready_Valve_Layer(L"Valve"), E_FAIL);

	//FAILED_CHECK_RETURN(Ready_LoadMap_Layer(L"LoadObject", L"../../Data/ITT_Test/Test.dat"), E_FAIL);

	if (!Engine::Is_LightExsist())
		Ready_LightInfo();


	return S_OK;
}

_int CSpaceField2::Update_Scene(const _float & fTimeDelta)
{
	if (m_bStart)
	{

		m_bStart = false;
	}

	m_pScene->simulate(fTimeDelta);

	m_pScene->fetchResults(true);
	_int iExit = Engine::CScene::Update_Scene(fTimeDelta);



	if (Engine::Key_Down(DIK_Y))
	{

		CHANGE_SCENE(m_pGraphicDev, SCENE_SF3,OBJ_NOEVENT);
		return 0;
	}
	return iExit;
}

_int CSpaceField2::LateUpdate_Scene(const _float & fTimeDelta)
{
	_int iExit = Engine::CScene::LateUpdate_Scene(fTimeDelta);

	return iExit;
}

void CSpaceField2::Render_Scene()
{

}

void CSpaceField2::onConstraintBreak(PxConstraintInfo* constraints, PxU32 count)
{

	return;
}

void CSpaceField2::onWake(PxActor** actors, PxU32 count)
{
	OutputDebugString(L"����");
	return;
}

void CSpaceField2::onSleep(PxActor** actors, PxU32 count)
{
	OutputDebugString(L"���");

	return;
}

void CSpaceField2::onContact(const PxContactPairHeader& pairHeader, const PxContactPair* pairs, PxU32 nbPairs)
{
	OutputDebugString(L"�浹����\n");
	for (PxU32 i = 0; i < nbPairs; ++i)
	{

		/*if ((!strcmp(pairHeader.actors[0]->getName(), "Cody") && !strcmp(pairHeader.actors[1]->getName(), "Wall")) ||
			(!strcmp(pairHeader.actors[1]->getName(), "Cody") && !strcmp(pairHeader.actors[0]->getName(), "Wall")))
		{
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Set_Climbing(true);
		}*/

	}
}

void CSpaceField2::onTrigger(PxTriggerPair* pairs, PxU32 count)
{
	for (PxU32 i = 0; i < count; ++i)
	{
		if (pairs[i].triggerShape->getSimulationFilterData().word0 == FilterGroup::eWall &&
			pairs[i].otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
		{
			pairs[i].triggerActor->getGlobalPose();
			CCody* pCody = (CCody*)Engine::Get_GameObject(L"GameObject", L"Cody");
		}
		auto Trigger = pairs[i];
		if (Trigger.otherShape->getSimulationFilterData().word0 &(FilterGroup::eCody | FilterGroup::eMay))
		{
			auto* pTrigger = ToTrigger(Trigger.triggerShape->getName());
			if (Trigger.status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
				pTrigger->Set_Active(true);
			else if (Trigger.status == PxPairFlag::eNOTIFY_TOUCH_LOST)
				pTrigger->Set_Active(false);

			if (!pTrigger)
				return;
			switch (pTrigger->Get_Type())
			{
			case TRIGGER_LEVER_CODY:
				Event_Lever_Cody(&Trigger);
				break;
			case TRIGGER_LEVER_MAY:
				Event_Lever_May(&Trigger);
				break;
			case TRIGGER_SCENE_CHANGE:
				Event_Scene_Change(&Trigger);
				break;
			case TRIGGER_SPACE_WALL_CODY:
				Event_SpaceWall(&Trigger);
				break;
			case TRIGGER_BOUNCE_SWITCH:
				Event_Bounce_Switch(&Trigger);
				break;
			case TRIGGER_HANDLE:
				Event_Handle(&Trigger);
				break;
			case TRIGGER_SPACE_GENERATOR_BATTERY:
				Event_Generator_Battery(&Trigger);
				break;
			}
		}
	}
}

void CSpaceField2::onAdvance(const PxRigidBody*const* bodyBuffer, const PxTransform* poseBuffer, const PxU32 count)
{
	OutputDebugString(L"������Ʈ");
}


void CSpaceField2::Event_Scene_Change(PxTriggerPair* pairs)
{
	//ToTrigger(pairs->triggerActor->getName())->Activate();
}

void CSpaceField2::Event_SpaceWall(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());
	CSpaceWall* pWall = pTrigger->Is<CSpaceWall>();

	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		CCody* pCody = ToObj<CCody>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pCody, );

		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
		{
			pCody->Set_Push(true, pWall, pWall->Get_Target1(), CCody::SPACE_WALL);
		}
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
		{
			pCody->Set_Push(false);
	
		}
	}
	else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	{
		CMay* pMay = (CMay*)Engine::Get_GameObject(L"GameObject", L"May");
		NULL_CHECK_RETURN(pMay, );

		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
		{
			pMay->Set_Push(true, pWall, pWall->Get_Target2(), CMay::SPACE_WALL);
		}

		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
		{
			pMay->Set_Push(false);
		}
	}
}

void CSpaceField2::Event_Handle(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());
	CSpaceValve* pHandle = ToTrigger(pairs->triggerShape->getActor()->getName())->Is<CSpaceValve>();

	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Set_Handle(true, pHandle->Get_ObjTag());
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Set_Handle(false);
	}
	else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	{
		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
			Engine::Get_GameObject(L"GameObject", L"May")->Is<CMay>()->Set_Handle(true, pHandle->Get_ObjTag());
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
			Engine::Get_GameObject(L"GameObject", L"May")->Is<CMay>()->Set_Handle(false);
	}
}


void CSpaceField2::Event_Lever_Cody(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());
	CSpaceLever* pLever = ToTrigger(pairs->triggerShape->getActor()->getName())->Is<CSpaceLever>();

	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
		{
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Set_PickUp(true, CCody::LEVER, pTrigger->Is<CLever>());
			ToObj<CCody>(pairs->otherShape->getName())->Set_Slap(pLever->Get_Slap());
		}
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
		{
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Set_PickUp(false, CCody::LEVER, nullptr);
		}
	}
}

void CSpaceField2::Event_Generator_Battery(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());
	CGeneratorBattery*		pBattery = pTrigger->Is<CGeneratorBattery>();

	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		CCody_Space* pCody = ToObj<CCody_Space>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pCody, );

		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
		{
			OutputDebugString(L"�ڵ� ���͸��� ���� �� ����");
			pCody->Set_Push(true, pBattery, pBattery->Get_Push_StartPos(), CCody_Space::GENERATOR_BATTERY);
		}
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
		{
			pCody->Set_Push(false);
		}
	}
}

void CSpaceField2::Event_Lever_May(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());


	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	{
		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
			Engine::Get_GameObject(L"GameObject", L"May")->Is<CMay>()->Set_PickUp(true, CMay::LEVER, pTrigger->Is<CLever>());
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
			Engine::Get_GameObject(L"GameObject", L"May")->Is<CMay>()->Set_PickUp(false, CMay::LEVER, nullptr);
	}
}

void CSpaceField2::Event_Bounce_Switch(PxTriggerPair* pairs)
{
	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	{
		if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
		{
			if (ToObj<CCody_Space>(pairs->otherShape->getName())->Is_GroundFound())
			{
				ToTrigger(pairs->triggerShape->getName())->Activate();
			}
		}
		if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
		{
			if (ToObj<CMay_Space>(pairs->otherShape->getName())->Is_GroundFound())
			{
				ToTrigger(pairs->triggerShape->getName())->Activate();
			}
		}
	}
}



void CSpaceField2::Event_Float(PxTriggerPair* pairs)
{
	//CFan* pFan = ToTrigger(pairs->triggerShape->getActor()->getName())->Is<CFan>();
	//_float3 vPos = ToTrigger(pairs->triggerShape->getActor()->getName())->Get_Pos();
	//NULL_CHECK_RETURN(pFan, );

	//if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	//{
	//	CCody* pCody = ToObj<CCody>(pairs->otherShape->getName());
	//	NULL_CHECK_RETURN(pCody, );

	//	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	//		pCody->Set_Float(true, pFan->Get_Up(), pFan, vPos, 20.f);

	//	else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
	//		pCody->Set_Float(false, pFan->Get_Up(), nullptr, vPos);
	//}
	//else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	//{
	//	CMay* pMay = (CMay*)Engine::Get_GameObject(L"GameObject", L"May");
	//	NULL_CHECK_RETURN(pMay, );

	//	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	//		pMay->Set_Float(true, pFan->Get_Up(), pFan, vPos, 20.f);

	//	else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
	//		pMay->Set_Float(false, pFan->Get_Up(), nullptr, vPos);
	//}
}

void CSpaceField2::Event_Dead(PxTriggerPair * pairs)
{
	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		CCody* pCody = ToObj<CCody>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pCody, );

		pCody->Set_PlayerDead();
	}
	else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	{
		CMay* pMay = ToObj<CMay>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pMay, );
		pMay->Set_PlayerDead();
	}
}

HRESULT CSpaceField2::Ready_Environment_Layer(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;

	OBJINFO tInfo;
	_int iX = 0, iY = 0, iZ = 0, iScale = 0;


	m_mapLayer.emplace(pLayerTag, pLayer);
	return S_OK;
}
//#��������	�����̽� �ʵ�2
HRESULT CSpaceField2::Ready_GameObject_Layer(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_SF2;
	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;
	tObj.vScale = { 0.01f, 0.01f ,0.01f };

	// CodyCamera
	pGameObject = CCodyCamera::Create(m_pGraphicDev, &_vec3(0.f, 10.f, -5.f), &_vec3(0.f, 0.f, 1.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"CodyCamera", pGameObject, this), E_FAIL);

	// MayCamera
	pGameObject = CMayCamera::Create(m_pGraphicDev, &_vec3(0.f, 10.f, -5.f), &_vec3(0.f, 0.f, 1.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MayCamera", pGameObject, this), E_FAIL);

	//pGameObject = CMainCamera::Create(m_pGraphicDev, &_vec3(0.f, 0.f, -5.f), &_vec3(0.f, 0.f, 0.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f, &_vec3(0.f, 0.f, -5.0f), 12.f);
	//NULL_CHECK_RETURN(pGameObject, E_FAIL);
	//FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MainCamera", pGameObject), E_FAIL);
	//pGameObject->Is<CMainCamera>()->Set_Offset({ 0.f,2.f,0.f });

	tObj.vPos = { 0.f,5.f,0.f };
	tObj.vPos = { 190.f,40.f,-0.91f };//�׶���ٿ
	tObj.vPos = { 222.6f,23.81f,-1.49f };
	tObj.vPos = { 278.6f,15.f,-0.91f };//��
	tObj.vPos = { 269.564f,13.451f,-0.85773f };// ��
	tObj.vPos = { 250.5774f, 13.46f,-1.0f };// �ڵ�
	tObj.vPos = { 69.5f, 23.5f, -1.f };// ���� �÷���
	tObj.vPos = { 340.f, 10.f, 0.5f }; //���׷�����.

	pGameObject = CCody_Space::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Cody", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eCody, FilterGroup::eGround | FilterGroup::eWall);
	//pGameObject->Is<CCody_Space>()->Set_ChangeAble(false);
	//tObj.vPos = { 222.6f,17.81f,-1.49f }; // �ü�
	tObj.vPos = { 262.33f, 29.5159f, -1.0f };// �ڵ� - ����
	
	pGameObject = CMay_Space::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"May", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eMay, FilterGroup::eGround | FilterGroup::eWall);
	pGameObject->Is<CMay_Space>()->Set_Up({ 0.f,-1.f,0.f });





#pragma region �� Ʈ���� //////////////////////////////////////////////////////////////////////////
	m_pTrigger[TRIGGER_SPACE_MOVEPLATFORM] = CTrigger::CreateBoxTrigger(m_pScene, L"TRIGGER_SPACE_MOVEPLATFORM", _vec3(-8.f, 0.f, -24.f), 2.f, TRIGGER_SPACE_MOVEPLATFORM, FilterGroup::eChessTrigger);


#pragma endregion



	lstrcpy(tObj.tagMesh, L"GroundBounce1");
	tObj.vPos = { 0.f,0.f,0.f };
	pGameObject = CGroundBounce::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Bounce1", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eCrusher, FilterGroup::eCody | FilterGroup::eMay);
	pGameObject->Is<CGroundBounce>()->Set_Dir({ 0.f,-1.f,0.f });
	pGameObject->Is<CGroundBounce>()->Set_Dist(3.1f);
	pGameObject->Is<CGroundBounce>()->Set_Duration(0.2f);

	//#�����ؾ���
	lstrcpy(tObj.tagMesh, L"GroundBounce2");
	tObj.vPos = { 0.f,0.1f,0.f };
	pGameObject = CGroundBounce::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Bounce2", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eCrusher, FilterGroup::eCody | FilterGroup::eMay);
	pGameObject->Is<CGroundBounce>()->Set_Dir({ 0.f,1.f,0.f });
	pGameObject->Is<CGroundBounce>()->Set_Dist(4.f);
	pGameObject->Is<CGroundBounce>()->Set_Duration(0.5f);

	tObj.vPos = { 0.f,0.f,0.f };
	lstrcpy(tObj.tagMesh, L"GroundBounce3");
	pGameObject = CGroundBounce::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Bounce3", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eCrusher, FilterGroup::eCody | FilterGroup::eMay);
	pGameObject->Is<CGroundBounce>()->Set_Dir({ 0.f,-1.f,0.f });
	pGameObject->Is<CGroundBounce>()->Set_Dist(8.15f);
	pGameObject->Is<CGroundBounce>()->Set_Duration(1.f);

	tObj.vPos = { 222.6f,23.81f,-1.49f };
	tObj.vAngle = { 0.f,-90.f,0.f };

	pGameObject = CGroundBouncePanel::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"GroundBouncePanel", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eGround, FilterGroup::eCody | FilterGroup::eMay);


	tObj.vPos = { 278.7f,18.4f,-1.f };
	tObj.vAngle = { 0.f,90.f,0.f };
	pGameObject = CSpaceCup::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceCup", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eCrusher, FilterGroup::eCody | FilterGroup::eMay);

	tObj.vPos = { 271.8f,13.4f,-0.3f };
	tObj.vAngle = { 0.f,0.f,0.f };
	tObj.vTriggerPos = { 271.8f,16.4f,-0.3f };
	tObj.vTriggerScale = { 3.0f,3.0f,1.0f };
	pGameObject = CSpaceWall::Create(m_pGraphicDev, _vec3(269.814f, 13.451f, -1.316f), _vec3(270.044f, 18.431f, -1.316f), &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceWall", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eRideObj, FilterGroup::eCody | FilterGroup::eMay);

	tObj.vPos = { 69.5f,23.5f,-1.f };
	pGameObject = CSpacePlatform::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpacePlatform", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eRideObj, FilterGroup::eCody | FilterGroup::eMay);

	tObj.vPos = { 69.5f,24.2f,-1.f };
	tObj.vTriggerPos = { 69.5f,24.2f,-1.f };
	tObj.vTriggerScale = { 3.0f,3.0f,3.0f };
	tObj.vAngle = _vec3(D3DXToRadian(45.0f), D3DXToRadian(90.0f), 0.0f);
	pGameObject = CSpaceLever::Create(m_pGraphicDev, _vec3(0.0f, 0.0f, -1.0f), _vec3(69.5524f, 23.905f, -0.25f), TRIGGER_LEVER_CODY, &tObj);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceLever", pGameObject, this), E_FAIL);

	tObj.vPos = { 69.5f,22.7f,-1.f };
	tObj.vTriggerPos = { 69.5f,22.7f,-1.f };
	tObj.vTriggerScale = { 3.0f,3.0f,3.0f };
	tObj.vAngle = _vec3(D3DXToRadian(225.0f), D3DXToRadian(90.0f), 0.0f);
	pGameObject = CSpaceLever::Create(m_pGraphicDev, _vec3(0.0f, 0.0f, 1.0f), _vec3(69.5524f, 24.005f, -0.1121f), TRIGGER_LEVER_MAY, &tObj);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceLever2", pGameObject, this), E_FAIL);

	tObj.vPos = { 69.5f,28.5f,-1.f };
	pGameObject = CSpacePlatformWall::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MoveWall1", pGameObject, this), E_FAIL);

	tObj.vPos = { 69.5f,17.5f,-1.f };
	pGameObject = CSpacePlatformWall::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MoveWall2", pGameObject, this), E_FAIL);


	tObj.vPos = { 89.5f,28.5f,-1.f };
	pGameObject = CSpacePlatformWall::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MoveWall3", pGameObject, this), E_FAIL);

	tObj.vPos = { 89.5f,17.5f,-1.f };
	pGameObject = CSpacePlatformWall::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MoveWall4", pGameObject, this), E_FAIL);

	tObj.vPos = { 250.8f,19.4f,1.5f };
	tObj.vAngle = { 0.f,90.f,0.f };
	tObj.vScale = { 0.03f,0.03f,0.03f };
	tObj.vTriggerPos = { 250.8f,19.4f,1.5f };
	tObj.vTriggerScale = { 3.0f, 3.0f, 3.0f };
	pGameObject = CSpaceValve::Create(m_pGraphicDev, _vec3(250.47f, 12.636f, -1.09f), _vec3(0.0f, 0.0f, 1.0f), L"SpaceValve", &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceValve", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eRideObj, FilterGroup::eCody | FilterGroup::eMay);

	tObj.vScale = { 0.1f,0.1f,0.1f };

	lstrcpy(tObj.tagMesh, L"SpacePlatform");
	tObj.vScale = _vec3{ 0.01f,0.01f,0.01f };
	tObj.vAngle = { 0, 0.f, 0.f };

	tObj.eMeshType = 1;
	tObj.eRenderType = RENDER_NONALPHA;
	tObj.vPos = { 0.f,0.f,0.f };
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Panel");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field2", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Gravity");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field3", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"GravityCorner");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field4", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Background");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field5", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Alpha");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Field6", pGameObject, this), E_FAIL);

	m_mapLayer.emplace(pLayerTag, pLayer);


	return S_OK;
}

HRESULT CSpaceField2::Ready_LightInfo(void)
{
	D3DLIGHT9				tLightInfo;
	ZeroMemory(&tLightInfo, sizeof(D3DLIGHT9));

	tLightInfo.Type = D3DLIGHT_DIRECTIONAL;
	tLightInfo.Diffuse = D3DXCOLOR(1.f, 1.f, 1.f, 1.f);
	tLightInfo.Specular = D3DXCOLOR(1.f, 1.f, 1.f, 1.f);
	tLightInfo.Ambient = D3DXCOLOR(0.3f, 0.3f, 0.3f, 1.f);
	tLightInfo.Direction = _vec3(-1.f, -1.f, 1.f);

	FAILED_CHECK_RETURN(Engine::Ready_Light(m_pGraphicDev, &tLightInfo, 0), E_FAIL);

	return S_OK;
}

CSpaceField2 * CSpaceField2::Create(LPDIRECT3DDEVICE9 pGraphicDev)
{
	CSpaceField2*		pInstance = new CSpaceField2(pGraphicDev);

	if (FAILED(pInstance->Ready_Scene()))
		Safe_Release(pInstance);

	return pInstance;
}

void CSpaceField2::Free(void)
{
	// ����

	for (_uint i = 0; i < m_vecObject.size(); ++i)
		Safe_Delete_Array(m_vecObject[i]);

	m_vecObject.clear();
	m_vecObject.shrink_to_fit();
	Engine::Delete_AllResource(RESOURCE_SF2);
	Engine::CScene::Free();
}


HRESULT CSpaceField2::Ready_Valve_Layer(const _tchar* szLayer)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_SF2;
	// ������Ʈ �߰�
	tObj.vPos = { 0.f,0.f ,0.f };
	tObj.vScale = { 0.01f,0.01f ,0.01f };
	Engine::CGameObject*		pGameObject = nullptr;
	Engine::CGameObject*		pButton = nullptr;

	tObj.vPos = { 263.35f,35.5f,-0.3f };
	tObj.vAngle = { 0.f,90.f,180.f };
	tObj.vScale = { 0.01f, 0.01f ,0.01f };
	pGameObject = CSpaceValveSpring::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceSpring", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eRideObj, FilterGroup::eCody | FilterGroup::eMay);

	m_mapLayer.emplace(szLayer, pLayer);

	return S_OK;
}

HRESULT CSpaceField2::Ready_Interact_Layer(const _tchar* szLayer)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_SF2;
	// ������Ʈ �߰�
	tObj.vPos = { 0.f,0.f ,0.f };
	tObj.vScale = { 0.01f,0.01f ,0.01f };
	Engine::CGameObject*		pGameObject = nullptr;
	Engine::CGameObject*		pButton = nullptr;

	//pGameObject = CMiniVacuum::Create(m_pGraphicDev, DIRRIGHT, &tObj);
	//NULL_CHECK_RETURN(pGameObject, E_FAIL);
	//FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Minivacuum", pGameObject, this), E_FAIL);

	//pButton = CPowerButton::Create(m_pGraphicDev, &tObj);
	//NULL_CHECK_RETURN(pButton, E_FAIL);
	//FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"PowerButton1", pButton, this), E_FAIL);
	//pButton->Set_InteractObj(pGameObject);


	m_mapLayer.emplace(szLayer, pLayer);

	return S_OK;
}
