#pragma once
#ifndef TriggerView_h__

#include "GameObject.h"
#include "Engine_Define.h"

BEGIN(Engine)

class CShader;

END

class CTriggerView : public CGameObject
{
public:
	explicit CTriggerView(LPDIRECT3DDEVICE9 pGraphicDev);
	virtual ~CTriggerView();

public:
	 HRESULT Ready_Object(TRIGGERTYPE eType, void* pArg = nullptr);
	virtual _int Update_Object(const _float& fTimeDelta) override;
	virtual _int LateUpdate_Object(const _float & TimeDelta) override;
	virtual void Render_Object(const _int& iIndex = 0) override;

public:
	static CGameObject* Create(LPDIRECT3DDEVICE9 pGraphicDev, TRIGGERTYPE eType, void* pArg);

private:
	TRIGGERTYPE m_eTriggerType;
	CTrigger* m_pTrigger;

private:
	class CBoundingBox*	m_pBox = nullptr;
	Engine::CShader* m_pShaderCom = nullptr;

public:
	virtual void Free() override;
};

#define TriggerView_h__
#endif