#include "stdafx.h"
#include "SpaceField.h"
#include "Export_Function.h"
#include "UI.h"
#include "Cody.h"
#include "May.h"
#include "CodyCamera.h"
#include "MayCamera.h"
#include "StaticObject.h"
#include "SpaceField.h"
#include "Map.h"
#include "SceneChangeSpace.h"
#include "DeadSpace.h"
#include "Cody_Space.h"
#include "May_Space.h"
#include "GravityFloor.h"
#include "SpacePowerButton.h"
#include "SpaceBridge.h"
#include "GeneratorBattery.h"
#include "GeneratorLever.h"
#include "PowerButton.h"



CSpaceField::CSpaceField(LPDIRECT3DDEVICE9 pDevice)
	: CScene(pDevice)
{
}

CSpaceField::~CSpaceField()
{
}

HRESULT CSpaceField::Ready_Scene()
{
	Engine::Set_SoundScene(RESOURCE_SF);

	Engine::Start_Split();
	g_bMenu = false;
	g_bSlideFinal = false;
	auto* pPhysics = Engine::Get_Physics();
	auto* pDispatcher = Engine::Get_Dispatcher();
	auto* pCudaMgr = Engine::Get_CudaMgr();
	CScene::Ready_PhysX(this, pPhysics, pDispatcher, pCudaMgr);


	if (!m_pScene)
		return E_FAIL;

	//pPlane->setGlobalPose(PxTransform(0, 0.f, 0));

	auto* pPlane = PxCreatePlane(*pPhysics, PxPlane(0, 1, 0, 1), *pPhysics->createMaterial(0.5f, 0.5f, 0.f));

	pPlane->setName((char*)pPlane);
	setupFiltering(Engine::Get_Allocator(), pPlane, FilterGroup::eGround, FilterGroup::eCody | FilterGroup::eMay);
	m_pScene->addActor(*pPlane);
	m_pScene->setGravity(PxVec3(0.0f, -20.f, 0.0f));
	FAILED_CHECK_RETURN(Ready_Environment_Layer(L"Environment"), E_FAIL);
	FAILED_CHECK_RETURN(Ready_GameObject_Layer(L"GameObject"), E_FAIL);
	FAILED_CHECK_RETURN(Ready_Interact_Layer(L"Interact"), E_FAIL);

	//FAILED_CHECK_RETURN(Ready_LoadMap_Layer(L"LoadObject", L"../../Data/ITT_Test/Test.dat"), E_FAIL);

	if (!Engine::Is_LightExsist())
		Ready_LightInfo();


	return S_OK;
}

_int CSpaceField::Update_Scene(const _float & fTimeDelta)
{
	if (m_bStart)
	{
		
		m_bStart = false;
	}

	m_pScene->simulate(fTimeDelta);

	m_pScene->fetchResults(true);
	_int iExit = Engine::CScene::Update_Scene(fTimeDelta);



	if (Engine::Key_Down(DIK_Y))
	{
		CHANGE_SCENE(m_pGraphicDev, SCENE_SF2, OBJ_NOEVENT);

		return 0;
	}
	return iExit;
}

_int CSpaceField::LateUpdate_Scene(const _float & fTimeDelta)
{
	_int iExit = Engine::CScene::LateUpdate_Scene(fTimeDelta);

	return iExit;
}

void CSpaceField::Render_Scene()
{

}

void CSpaceField::onConstraintBreak(PxConstraintInfo* constraints, PxU32 count)
{

	return;
}

void CSpaceField::onWake(PxActor** actors, PxU32 count)
{
	OutputDebugString(L"����");
	return;
}

void CSpaceField::onSleep(PxActor** actors, PxU32 count)
{
	OutputDebugString(L"���");

	return;
}

void CSpaceField::onContact(const PxContactPairHeader& pairHeader, const PxContactPair* pairs, PxU32 nbPairs)
{
	OutputDebugString(L"�浹����\n");
	for (PxU32 i = 0; i < nbPairs; ++i)
	{

		/*if ((!strcmp(pairHeader.actors[0]->getName(), "Cody") && !strcmp(pairHeader.actors[1]->getName(), "Wall")) ||
			(!strcmp(pairHeader.actors[1]->getName(), "Cody") && !strcmp(pairHeader.actors[0]->getName(), "Wall")))
		{
			Engine::Get_GameObject(L"GameObject", L"Cody")->Is<CCody>()->Set_Climbing(true);
		}*/

	}
}

void CSpaceField::onTrigger(PxTriggerPair* pairs, PxU32 count)
{
	for (PxU32 i = 0; i < count; ++i)
	{
		if (pairs[i].triggerShape->getSimulationFilterData().word0 == FilterGroup::eWall &&
			pairs[i].otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
		{
			pairs[i].triggerActor->getGlobalPose();
			CCody* pCody = (CCody*)Engine::Get_GameObject(L"GameObject", L"Cody");
		}
		auto Trigger = pairs[i];
		if (Trigger.otherShape->getSimulationFilterData().word0 &(FilterGroup::eCody | FilterGroup::eMay))
		{
			auto* pTrigger = ToTrigger(Trigger.triggerShape->getName());
			if (Trigger.status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
				pTrigger->Set_Active(true);
			else if (Trigger.status == PxPairFlag::eNOTIFY_TOUCH_LOST)
				pTrigger->Set_Active(false);


			if (!pTrigger)
				return;
			switch (pTrigger->Get_Type())
			{
			case TRIGGER_SCENE_CHANGE:
				Event_Scene_Change(&Trigger);
				break;
			case TRIGGER_SPACE_GENERATOR_BATTERY:
				Event_Generator_Battery(&Trigger);
				break;
			case TRIGGER_SPACE_GENERATOR_LEVER:
				Event_Generator_Lever(&Trigger);
				break;
			case TRIGGER_SPACE_GRAVITY_FLY:
				Event_Gravity_Fly(&Trigger);
			default:
				break;
			}


		}
	}
}

void CSpaceField::onAdvance(const PxRigidBody*const* bodyBuffer, const PxTransform* poseBuffer, const PxU32 count)
{
	OutputDebugString(L"������Ʈ");
}


void CSpaceField::Event_Scene_Change(PxTriggerPair* pairs)
{
	ToTrigger(pairs->triggerActor->getName())->Activate();
}

void CSpaceField::Event_Gravity_Fly(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());

	_bool bBatteryMoveEnd;
	_bool bLeverMoveEnd;
	CGeneratorBattery*	pBattery = (CGeneratorBattery*)Engine::Get_GameObject(L"GameObject", L"GeneratorBattery");
	CGeneratorLever*	pLever = (CGeneratorLever*)Engine::Get_GameObject(L"GameObject", L"GeneratorLever");

	bBatteryMoveEnd = pBattery->Get_MoveEnd();
	bLeverMoveEnd = pLever->Get_MoveEnd();

	if (bBatteryMoveEnd && bLeverMoveEnd)
	{
		if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
		{
			//
			OutputDebugString(L"�ڵ� �ö󰡱� ����");
		}
		else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
		{
			OutputDebugString(L"���� �ö󰡱� ����");
		}
	}
}

void CSpaceField::Event_Gravity_FlyBossRoom(PxTriggerPair * pairs)
{

}

void CSpaceField::Event_Generator_Battery(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());
	CGeneratorBattery*		pBattery = pTrigger->Is<CGeneratorBattery>();

	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		CCody_Space* pCody = ToObj<CCody_Space>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pCody, );

		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
		{
			OutputDebugString(L"�ڵ� ���͸��� ���� �� ����");
			pCody->Set_Push(true, pBattery, pBattery->Get_Push_StartPos(), CCody_Space::GENERATOR_BATTERY);
		}
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
		{
			pCody->Set_Push(false);
		}
	}
}

void CSpaceField::Event_Generator_Lever(PxTriggerPair * pairs)
{
	auto* pTrigger = ToTrigger(pairs->triggerShape->getName());
	CGeneratorLever*	pLever = pTrigger->Is<CGeneratorLever>();

	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	{
		CMay_Space* pMay = ToObj<CMay_Space>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pMay, );

		if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
		{
			OutputDebugString(L"���̰� ������ ���� �� ����");
			pMay->Set_Push(true, pLever, pLever->Get_Push_StartPos(), CMay_Space::GENERATOR_LEVER);
			//pMay->Set_PickUp(true, CMay_Space::GENERATOR_LEVER, pLever);
		}
		else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
		{
			pMay->Set_Push(false);
			//pMay->Set_PickUp(false, CMay_Space::GENERATOR_LEVER, nullptr);
		}
	}

}


void CSpaceField::Event_Bounce_Switch(PxTriggerPair* pairs)
{

}



void CSpaceField::Event_Float(PxTriggerPair* pairs)
{
	//CFan* pFan = ToTrigger(pairs->triggerShape->getActor()->getName())->Is<CFan>();
	//_float3 vPos = ToTrigger(pairs->triggerShape->getActor()->getName())->Get_Pos();
	//NULL_CHECK_RETURN(pFan, );

	//if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	//{
	//	CCody* pCody = ToObj<CCody>(pairs->otherShape->getName());
	//	NULL_CHECK_RETURN(pCody, );

	//	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	//		pCody->Set_Float(true, pFan->Get_Up(), pFan, vPos, 20.f);

	//	else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
	//		pCody->Set_Float(false, pFan->Get_Up(), nullptr, vPos);
	//}
	//else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	//{
	//	CMay* pMay = (CMay*)Engine::Get_GameObject(L"GameObject", L"May");
	//	NULL_CHECK_RETURN(pMay, );

	//	if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_FOUND)
	//		pMay->Set_Float(true, pFan->Get_Up(), pFan, vPos, 20.f);

	//	else if (pairs->status == PxPairFlag::eNOTIFY_TOUCH_LOST)
	//		pMay->Set_Float(false, pFan->Get_Up(), nullptr, vPos);
	//}
}

void CSpaceField::Event_Dead(PxTriggerPair * pairs)
{
	if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eCody)
	{
		CCody* pCody = ToObj<CCody>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pCody, );

		pCody->Set_PlayerDead();
	}
	else if (pairs->otherShape->getSimulationFilterData().word0 == FilterGroup::eMay)
	{
		CMay* pMay = ToObj<CMay>(pairs->otherShape->getName());
		NULL_CHECK_RETURN(pMay, );
		pMay->Set_PlayerDead();
	}
}

HRESULT CSpaceField::Ready_Environment_Layer(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;

	OBJINFO tInfo;
	_int iX = 0, iY = 0, iZ = 0, iScale = 0;


	m_mapLayer.emplace(pLayerTag, pLayer);
	return S_OK;
}
//#��������	�����̽� �ʵ�
HRESULT CSpaceField::Ready_GameObject_Layer(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_SF;
	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;

	//�� ü����
	pGameObject = CSceneChangeSpace::Create(m_pGraphicDev, SCENE_SF2, { 193.5f, 99.1f, 24.f }, 2.f,2.f,0.5f, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SceneChange_SF_To_SF2", pGameObject, this), E_FAIL);

	pGameObject = CSceneChangeSpace::Create(m_pGraphicDev, SCENE_SF3, { 193.5f, 99.1f, -24.f }, 2.f, 2.f, 0.5f, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SceneChange_SF_To_SF3", pGameObject, this), E_FAIL);




	tObj.vScale = { 0.01f, 0.01f ,0.01f };

	// CodyCamera
	pGameObject = CCodyCamera::Create(m_pGraphicDev, &_vec3(0.f, 10.f, -5.f), &_vec3(0.f, 0.f, 1.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"CodyCamera", pGameObject, this), E_FAIL);

	// MayCamera
	pGameObject = CMayCamera::Create(m_pGraphicDev, &_vec3(0.f, 10.f, -5.f), &_vec3(0.f, 0.f, 1.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MayCamera", pGameObject, this), E_FAIL);
	
	
	
	
	//pGameObject->Is<CMayCamera>()->Set_FreeMode();

	//780.886, 10794.9, 2694.33
	tObj.vPos = { 97.97f,22.59f,37.8f };//��������
	tObj.vPos = { 7.8f,26.9f,107.19f };//��ó��
	tObj.vPos = { 175.f,50.f, -7.f };

	//tObj.vPos = { 0.f,5.f,0.f };

	//tObj.vPos = { 175.f,150.f, -7.f };


	pGameObject = CCody_Space::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Cody", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eCody, FilterGroup::eGround | FilterGroup::eWall);


	pGameObject = CMay_Space::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"May", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eMay, FilterGroup::eGround | FilterGroup::eWall);

	lstrcpy(tObj.tagMesh, L"Gravity_Corner4");
	tObj.vPos = { 0.f,0.f,0.f };
	tObj.vScale = _vec3{ 0.01f,0.01f,0.01f };
	//tObj.vAngle = { 0.f,D3DXToRadian(-90.f),0.f };
	pGameObject = CGravityFloor::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Gravity_Corner", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eGravityFloor, FilterGroup::eCody | FilterGroup::eMay);


	tObj.vPos = { 177.35f, 24.56f, -8.4f };
	tObj.vTriggerScale = { 0.3f, 0.3f, 0.2f };
	tObj.vAngle = { 0.f, 20.f, 0.f };
	_vec3 TriggerPos = tObj.vPos + _vec3(-0.2f, -0.115f, -0.75f);
	_vec3 StartPos = tObj.vPos + _vec3(-0.45f, -0.14f, -0.756f);
	pGameObject = CGeneratorBattery::Create(m_pGraphicDev, &tObj, TriggerPos, StartPos);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"GeneratorBattery", pGameObject, this), E_FAIL);


	tObj.vPos = { 175.f, 23.2f, -8.9f };
	tObj.vTriggerScale = { 1.f, 1.f, 1.f };
	tObj.vAngle = { 0, 25.f, 90.f };
	TriggerPos = tObj.vPos + _vec3(-1.f, -0.f, 0.f);
	StartPos = tObj.vPos + _vec3(-1.f, -0.f, -0.f);
	pGameObject = CGeneratorLever::Create(m_pGraphicDev, &tObj, TriggerPos, StartPos);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"GeneratorLever", pGameObject, this), E_FAIL);


#pragma region �� Ʈ���� ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	m_pTrigger[SpaceTrigger::Trigger_GravityFly] = CTrigger::CreateCapsuleTirgger(m_pScene, L"GravityFly", _vec3(203.f, 40.f, 0.f), 15.f, 30.f, TRIGGER_SPACE_GRAVITY_FLY, FilterGroup::eDefaultTrigger);
	m_pTrigger[SpaceTrigger::Trigger_GravityFly]->Set_Rotation(_vec3(0.f, 0.f, D3DXToRadian(90.f)));

	m_pTrigger[SpaceTrigger::Trigger_GravityFly_BossRoom] = CTrigger::CreateCapsuleTirgger(m_pScene, L"GravityFly_BossRoom", _vec3(203.f, 100.f, 0.f), 15.f, 30.f, TRIGGER_SPACE_GRAVITY_FLY, FilterGroup::eDefaultTrigger);
	m_pTrigger[SpaceTrigger::Trigger_GravityFly_BossRoom]->Set_Rotation(_vec3(0.f, 0.f, D3DXToRadian(90.f)));
#pragma  endregion


	tObj.vScale = _vec3{ 0.01f,0.01f,0.01f };
	tObj.vAngle = { 0, 0.f, 0.f};
	tObj.eMeshType = 1;
	tObj.eRenderType = RENDER_NONALPHA;
	tObj.vPos = { 0.f,0.f,0.f };

	

	lstrcpy(tObj.tagMesh, L"SpaceFloor");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceFloor", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Gravity_Straight");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Gravity_Straight", pGameObject, this), E_FAIL);



	lstrcpy(tObj.tagMesh, L"SpaceTutorial");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceTutorial", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Generator");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Generator", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"SpaceWindow");
	tObj.eRenderType = RENDER_ALPHA;
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	//static_cast<CMap*>(pGameObject)->Set_PassIndex(14);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceWindow", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"Lamp");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Lamp", pGameObject, this), E_FAIL);

	lstrcpy(tObj.tagMesh, L"DoorWindow");
	pGameObject = CMap::Create(m_pGraphicDev, &tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"DoorWindow", pGameObject, this), E_FAIL);







	m_mapLayer.emplace(pLayerTag, pLayer);


	return S_OK;
}

HRESULT CSpaceField::Ready_LightInfo(void)
{
	D3DLIGHT9				tLightInfo;
	ZeroMemory(&tLightInfo, sizeof(D3DLIGHT9));

	tLightInfo.Type = D3DLIGHT_DIRECTIONAL;
	tLightInfo.Diffuse = D3DXCOLOR(1.f, 1.f, 1.f, 1.f);
	tLightInfo.Specular = D3DXCOLOR(1.f, 1.f, 1.f, 1.f);
	tLightInfo.Ambient = D3DXCOLOR(0.3f, 0.3f, 0.3f, 1.f);
	tLightInfo.Direction = _vec3(-1.f, -1.f, 1.f);

	FAILED_CHECK_RETURN(Engine::Ready_Light(m_pGraphicDev, &tLightInfo, 0), E_FAIL);

	return S_OK;
}

CSpaceField * CSpaceField::Create(LPDIRECT3DDEVICE9 pGraphicDev)
{
	CSpaceField*		pInstance = new CSpaceField(pGraphicDev);

	if (FAILED(pInstance->Ready_Scene()))
		Safe_Release(pInstance);

	return pInstance;
}

void CSpaceField::Free(void)
{
	// ����

	for (_uint i = 0; i < m_vecObject.size(); ++i)
		Safe_Delete_Array(m_vecObject[i]);

	m_vecObject.clear();
	m_vecObject.shrink_to_fit();
	Engine::Delete_AllResource(RESOURCE_SF);
	Engine::CScene::Free();
}


HRESULT CSpaceField::Ready_Interact_Layer(const _tchar* szLayer)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	OBJINFO tObj;
	ZeroMemory(&tObj, sizeof(OBJINFO));
	tObj.eSceneID = RESOURCE_SF;
	// ������Ʈ �߰�
	tObj.vPos = {0.f,0.f ,0.f };
	tObj.vScale = { 0.01f,0.01f ,0.01f };
	Engine::CGameObject*		pGameObject = nullptr;
	Engine::CGameObject*		pButton = nullptr;
	

	tObj.vPos = { 66.f,0.f,0.f };
	tObj.vScale = _vec3{ 0.01f,0.01f,0.01f };
	//tObj.vAngle = { 0.f,D3DXToRadian(-90.f),0.f };
	pButton = CSpacePowerButton::Create(m_pGraphicDev, &tObj,2);
	NULL_CHECK_RETURN(pButton, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceBridgeButton", pButton, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pButton->Get_RigidActor(), FilterGroup::eButton, FilterGroup::eCody | FilterGroup::eMay);

	tObj.vPos = { 150.f,16.99f,0.f };
	tObj.vAngle = { 0.f,0.f,60.f };
	pGameObject = CSpaceBridge::Create(m_pGraphicDev,&tObj);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"SpaceBridge", pGameObject, this), E_FAIL);
	setupFiltering(Engine::Get_Allocator(), pGameObject->Get_RigidActor(), FilterGroup::eGround, FilterGroup::eCody | FilterGroup::eMay);

	pButton->Set_InteractObj(pGameObject);


	m_mapLayer.emplace(szLayer, pLayer);

	return S_OK;
}
