#ifndef __BABOONMISSILE_H__

#include "Player.h"

BEGIN(Engine)

class CStaticMesh;
class CCalculator;
class CCollider;
class CShader;

END

//Bool�� �̿��ؼ� �������������� ���� �ҷ��� ���, True�϶� �÷��̾� �ҷ��� ������ �ɵ�?
class CBaboonMissile : public CPlayer
{

	enum SoundID
	{
		Sound_Effect,
		Sound_End,
	};

private:
	explicit CBaboonMissile(LPDIRECT3DDEVICE9 pGraphicDev);
	virtual ~CBaboonMissile();

public:
	virtual HRESULT Ready_Object(void* pArg = nullptr, CGameObject* pPlayer = nullptr, _bool bTarget = false, _uint iIndex =0);
	virtual _int	Update_Object(const _float& fTimeDelta) override;
	virtual _int	LateUpdate_Object(const _float& fTimeDelta) override;
	virtual void	Render_Object(const _int& iIndex = 0) override;

public :
	_bool			Get_Att() { return m_bAtt; }
private:
	HRESULT			Add_Component(void* pArg);
	HRESULT			SetUp_ConstantTable(LPD3DXEFFECT& pEffect, const _int& iIndex);

private :
	void			Move(const _float& fTimeDelta);
	void			Chase_Move(const _float& fTimeDelta);
	void			Down_Move(const _float& fTimeDelta);
	void			Att_Move(const _float& fTimeDelta); //�÷��̾ �����ϴ� ?
private:
	Engine::CStaticMesh*		m_pMeshCom = nullptr;
	Engine::CCalculator*		m_pCalculatorCom = nullptr;
	Engine::CCollider*			m_pColliderCom = nullptr;
	Engine::CShader*			m_pShaderCom = nullptr;


	CGameObject*				m_pTarget = nullptr;
private:
	_bool						m_bSound[Sound_End] = { false };
	_float						m_fSpeed;

private:
	_bool						m_bChaseMove;
	_bool						m_bDownMove;
	_bool						m_bChange; //ó������, �÷��̾�� �浹. ���߿� ���Ϳ� �浹�ϱ�����.
	_bool						m_bAtt;
	_bool						m_bTarget;
	_bool						m_bPlayerAtt;

	_float						m_fChangeTime; 
	_float						m_fChaseTime;

	_vec3						m_vTargetPos;

	_float						m_fAngle;
	_float						m_fTurnSpeed;
	_float						m_fLifeTime;

	_uint						m_iIndex;

	_bool						m_bStartMissile;

	CTrigger*					m_pTrigger = nullptr;
	
public:
	static CBaboonMissile*				Create(LPDIRECT3DDEVICE9 pGraphicDev, void* pArg = nullptr, CGameObject* pPlayer = nullptr, _bool bTarget = false, _uint iIndex = 0);
	virtual void						Free(void)			override;


};

#define __BABOONMISSILE_H__
#endif

