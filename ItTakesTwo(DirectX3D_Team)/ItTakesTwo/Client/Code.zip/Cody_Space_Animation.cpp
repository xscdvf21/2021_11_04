#include "stdafx.h"
#include "Cody_Space.h"

#include "Export_Function.h"

void CCody_Space::ChangeAnimation(CCody_Space* pCody, CCody_Space::PLAYER_STATE eCurState, CCody_Space::PLAYER_STATE* ePreState, Engine::CDynamicMesh* pMesh)
{
	switch (eCurState)
	{
	case CCody_Space::PL_IDLE:
		PlayIdle(pMesh, ePreState);
		break;
	case CCody_Space::PL_MOVE:
		PlayWalk(pMesh, ePreState);
		break;
	case CCody_Space::PL_JUMP:
		PlayJump(pCody, pMesh);
		break;
	case CCody_Space::PL_SIT:
		PlaySit(pMesh);
		break;
	case CCody_Space::PL_DASH:
		PlayDash(pCody, pMesh);
		break;
	case CCody_Space::PL_RUN:
		PlayRun(pMesh);
		break;
	case CCody_Space::PL_HANG:
		PlayHang(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_SLIDE:
		PlaySlide(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_CLIMBING:
		PlayClimbing(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_PICKUP:
		PlayPickUp(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_RIDE:
		PlayRide(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_LEVER:
		PlayLever(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_FLOAT:
		PlayFloat(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_FALL:
		PlayFall(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_HANGSWITCH:
		PlayHangSwitch(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_PUSH:
		PlayPush(pCody, pMesh, ePreState);
		break;
	case CCody_Space::PL_HANDLE:
		PlayHandle();
		break;
	}
}

void CCody_Space::PlayAnimation(CCody_Space* pCody, CDynamicMesh* pMesh, const _float& fTimeDelta, CCody_Space::PLAYER_STATE eCurState, CCody_Space::PLAYER_STATE* pPreState)
{
	ChangeAnimation(pCody, eCurState, pPreState, pMesh);
	if(m_bPlayAnmation)
		pMesh->Play_Animationset(fTimeDelta);
}

void CCody_Space::PlayIdle(Engine::CDynamicMesh* pMesh, CCody_Space::PLAYER_STATE* pPreState)
{
	if (*pPreState != CCody_Space::PL_IDLE)
	{
		switch (*pPreState)
		{
		case CCody_Space::PL_JUMP:
		{
			m_b2ndJump = false;
			m_b2ndJumpStart = false;
			m_bJumpDash = false;
			m_bJumpDashStart = false;
			m_bGroundPoundStop = false;
			m_eCodyAnim = Cody_Space_Jump_Land;
			pMesh->Set_Animationset(m_eCodyAnim);
			*pPreState = CCody_Space::PL_IDLE;
			break;
		}
		case CCody_Space::PL_SIT:
		{
			m_eCodyAnim = Cody_Space_Crouch_End;
			pMesh->Set_Animationset(m_eCodyAnim, 0.5f);
			*pPreState = CCody_Space::PL_IDLE;
			break;
		}
		case CCody_Space::PL_DASH:
		{
			if (pMesh->Is_AnimationSetEnd(0.15f))
			{
				m_eCodyAnim = Cody_Space_Idle;
				pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
			}
			*pPreState = CCody_Space::PL_IDLE;
			break;
		}
		case CCody_Space::PL_HANGSWITCH:
		{
			m_eCodyAnim = Cody_Space_Idle;
			pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.0f);
			break;
		}
		case CCody_Space::PL_HANG:
		{
			m_eCodyAnim = Cody_Space_Idle;
			pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
			break;
		}
		default:
			m_eCodyAnim = Cody_Space_Idle;
			pMesh->Set_Animationset(Cody_Space_Idle);

			// Dash���� ������ ���ŷӰ� ������ �־���
			*pPreState = CCody_Space::PL_IDLE;
			break;
		}

		return;
	}

	if (pMesh->Is_AnimationSetEnd(0.1f))
	{
		m_eCodyAnim = Cody_Space_Idle;
		pMesh->Set_Animationset(Cody_Space_Idle, 1.0f, 0.1f);
	}
}

void CCody_Space::PlayJump(CCody_Space* pCody, Engine::CDynamicMesh* pMesh)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Jump:
		Jump(pMesh);
		break;
	case Cody_Space_2ndJump:
		SecondJump(pMesh);
		break;
	case Cody_Space_Jump_Fall:
		Jump_Fall(pMesh);
		break;
	case Cody_Space_Jump_Dash:
		Jump_Dash(pCody, pMesh);
		break;
	case Cody_Space_GroundPound_Start:
		GroundPound_Start(pCody, pMesh);
		break;
	case Cody_Space_GroundPound_Fall:
		GroundPound_Fall(pCody, pMesh);
		break;
	case Cody_Space_GroundPound_Land:
		GroundPound_Land(pMesh);
		break;
	case Cody_Space_GroundPound_End:
		GroundPound_End(pCody, pMesh);
		break;
	}
}

void CCody_Space::PlayWalk(Engine::CDynamicMesh* pMesh, CCody_Space::PLAYER_STATE* pPreState)
{
	if (*pPreState != CCody_Space::PL_MOVE)
	{
		switch (*pPreState)
		{
		case CCody_Space::PL_SIT:
			m_eCodyAnim = Cody_Space_Crouch_Walk_End;
			pMesh->Set_Animationset(m_eCodyAnim);

			*pPreState = CCody_Space::PL_MOVE;
			break;
		case CCody_Space::PL_JUMP:
		{
			m_b2ndJump = false;
			m_b2ndJumpStart = false;
			m_bJumpDash = false;
			m_bJumpDashStart = false;
			m_bGroundPoundStop = false;
			m_eCodyAnim = Cody_Space_Jump_Land;

			*pPreState = CCody_Space::PL_MOVE;
			pMesh->Set_Animationset(m_eCodyAnim);
			break;
		}
		case CCody_Space::PL_DASH:
		{
			if (pMesh->Is_AnimationSetEnd(0.1f))
			{
				m_eCodyAnim = Cody_Space_Walk;
				pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.05f);
			}
			break;
		}
		default:
			m_eCodyAnim = Cody_Space_Walk;
			pMesh->Set_Animationset(m_eCodyAnim);

			// �뽬 ������ ������ �־���
			*pPreState = CCody_Space::PL_MOVE;
			break;
		}

		return;
	}

	if (pMesh->Is_AnimationSetEnd(0.3f))
	{
		m_eCodyAnim = Cody_Space_Walk;
		pMesh->Set_Animationset(m_eCodyAnim);
	}

}

void CCody_Space::PlayDash(CCody_Space* pCody, Engine::CDynamicMesh* pMesh)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Dash_Start:
	{
		if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			m_eCodyAnim = Cody_Space_Dash_End;
			pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		}
		break;
	}
	case Cody_Space_Dash_End:
	{
		if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			pCody->Clear(CPlayerValue::PL_DASH);
		}
		break;
	}
	default:
		pCody->Set_Dash(CCody_Space::PL_1STDASH);
		m_eCodyAnim = Cody_Space_Dash_Start;
		pMesh->Set_Animationset(m_eCodyAnim);
		break;
	}
}

void CCody_Space::PlaySit(Engine::CDynamicMesh* pMesh)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Crouch_Start:
		Crouch_Start(pMesh);
		break;
	case Cody_Space_Crouch_Walk_Start:
		Crouch_Walk_Start(pMesh);
		break;
	case Cody_Space_Crouch_Idle:
		Crouch_Idle(pMesh);
		break;
	case Cody_Space_Crouch_Walk:
		Crouch_Walk(pMesh);
		break;
	case Cody_Space_Walk:
		m_eCodyAnim = Cody_Space_Crouch_Walk_Start;
		pMesh->Set_Animationset(m_eCodyAnim, 0.5f);
		break;
	default:
		m_eCodyAnim = Cody_Space_Crouch_Start;
		pMesh->Set_Animationset(m_eCodyAnim, 0.5f);
		break;
	}
}

void CCody_Space::PlayRun(Engine::CDynamicMesh * pMesh)
{
	m_eCodyAnim = Cody_Space_Run;
	pMesh->Set_Animationset(m_eCodyAnim);
}

void CCody_Space::PlayClimbing(CCody_Space* pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE* pPreState)
{
	if (*pPreState != CCody_Space::PL_CLIMBING)
	{
		switch (*pPreState)
		{
		case CCody_Space::PL_JUMP:
			m_b2ndJump = false;
			m_b2ndJumpStart = false;
			m_bJumpDash = false;
			m_bJumpDashStart = false;
			m_bGroundPoundStop = false;
			*pPreState = CCody_Space::PL_CLIMBING;
			break;
		}
	}

	switch (m_eCodyAnim)
	{
	case Cody_Space_Wall_Idle:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (m_bClimbingJump)
		{
			m_eCodyAnim = Cody_Space_Wall_Jump;
		}
		break;
	case Cody_Space_Wall_Jump:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);

		if (m_bClimbingJumpEnd)
		{
			m_bClimbingJumpEnd = false;
			m_eCodyAnim = Cody_Space_Wall_Idle;
		}
		else if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			m_eCodyAnim = Cody_Space_Jump_Fall;
		}
		break;
	case Cody_Space_Jump_Fall:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
		if (m_bClimbingJumpEnd)
		{
			m_bClimbingJumpEnd = false;
			m_eCodyAnim = Cody_Space_Wall_Idle;
		}
		break;
	default:
		m_eCodyAnim = Cody_Space_Wall_Idle;
		break;
	}
}

void CCody_Space::PlayHang(CCody_Space * pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE * pPreState)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Ledge_Start:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_Ledge_Idle;
		break;
	case Cody_Space_Ledge_Idle:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
		if (m_bRise)
		{
			m_bRise = false;
			m_eCodyAnim = Cody_Space_Ledge_ClimbUp;
		}
		break;
	case Cody_Space_Ledge_Drop:
		break;
	case Cody_Space_Ledge_ClimbUp:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			m_bEndRise = true;
			Set_Pos("Align", m_fTimeDelta);
		}
		break;
	case Cody_Space_Ledge_ClimbLeft:
		break;
	case Cody_Space_Ledge_ClimbRight:
		break;
	default:
		m_eCodyAnim = Cody_Space_Ledge_Start;
		break;
	}
}
void CCody_Space::PlaySlide(CCody_Space* pCody, Engine::CDynamicMesh* pMesh, CCody_Space::PLAYER_STATE* ePreState)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Hose_Inside:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (pCody->Get_SlideEnd())
			m_eCodyAnim = Cody_Space_Hose_BlowOut;
		break;
	case Cody_Space_Hose_BlowOut:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_Fall;
		break;
	case Cody_Space_Fall:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.08f);
		break;
	default:
		m_eCodyAnim = Cody_Space_Hose_Inside;
		break;
	}
}

void CCody_Space::PlayRide(CCody_Space * pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE * ePreState)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Jump:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (pCody->Get_RideEnd())
			m_eCodyAnim = Cody_Space_Hose_Start;
		else if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_Jump_Fall;
		break;
	case Cody_Space_Jump_Fall:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (pCody->Get_RideEnd() && !pCody->Get_TakeOff())
			m_eCodyAnim = Cody_Space_Hose_Start;
		break;
	case Cody_Space_Hose_Start:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_Hose_Idle;
		break;
	case Cody_Space_Hose_Idle:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.09f);
		if (m_bTakeOff)
			m_eCodyAnim = Cody_Space_Hose_End;
		else if (pCody->Click_Left())
			m_eCodyAnim = Cody_Space_Hose_Left;
		else if (pCody->Click_Right())
			m_eCodyAnim = Cody_Space_Hose_Right;
		break;
	case Cody_Space_Hose_Up:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (m_bTakeOff)
			m_eCodyAnim = Cody_Space_Hose_End;
		else if (!pCody->Click_Down())
			m_eCodyAnim = Cody_Space_Hose_Idle;
		break;
	case Cody_Space_Hose_Left:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (m_bTakeOff)
			m_eCodyAnim = Cody_Space_Hose_End;
		else if (!pCody->Click_Left())
			m_eCodyAnim = Cody_Space_Hose_Idle;
		break;
	case Cody_Space_Hose_Right:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (m_bTakeOff)
			m_eCodyAnim = Cody_Space_Hose_End;
		else if (!pCody->Click_Right())
			m_eCodyAnim = Cody_Space_Hose_Idle;
		break;
	case Cody_Space_Hose_End:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			pCody->Set_RideJumpMax();
			m_eCodyAnim = Cody_Space_Jump_Fall;
		}
		break;
	case Cody_Space_Hose_SuckedIn:
		break;
	case Cody_Space_Hose_Inside:
		break;
	case Cody_Space_Hose_BlowOut:
		break;
	default:
		m_eCodyAnim = Cody_Space_Jump;
		break;
	}

	if (true == m_bTakeOff)
		m_bTakeOff = false;
}

void CCody_Space::PlayLever(CCody_Space * pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE * ePreState)
{
	if (m_bSlap)
		PlayLeverSlap();
	else
		PlayLeverGrap();
}
void CCody_Space::PlayHangSwitch(CCody_Space* pCody, Engine::CDynamicMesh* pMesh, CCody_Space::PLAYER_STATE* ePreState)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_PowerSwitch_Start:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_PowerSwitch_Idle;
		break;
	case Cody_Space_PowerSwitch_Idle:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
		pCody->Set_SwitchReady();
		if (m_bHangSwitchSuccess)
			m_eCodyAnim = Cody_Space_PowerSwitch_Success;
		break;
	case Cody_Space_PowerSwitch_Success:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			pCody->Set_Success();

			const D3DXFRAME_DERIVED* pBone = pMesh->Get_FrameByName("Align");
			_matrix matBone = pBone->CombinedTranformationMatrix;
			_matrix matPlayer;
			pCody->Get_Component(L"Com_Transform", ID_DYNAMIC)->Is<CTransform>()->Get_WorldMatrix(&matPlayer);

			_matrix matCombined = matBone * matPlayer;
			pCody->Set_SwitchEndPos(_vec3(matCombined._41, matCombined._42, matCombined._43));
		}
		break;
	case Cody_Space_Jump:
		pMesh->Set_Animationset(m_eCodyAnim, 1.5f, 0.1f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_PowerSwitch_Start;
		break;
	default:
		m_eCodyAnim = Cody_Space_Jump;
		break;
	}
}

void CCody_Space::PlayFloat(CCody_Space * pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE * ePreState)
{
	m_eCodyAnim = Cody_Space_Zerogravity_Idle;
	pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
}

void CCody_Space::PlayFall(CCody_Space * pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE * ePreState)
{
	m_eCodyAnim = Cody_Space_Jump_Fall;
	pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
}

void CCody_Space::PlayPush(CCody_Space * pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE * ePreState)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Push:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		switch (m_ePickUpType)
		{
		case CPlayerValue::GENERATOR_BATTERY:
			if (!pCody->Click_Up())
				m_eCodyAnim = Cody_Space_Push_Idle;
			break;
		case CPlayerValue::SPACE_WALL:
			if (!pCody->Click_Right())
				m_eCodyAnim = Cody_Space_Push_Idle;
			break;
		}
		break;
	case Cody_Space_Push_Idle:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		switch (m_ePickUpType)
		{
		case CPlayerValue::GENERATOR_BATTERY:
			if (pCody->Click_Up())
				m_eCodyAnim = Cody_Space_Push;
			break;
		case CPlayerValue::SPACE_WALL:
			if (pCody->Click_Right())
				m_eCodyAnim = Cody_Space_Push;
			break;
		}
		break;
	default:
		m_eCodyAnim = Cody_Space_Push_Idle;
		break;
	}
}

void CCody_Space::PlayAttach()
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Wall_Idle:
		m_pMeshCom->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (m_bClimbingJump)
		{
			m_eCodyAnim = Cody_Space_Wall_Jump;
		}
		break;
	case Cody_Space_Wall_Jump:
		m_pMeshCom->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);

		if (m_bClimbingJumpEnd)
		{
			m_bClimbingJumpEnd = false;
			m_eCodyAnim = Cody_Space_Wall_Idle;
		}
		else if (m_pMeshCom->Is_AnimationSetEnd(0.1f))
		{
			m_eCodyAnim = Cody_Space_Jump_Fall;
		}
		break;
	case Cody_Space_Jump_Fall:
		m_pMeshCom->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
		if (m_bClimbingJumpEnd)
		{
			m_bClimbingJumpEnd = false;
			m_eCodyAnim = Cody_Space_Wall_Idle;
		}
		break;
	default:
		m_eCodyAnim = Cody_Space_Wall_Idle;
		break;
	}
}

void CCody_Space::PlayHandle()
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Valve_Idle:
		m_pMeshCom->Set_Animationset(m_eCodyAnim);
		if (true == m_bHandleRot)
			m_eCodyAnim = Cody_Space_Valve_RotateRight;
		break;
	case Cody_Space_Valve_RotateRight:
		m_pMeshCom->Set_Animationset(m_eCodyAnim);
		if (false == m_bHandleRot)
			m_eCodyAnim = Cody_Space_Valve_Idle;
		break;
	}
}

void CCody_Space::PlayLeverSlap()
{
	if (Get_LeverStart())
	{
		switch (m_eLever)
		{
		case CCody_Space::LEFT_TO_RIGHT:
			m_eCodyAnim = Cody_Space_LeverLeft;
			m_pMeshCom->Set_Animationset(m_eCodyAnim);
			if (m_pMeshCom->Is_AnimationSetEnd(0.1f))
			{
				Set_Lever(true);
				m_pMeshCom->Set_Animationset(Cody_Space_Idle, 1.0f, 0.1f);
			}
			break;
		case CCody_Space::RIGHT_TO_LEFT:
			m_eCodyAnim = Cody_Space_LeverRight;
			m_pMeshCom->Set_Animationset(m_eCodyAnim);
			if (m_pMeshCom->Is_AnimationSetEnd(0.1f))
			{
				Set_Lever(true);
				m_pMeshCom->Set_Animationset(Cody_Space_Idle, 1.0f, 0.09f);
			}
			break;
		}
	}
	else
	{
		m_pMeshCom->Set_Animationset(Cody_Space_Walk);
	}
}

void CCody_Space::PlayLeverGrap()
{
	//if (false == m_bLeverStart)
	//	return;



	switch (m_eCodyAnim)
	{
	case Cody_Space_LeverLeftToRight:
		if (m_pMeshCom->Is_AnimationSetEnd(0.1f))
		{
			Set_Lever(true);
			m_bPlayAnmation = false;
			//m_pMeshCom->Set_Animationset(Cody_Space_Idle, 1.0f, 0.1f);
		}
		break;
	case Cody_Space_LeverRightToLeft:
		if (m_pMeshCom->Is_AnimationSetEnd(0.1f))
		{
			Set_Lever(true);
			m_bPlayAnmation = false;
			//m_pMeshCom->Set_Animationset(Cody_Space_Idle, 1.0f, 0.09f);
		}
		break;
	}
}

void CCody_Space::PlayPickUp(CCody_Space * pCody, Engine::CDynamicMesh * pMesh, CCody_Space::PLAYER_STATE * pPreState)
{
	switch (m_eCodyAnim)
	{
	case Cody_Space_Pickup:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			m_ePreCodyAnim = Cody_Space_Pickup;
			m_eCodyAnim = Cody_Space_Pickup_Idle;
		}
		break;
	case Cody_Space_Pickup_Idle:
		if (m_bInsert_Fuse)
		{
			pMesh->Set_Animationset(Cody_Space_Pickup_FusePutinSocket);
			m_eCodyAnim = Cody_Space_Pickup_FusePutinSocket;
			m_bInsert_Fuse = false;
			return;
		}
		if (m_ePreCodyAnim == Cody_Space_Pickup)
			pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.01f);
		else
			pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);

		if (m_bPickUpDrop)
		{
			m_bPickUpDrop = false;
			m_eCodyAnim = Cody_Space_Pickup_PutDown;
		}
		else if (pCody->Get_PickUpJump())
			m_eCodyAnim = Cody_Space_Pickup_Jump_Start;
		else if (m_bPickUpMove)
			m_eCodyAnim = Cody_Space_Pickup_Walk;
		break;
	case Cody_Space_Pickup_Walk:
		if (m_bInsert_Fuse)
		{
			pMesh->Set_Animationset(Cody_Space_Pickup_FusePutinSocket);
			m_eCodyAnim = Cody_Space_Pickup_FusePutinSocket;
			m_bInsert_Fuse = false;
			return;
		}
		pMesh->Set_Animationset(Cody_Space_Pickup_Walk);

		if (m_bPickUpDrop)
		{
			m_bPickUpDrop = false;
			m_eCodyAnim = Cody_Space_Pickup_PutDown;
		}
		else if (pCody->Get_PickUpJump())
			m_eCodyAnim = Cody_Space_Pickup_Jump_Start;
		else if (!m_bPickUpMove)
		{
			m_eCodyAnim = Cody_Space_Pickup_Idle;
			m_ePreCodyAnim = Cody_Space_Pickup_Walk;
		}
		break;
	case Cody_Space_Pickup_Jump_Start:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (false == pCody->Get_PickUpJump())
			m_eCodyAnim = Cody_Space_Pickup_Jump_Land;
		else if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_Pickup_Jump_Fall;
		break;
	case Cody_Space_Pickup_Jump_Fall:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (false == pCody->Get_PickUpJump())
			m_eCodyAnim = Cody_Space_Pickup_Jump_Land;
		break;
	case Cody_Space_Pickup_Jump_Land:
		pMesh->Set_Animationset(m_eCodyAnim);
		if (m_bPickUpMove)
			m_eCodyAnim = Cody_Space_Pickup_Walk;
		else if (pMesh->Is_AnimationSetEnd(0.1f))
			m_eCodyAnim = Cody_Space_Pickup_Idle;
		break;
	case Cody_Space_Pickup_PutDown:
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		if (pMesh->Is_AnimationSetEnd(0.1f))
			pCody->Set_PickUpEnd();
		break;
	case Cody_Space_Pickup_FusePutinSocket:
		/*if (pMesh->Is_AnimationSetEnd(0.1f) && !pCody->Get_Insert())
		{
			pCody->Insert_Fuse_End();
		}*/
		if (pMesh->Is_AnimationSetEnd(0.1f))
		{
			pCody->Set_Insert(true);
		}
		break;
	default:
		m_eCodyAnim = Cody_Space_Pickup;
		break;
	}
}


#pragma region Crouch

void CCody_Space::Crouch_Idle(Engine::CDynamicMesh * pMesh)
{
	if (m_bCrouchMove)
	{
		m_eCodyAnim = Cody_Space_Crouch_Walk;
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
	}
	else
	{
		m_eCodyAnim = Cody_Space_Crouch_Idle;
		pMesh->Set_Animationset(m_eCodyAnim);
	}
}


void CCody_Space::Crouch_Walk_Start(Engine::CDynamicMesh * pMesh)
{
	if (pMesh->Is_AnimationSetEnd(0.1f))
	{
		if (m_bCrouchMove)
		{
			m_eCodyAnim = Cody_Space_Crouch_Walk;
			pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		}
		else
		{
			m_eCodyAnim = Cody_Space_Crouch_Idle;
			pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
		}
	}
}

void CCody_Space::Crouch_Walk(Engine::CDynamicMesh * pMesh)
{
	if (!m_bCrouchMove)
	{
		m_eCodyAnim = Cody_Space_Crouch_Idle;
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
	}
}

void CCody_Space::Crouch_Start(Engine::CDynamicMesh * pMesh)
{
	if (pMesh->Is_AnimationSetEnd(0.1f))
	{
		m_eCodyAnim = Cody_Space_Crouch_Idle;
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
	}
}

#pragma endregion Crouch
#pragma region Jump
void CCody_Space::Jump(Engine::CDynamicMesh * pMesh)
{
	pMesh->Set_Animationset(m_eCodyAnim);
	if (m_bJump[PL_GROUNDPOUND_START])
	{
		m_eCodyAnim = Cody_Space_GroundPound_Start;
		pMesh->Set_Animationset(m_eCodyAnim);
		return;
	}
	else if (m_bJumpDash && !m_bJumpDashStart)
	{
		m_bJumpDashStart = true;
		m_eCodyAnim = Cody_Space_Jump_Dash;
		pMesh->Set_Animationset(m_eCodyAnim, 2.0f, 0.1f);
		return;
	}

	else if (!m_b2ndJumpStart && m_b2ndJump)
	{
		m_b2ndJumpStart = true;
		m_eCodyAnim = Cody_Space_2ndJump;
		pMesh->Set_Animationset(m_eCodyAnim);
		return;
	}

	if (pMesh->Is_AnimationSetEnd(0.3f))
		m_eCodyAnim = Cody_Space_Jump_Fall;
}

void CCody_Space::Jump_Fall(Engine::CDynamicMesh * pMesh)
{
	if (m_bJump[PL_GROUNDPOUND_START])
	{
		m_eCodyAnim = Cody_Space_GroundPound_Start;
		pMesh->Set_Animationset(m_eCodyAnim);
		return;
	}
	else if (m_bJumpDash && !m_bJumpDashStart)
	{
		m_bJumpDashStart = true;
		m_eCodyAnim = Cody_Space_Jump_Dash;
		pMesh->Set_Animationset(m_eCodyAnim, 2.0f, 0.1f);
		return;
	}
	else if (!m_b2ndJumpStart && m_b2ndJump)
	{
		m_b2ndJumpStart = true;
		m_eCodyAnim = Cody_Space_2ndJump;
		pMesh->Set_Animationset(m_eCodyAnim);
		return;
	}

	m_eCodyAnim = Cody_Space_Jump_Fall;
	pMesh->Set_Animationset(m_eCodyAnim);
}

void CCody_Space::Jump_Dash(CCody_Space* pCody, Engine::CDynamicMesh * pMesh)
{
	if (pMesh->Is_AnimationSetEnd(0.1f))
	{
		pCody->Set_JumpDashStop();
		m_eCodyAnim = Cody_Space_Jump_Fall;
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.08f);
	}
}

void CCody_Space::SecondJump(Engine::CDynamicMesh * pMesh)
{
	if (m_bJump[PL_GROUNDPOUND_START])
	{
		m_eCodyAnim = Cody_Space_GroundPound_Start;
		pMesh->Set_Animationset(m_eCodyAnim);
		return;
	}
	else if (m_bJumpDash && !m_bJumpDashStart)
	{
		m_bJumpDashStart = true;
		m_eCodyAnim = Cody_Space_Jump_Dash;
		pMesh->Set_Animationset(m_eCodyAnim, 2.0f, 0.1f);
		return;
	}
	else if (pMesh->Is_AnimationSetEnd(0.1f))
		m_eCodyAnim = Cody_Space_Jump_Fall;
}

void CCody_Space::GroundPound_Start(CCody_Space* pCody, Engine::CDynamicMesh * pMesh)
{
	if (pMesh->Is_AnimationSetEnd(0.1f))
	{
		pCody->Set_Jump(CCody_Space::PL_GROUNDPOUND, true);
		m_eCodyAnim = Cody_Space_GroundPound_Fall;
		pMesh->Set_Animationset(m_eCodyAnim, 1.0f, 0.1f);
	}
}

void CCody_Space::GroundPound_Fall(CCody_Space* pCody, Engine::CDynamicMesh * pMesh)
{
	if (m_bGroundPoundStop)
	{
		m_eCodyAnim = Cody_Space_GroundPound_Land;
		pMesh->Set_Animationset(m_eCodyAnim);
	}
}

void CCody_Space::GroundPound_Land(Engine::CDynamicMesh * pMesh)
{
	if (pMesh->Is_AnimationSetEnd(0.1f))
	{
		m_eCodyAnim = Cody_Space_GroundPound_End;
		pMesh->Set_Animationset(m_eCodyAnim);
	}
}

void CCody_Space::GroundPound_End(CCody_Space* pCody, Engine::CDynamicMesh * pMesh)
{
	if (pMesh->Is_AnimationSetEnd(0.1f))
	{
		m_eCodyAnim = Cody_Space_GroundPound_End;
		pMesh->Set_Animationset(m_eCodyAnim);
		pCody->Set_Jump(CCody_Space::PL_GROUNDPOUND_STOP);

		m_b2ndJump = false;
		m_b2ndJumpStart = false;
		m_bJumpDash = false;
		m_bJumpDashStart = false;
		m_bGroundPoundStop = false;
	}
}


#pragma endregion Jump

void CCody_Space::Set_Insert_Fuse()
{
	m_bInsert_Fuse = true;
}

void CCody_Space::Set_ClearJump()
{
	m_b2ndJumpStart = false;
	m_b2ndJump = false;
	m_bJumpDash = false;
	m_bJumpDashStart = false;
}

