#include "stdafx.h"
#include "BaboonMissile.h"
#include "Enermy.h"
#include "CollisionMgr.h"
#include "SpaceBaboon.h"
#include "Export_Function.h"

CBaboonMissile::CBaboonMissile(LPDIRECT3DDEVICE9 pGraphicDev)
	:CPlayer(pGraphicDev)
	, m_fSpeed(5.f), m_fChangeTime(0.f), m_fChaseTime(0.f)
	, m_bChange(false), m_fLifeTime(0.f)
	, m_bChaseMove(true), m_bDownMove(false), m_bAtt(false), m_fAngle(0.f), m_fTurnSpeed(D3DXToRadian(2.f)), m_bTarget(false)
	, m_bStartMissile(false), m_bPlayerAtt(false)
{
}

CBaboonMissile::~CBaboonMissile()
{
}

HRESULT CBaboonMissile::Ready_Object(void * pArg, CGameObject* pPlayer, _bool bTarget, _uint iIndex)
{
	m_tColInfo.fRadius = 1.f;
	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);


	if (nullptr != pPlayer)
	{
		m_pTarget = pPlayer;
		m_pTarget->AddRef();
	}

	m_bTarget = bTarget;
	m_iIndex = iIndex;

	return S_OK;
}

_int CBaboonMissile::Update_Object(const _float & fTimeDelta)
{
	if (m_bStart)
	{
		m_pTrigger = CTrigger::CreateSphereTirgger(m_pScene, this, m_pTransformCom->Get_Position(), 1.f, TRIGGER_SPACE_MISSILE_BOSS, FilterGroup::eDefaultTrigger);
		m_bStart = false;
	}

	_vec3 vPos;
	vPos = m_pTransformCom->Get_Position();
	m_pTrigger->Set_Pos(m_pTransformCom->Get_Position());

	if (m_bDead)
	{
		if (m_bTarget) // Ʈ���϶��� �ڵ�.
		{
			CSpaceBaboon*	pBaboon = (CSpaceBaboon*)Engine::Get_GameObject(L"GameObject", L"SpaceBoss");
			pBaboon->Set_TargetCody();
		}
		else if (!m_bTarget)
		{
			CSpaceBaboon*	pBaboon = (CSpaceBaboon*)Engine::Get_GameObject(L"GameObject", L"SpaceBoss");
			pBaboon->Set_TargetMay();
		}

		m_pTrigger->Set_Interactable(false);

		return OBJ_DEAD;
	}

	m_fLifeTime += fTimeDelta;
	if (m_fLifeTime > 20.f)
		m_bDead = true;

	Engine::CGameObject::Update_Object(fTimeDelta);
	Move(fTimeDelta);

	if (m_bChange)
	{
		m_pTrigger->Set_TriggerType(TRIGGER_SPACE_MISSILE_PLAYER);
		m_bChange = false;

	}

	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	return OBJ_NOEVENT;
}

_int CBaboonMissile::LateUpdate_Object(const _float & fTimeDelta)
{
	return _int();
}

void CBaboonMissile::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes(pEffect, 6);

	pEffect->End();

	Safe_Release(pEffect);

	m_tColInfo.matWorld = *m_pTransformCom->Get_WorldMatrix();
	m_pColliderCom->Render_Collider(m_tColInfo.matWorld, false);
}

HRESULT CBaboonMissile::Add_Component(void * pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO tTemp;
	ZeroMemory(&tTemp, sizeof(OBJINFO));

	if (nullptr != pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	// CStaticMesh
	pComponent = m_pMeshCom = static_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(RESOURCE_SB, L"BaboonMissile"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = static_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = static_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_tColInfo.fRadius, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);


	m_pTransformCom->Set_Scale(tTemp.vScale);
	m_pTransformCom->Rotation(ROT_X, tTemp.vAngle.x);
	m_pTransformCom->Rotation(ROT_Y, tTemp.vAngle.y);
	m_pTransformCom->Rotation(ROT_Z, tTemp.vAngle.z);
	m_pTransformCom->Set_Pos(tTemp.vPos);

	////PhysX
	//auto* pPhysics = Engine::Get_Physics();
	//_vec3 vPos = m_pTransformCom->Get_Position();
	//PxTransform tTransform(vPos.x, vPos.y, vPos.z);

	//PxMaterial* pMaterial = pPhysics->createMaterial(0.5f, 0.5f, 0.0f);

	//PxShape* pShape = pPhysics->createShape(PxBoxGeometry(1, 1, 1), *pMaterial, true);
	////�� �ΰ��� �ϳ��� false �Ѵ� true��?
	//pShape->setFlag(PxShapeFlag::eSIMULATION_SHAPE, true);
	//pShape->setFlag(PxShapeFlag::eTRIGGER_SHAPE, false);

	//pShape->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);
	//m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pShape, 1);

	//auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	//// �׷���Ƽ�� ����.
	//pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, false);

	//// ��������
	//pBody->setRigidDynamicLockFlags(PxRigidDynamicLockFlag::eLOCK_ANGULAR_X | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Y | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z);
	//pBody->setName((char*)this);
	//pShape->setName((char*)this);
	return S_OK;
}

HRESULT CBaboonMissile::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	return S_OK;
}

void CBaboonMissile::Move(const _float & fTimeDelta)
{
	Chase_Move(fTimeDelta); //�߰�
	Down_Move(fTimeDelta);
	Att_Move(fTimeDelta);
}

void CBaboonMissile::Chase_Move(const _float & fTimeDelta)
{
	if (!m_bChaseMove)
		return;

	m_fChaseTime += fTimeDelta;


	_vec3 vTargetPos; //Ÿ���� ����
	_vec3 vPos; //���� ����(�ڽ�)	��ġ
	_vec3 vLook; //���� ����(�ڽ�)	�����
	_vec3 vBack;
	_vec3 vRight; //���� ����(�ڽ�) ����Ʈ
	_vec3 vLeft; //���� ����(�ڽ�) ����Ʈ
	_vec3 vDown;
	_vec3 vDir;
	_vec3 vUp;
	_float fDir = 0.f;

	CTransform*			pTargetTrans = (CTransform*)m_pTarget->Get_Component(L"Com_Transform", ID_DYNAMIC);


	m_vTargetPos = pTargetTrans->Get_Position();
	vPos = m_pTransformCom->Get_Position();
	m_vTargetPos.y += 1.f;
	m_pTransformCom->Get_Info(INFO_LOOK, &vLook);
	m_pTransformCom->Get_Info(INFO_RIGHT, &vRight);
	m_pTransformCom->Get_Info(INFO_UP, &vUp);

	D3DXVec3Normalize(&vLook, &vLook);
	D3DXVec3Normalize(&vRight, &vRight);
	D3DXVec3Normalize(&vUp, &vUp);

	vDir = m_vTargetPos - vPos;
	D3DXVec3Normalize(&vDir, &vDir);

	_vec3 vAxis;

	D3DXVec3Cross(&vAxis, &vDir, &vLook);
	D3DXVec3Normalize(&vAxis, &vAxis);

	_matrix matWorld, matRot;
	D3DXMatrixRotationAxis(&matRot, &vAxis, -acosf(D3DXVec3Dot(&vLook, &vDir)));
	matWorld = *m_pTransformCom->Get_WorldMatrix();
	//D3DXMatrixScaling(&matWorld, 0.01f, 0.01f, 0.01f);
	m_pTransformCom->Set_WorldMatrix(matRot*matWorld);
	m_pTransformCom->Move_Pos(&vDir, 10.f, fTimeDelta);

	if (m_fChaseTime >= 7.f)
	{
		m_bChaseMove = false;
		m_bDownMove = true;
		m_pTransformCom->Set_Angle(_vec3(0.f, atan2f(vDir.x, vDir.z), 0.f));
	}

}


void CBaboonMissile::Down_Move(const _float & fTimeDelta)
{
	if (!m_bDownMove)
		return;

	_vec3 vPos;
	vPos = m_pTransformCom->Get_Position();

	m_pTransformCom->Move_Pos(&_vec3(0.f, -1.f, 0.f), m_fSpeed, fTimeDelta);

	if (vPos.y <= 50.f)
	{
		m_pTransformCom->Set_Pos(vPos.x, 50.f, vPos.z);
		m_bDownMove = false;
		m_bAtt = true;
		m_bPlayerAtt = true;
		m_bChange = true;
	}
}

void CBaboonMissile::Att_Move(const _float & fTimeDelta)
{
	if (!m_bAtt)
		return;

	

	//�̶����� �÷��̾ Ż �� ����.
	if (m_bAtt)//�÷��̾� Ÿ�°� ture�� �����̰� ��. �÷��̾�� bool�� �ϳ� ���� �Ѱܾ���. �׽�Ʈ�����γ־�а���.
	{
		_vec3 vLook;
		_vec3 vUp = { 0.f, 1.f, 0.f };
		_vec3 vDown = { 0.f, -1.f, 0.f };
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook);
		D3DXVec3Normalize(&vLook, &vLook);

		_float fAngle;

		if (!m_bStartMissile) //ó�� ����.
		{
			_vec3 vDir = vLook + vUp;
			
			m_pTransformCom->Move_Pos(&vDir, 10.f, fTimeDelta);
			m_bStartMissile = true;

		}
		else if (m_bStartMissile)
		{
			_matrix matRot, matWorld;
			matWorld = *m_pTransformCom->Get_WorldMatrix();

			if (m_bTarget)
			{

				if (Key_Pressing(DIK_A))
				{

					m_pTransformCom->Set_AddAngleY(D3DXToRadian(5.f));
				}

				if (Key_Pressing(DIK_D))
				{

					m_pTransformCom->Set_AddAngleY(D3DXToRadian(-5.f));

				}

				if (Key_Pressing(DIK_W))
				{
					fAngle = D3DXToDegree(acosf(D3DXVec3Dot(&vDown, &vLook)));
					if (fAngle > 3.f)
						m_pTransformCom->Set_AddAngleX(D3DXToRadian(5.f));
				}




				if (Key_Pressing(DIK_S))
				{
					fAngle = D3DXToDegree(acosf(D3DXVec3Dot(&vUp, &vLook)));
					if (fAngle > 3.f)
						m_pTransformCom->Set_AddAngleX(D3DXToRadian(-5.f));
				}

			}
			else if (!m_bTarget)
			{
				_float fDIC_Y = 0;
				_float fCheck = 0.0f;
				fDIC_Y = Engine::Get_DIPadMove(PADMOVESTATE::DIC_LS_Y);
				if (fabsf(fDIC_Y) <= 0.2f) {}
				else
				{
					if (fDIC_Y > 0)
					{
						fAngle = D3DXToDegree(acosf(D3DXVec3Dot(&vDown, &vLook)));
						if (fAngle > 3.f)
							m_pTransformCom->Set_AddAngleX(D3DXToRadian(5.f));
					}
					else if (fDIC_Y < 0)
					{
						fAngle = D3DXToDegree(acosf(D3DXVec3Dot(&vUp, &vLook)));
						if (fAngle > 3.f)
							m_pTransformCom->Set_AddAngleX(D3DXToRadian(-5.f));
					}

				}

				_float fDIC_X = 0;
				fDIC_X = Engine::Get_DIPadMove(PADMOVESTATE::DIC_LS_X);
				if (fabs(fDIC_X) <= 0.2f) {}
				else
				{
					if (fDIC_X > 0)
						m_pTransformCom->Set_AddAngleY(D3DXToRadian(-5.f));
					else if (fDIC_X < 0)
						m_pTransformCom->Set_AddAngleY(D3DXToRadian(5.f));
				}
			}

			m_pTransformCom->Move_Pos(&vLook, 10.f, fTimeDelta);
		}
	}
}

CBaboonMissile * CBaboonMissile::Create(LPDIRECT3DDEVICE9 pGraphicDev, void * pArg, CGameObject* pPlayer, _bool bTarget, _uint iIndex)
{
	
	CBaboonMissile*	pInstance = new CBaboonMissile(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg, pPlayer, bTarget)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void CBaboonMissile::Free(void)
{
	m_pTarget->Release();
	CPlayer::Free();
}
