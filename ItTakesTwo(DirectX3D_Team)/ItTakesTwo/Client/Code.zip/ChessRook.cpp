#include "stdafx.h"
#include "ChessRook.h"
#include "ChessTile.h"
#include "RookMoveBullet.h"
#include "Export_Function.h"
#include "CollisionMgr.h"
#include "MainCamera.h"


CChessRook::CChessRook(LPDIRECT3DDEVICE9 pGraphicDev)
	: CEnermy(pGraphicDev)
{
}

CChessRook::~CChessRook()
{
}

HRESULT CChessRook::Ready_Object(_uint iTileIndex)
{
	m_iHP = 15;
	m_fColDis = 1.5f;

	// �ݶ��̴�
	ZeroMemory(&m_tColInfo, sizeof(SPHERE_INFO));
	m_tColInfo.fRadius = m_fColDis;

	FAILED_CHECK_RETURN(Add_Component(), E_FAIL);

	CHESSTILE tTemp;
	ZeroMemory(&tTemp, sizeof(tTemp));
	tTemp = CChessTile::GetInstance()->Get_TileIndex(iTileIndex);


	m_pTransformCom->Set_Scale(_vec3(0.01f, 0.01f, 0.01f));
	m_pTransformCom->Set_Pos(tTemp.vPos);

	m_pMeshCom->Set_Animationset((animID::Enemy_PlayRoom_ChessRook_Summon));
	m_iAniNum = m_pMeshCom->Get_AniIndex();

	PhysicsCreate();

	if (!m_bSound[Ready1])
	{
		Engine::StopSound(CSoundMgr::CHANNELID::ChessRook);
		Engine::PlaySoundW(L"ChessRook_Ready1.wav", CSoundMgr::CHANNELID::ChessRook, 0.3f);
		m_bSound[Ready1] = true;
	}
	return S_OK;
}

_int CChessRook::Update_Object(const _float & fTimeDelta)
{
	if (m_bDead)
	{
		Dead_Effect2(true);
		m_pRigidActor->setActorFlag(PxActorFlag::eDISABLE_SIMULATION, true);
		return OBJ_DEAD;
	}

	if (m_iHP <= 0)
	{
		Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);
		Dead_State(fTimeDelta);

		return OBJ_NOEVENT;
	}



	Engine::CGameObject::Update_Object(fTimeDelta);

	Move(fTimeDelta);

	m_pMeshCom->Play_Animationset(fTimeDelta);

	Tick_Damage(fTimeDelta);
	CCollisionMgr::GetInstance()->Add_EnermyList(this);
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	return OBJ_NOEVENT;
}

_int CChessRook::LateUpdate_Object(const _float & fTimeDelta)
{
	_vec3 vPos = m_pTransformCom->Get_Position();

	PxTransform pxTransform = m_pRigidActor->getGlobalPose();
	pxTransform.p.x = vPos.x;
	pxTransform.p.y = vPos.y + 1.0f;
	pxTransform.p.z = vPos.z;
	m_pRigidActor->setGlobalPose(pxTransform);


	return _int();
}

void CChessRook::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes_VTF(pEffect, 0);

	pEffect->End();

	Safe_Release(pEffect);

	CMainCamera* pCamera = (CMainCamera*)Engine::Get_GameObject(L"GameObject", L"MainCamera");
	pCamera->Update_View_Proj();

	const D3DXFRAME_DERIVED* pBone = m_pMeshCom->Get_FrameByName("Spine2");
	_float4x4 matBoneMatrix = pBone->CombinedTranformationMatrix;

	//Spine2
	m_tColInfo.matWorld = matBoneMatrix * *m_pTransformCom->Get_WorldMatrix();
	m_pColliderCom->Render_Collider(m_tColInfo.matWorld, false);
}

HRESULT CChessRook::Add_Component()
{
	Engine::CComponent*		pComponent = nullptr;

	// CDynamicMesh
	pComponent = m_pMeshCom = dynamic_cast<Engine::CDynamicMesh*>(Engine::Clone_Resource(RESOURCE_CB, L"Chess_Rook"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = dynamic_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_fColDis, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = dynamic_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_VTF"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	//PhysX
	auto* pPhysics = Engine::Get_Physics();
	_vec3 vPos = m_pTransformCom->Get_Position();
	PxTransform tTransform(vPos.x, vPos.y, vPos.z);

	PxMaterial* pMaterial = pPhysics->createMaterial(0.5f, 0.5f, 0.0f);

	PxShape* pShape = pPhysics->createShape(PxBoxGeometry(1, 1, 1), *pMaterial, true);
	//�� �ΰ��� �ϳ��� false �Ѵ� true��?
	pShape->setFlag(PxShapeFlag::eSIMULATION_SHAPE, true);
	pShape->setFlag(PxShapeFlag::eTRIGGER_SHAPE, false);

	pShape->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);
	m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pShape, 1);

	auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	// �׷���Ƽ�� ����.
	pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, false);

	// ��������
	pBody->setRigidDynamicLockFlags(PxRigidDynamicLockFlag::eLOCK_ANGULAR_X | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Y | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z);
	pBody->setName((char*)this);
	pShape->setName((char*)this);

	return S_OK;
}

HRESULT CChessRook::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	pEffect->SetVector("g_vColor", &_vec4(255.f, 255.f, 255.f, 255.f));
	pEffect->CommitChanges();

	return S_OK;
}

void CChessRook::Move(const _float & fTimeDelta)
{
	m_iAniNum = m_pMeshCom->Get_AniIndex();


	m_fAttackTime += fTimeDelta;
	//�ʿ������𸣰���.
	Engine::CTransform*		pMayTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Get_Component(L"GameObject", L"May", L"Com_Transform", Engine::ID_DYNAMIC));
	Engine::CTransform*		pCodyTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Get_Component(L"GameObject", L"Cody", L"Com_Transform", Engine::ID_DYNAMIC));

	_vec3 vMayPos; //���� ��ġ
	_vec3 vCodyPos; //�ڵ� ��ġ
	_vec3 vPos; //���� ����(�ڽ�)	��ġ.
	_vec3 vLook; //���� ����(�ڽ�)	�����
	_vec3 vRight; //���� ����(�ڽ�) ����Ʈ
	_vec3 vLeft; //���� ����(�ڽ�) ����Ʈ

	m_pTransformCom->Get_Info(INFO_LOOK, &vLook);
	m_pTransformCom->Get_Info(INFO_RIGHT, &vRight);

	vMayPos = pMayTransformCom->Get_Position();
	vCodyPos = pCodyTransformCom->Get_Position();
	vPos = m_pTransformCom->Get_Position();

	_vec3 vMayDir;	//���̿��� �Ÿ�
	_vec3 vCodyDir; //�ڵ���� �Ÿ�

	_float fMayDir;
	_float fCodyDir;

	vMayDir = vMayPos - vPos;
	vCodyDir = vCodyPos - vPos;

	fMayDir = D3DXVec3Length(&vMayDir);
	fCodyDir = D3DXVec3Length(&vCodyDir);


	D3DXVec3Normalize(&vLook, &vLook);
	D3DXVec3Normalize(&vRight, &vRight);
	vLeft = vRight * -1.f;

	//28, 23, 24, 27

	if (m_iAniNum == animID::Enemy_PlayRoom_ChessRook_Summon && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{

		m_pMeshCom->Set_Animationset(animID::Enemy_PlayRoom_ChessRook_Slam_Anticipation_mh);
	}
	else if (m_iAniNum == animID::Enemy_PlayRoom_ChessRook_Summon && m_pMeshCom->Is_AnimationSetEnd(0.3f))
	{
		if (!m_bSound[Ready0])
		{
			Engine::StopSound(CSoundMgr::CHANNELID::ChessRook);
			Engine::PlaySoundW(L"ChessRook_Ready0.wav", CSoundMgr::CHANNELID::ChessRook, 0.3f);
			m_bSound[Ready0] = true;
		}
	}

	if (m_iAniNum == animID::Enemy_PlayRoom_ChessRook_Slam_Anticipation_mh && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		if (!m_bSound[Attack])
		{
			Engine::StopSound(CSoundMgr::CHANNELID::ChessRook);
			Engine::PlaySoundW(L"ChessRook_Attack0.wav", CSoundMgr::CHANNELID::ChessRook, 0.3f);
			m_bSound[Attack] = true;
		}
		m_pMeshCom->Set_Animationset(animID::Enemy_PlayRoom_ChessRook_Slam_Anticipation_mh_Max);
	}

	if (m_iAniNum == animID::Enemy_PlayRoom_ChessRook_Slam_Anticipation_mh_Max && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::Enemy_PlayRoom_ChessRook_Slam_Attack_Start);

		CLayer*				pLayer = nullptr;
		pLayer = Engine::Get_Layer(L"GameObject");
		Engine::CGameObject*		pGameObject = nullptr;

		_vec3 vLook1;
		_vec3 vPos1;
		_matrix matRotY;
		D3DXMatrixRotationY(&matRotY, D3DXToRadian(90));
		vPos1 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook1);
		D3DXVec3Normalize(&vLook1, &vLook1);
		D3DXVec3TransformNormal(&vLook1, &vLook1, &matRotY);
		pGameObject = CRookMoveBullet::Create(m_pGraphicDev, vPos1, vLook1, 1);
		NULL_CHECK_RETURN(pGameObject, );
		FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Rook_MoveBullet1", pGameObject), );

		D3DXMatrixRotationY(&matRotY, D3DXToRadian(180));
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook1);
		D3DXVec3TransformNormal(&vLook1, &vLook1, &matRotY);
		pGameObject = CRookMoveBullet::Create(m_pGraphicDev, vPos1, vLook1, 2);
		NULL_CHECK_RETURN(pGameObject, );
		FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Rook_MoveBullet2", pGameObject), );



		D3DXMatrixRotationY(&matRotY, D3DXToRadian(270));
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook1);
		D3DXVec3TransformNormal(&vLook1, &vLook1, &matRotY);
		pGameObject = CRookMoveBullet::Create(m_pGraphicDev, vPos1, vLook1, 3);
		NULL_CHECK_RETURN(pGameObject, );
		FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Rook_MoveBullet3", pGameObject), );


		D3DXMatrixRotationY(&matRotY, D3DXToRadian(360));
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook1);
		D3DXVec3TransformNormal(&vLook1, &vLook1, &matRotY);

		pGameObject = CRookMoveBullet::Create(m_pGraphicDev, vPos1, vLook1, 4);
		NULL_CHECK_RETURN(pGameObject, );
		FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Rook_MoveBullet4", pGameObject), );
	}
	
	if (m_iAniNum == animID::Enemy_PlayRoom_ChessRook_Slam_Attack_Start && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_bDead = true;
	}
}

void CChessRook::Set_Damage(_int iDamage)
{
	CEnermy::Set_Damage(iDamage);

	Hit_Effect(m_pTransformCom->Get_Position() + _vec3(0.f, 2.f, 0.f), 5.f);
}

void CChessRook::Dead_State(const _float & fTimeDelta)
{
	m_bDead = true;
}

void CChessRook::PhysicsCreate()
{
	//PhysX
	auto* pPhysics = Engine::Get_Physics();
	_vec3 vPos = m_pTransformCom->Get_Position();
	PxTransform tTransform(vPos.x, vPos.y, vPos.z);

	PxMaterial* pMaterial = pPhysics->createMaterial(0.5f, 0.5f, 0.0f);

	PxShape* pShape = pPhysics->createShape(PxBoxGeometry(1, 1, 1), *pMaterial, true);
	//�� �ΰ��� �ϳ��� false �Ѵ� true��?
	pShape->setFlag(PxShapeFlag::eSIMULATION_SHAPE, false);
	pShape->setFlag(PxShapeFlag::eTRIGGER_SHAPE, false);

	pShape->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);
	m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pShape, 1);

	auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	// �׷���Ƽ�� ����.
	pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, false);

	// ��������
	pBody->setRigidDynamicLockFlags(PxRigidDynamicLockFlag::eLOCK_ANGULAR_X | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Y | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z);
	pBody->setName((char*)this);
	pShape->setName((char*)this);
}

CChessRook * CChessRook::Create(LPDIRECT3DDEVICE9 pGraphicDev, _uint iTileIndex)
{
	CChessRook*	pInstance = new CChessRook(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(iTileIndex)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void CChessRook::Free(void)
{
	CEnermy::Free();
}
