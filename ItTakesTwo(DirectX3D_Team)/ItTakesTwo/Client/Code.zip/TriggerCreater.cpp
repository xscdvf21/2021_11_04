#include "stdafx.h"
#include "TriggerCreater.h"


CTriggerCreater::CTriggerCreater()
{
}


CTriggerCreater::~CTriggerCreater()
{
}
