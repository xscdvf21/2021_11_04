#include "stdafx.h"
#include "GeneratorLever.h"
#include "Export_Function.h"
#include "BoundingBox.h"


CGeneratorLever::CGeneratorLever(LPDIRECT3DDEVICE9 pGraphicDev)
	: CGameObject(pGraphicDev)
{
}

CGeneratorLever::~CGeneratorLever()
{
}

HRESULT CGeneratorLever::Ready_Object(void * pArg, _vec3 TriggerPos, _vec3 vStartPos)
{
	OBJINFO tTemp;
	ZeroMemory(&tTemp, sizeof(OBJINFO));

	if (nullptr != pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}
	m_vTriggerScale = tTemp.vTriggerScale;
	m_vPushStartPos = vStartPos;
	m_vTriggerPos = TriggerPos;

	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);


	return S_OK;
}

_int CGeneratorLever::Update_Object(const _float & fTimeDelta)
{
	if (m_bStart)
	{
		m_pTrigger = CTrigger::CreateBoxTrigger(m_pScene, this, m_vTriggerPos, m_vTriggerScale.x, m_vTriggerScale.y, m_vTriggerScale.z, TRIGGERTYPE::TRIGGER_SPACE_GENERATOR_LEVER);
		m_bStart = false;
	}

	Move(fTimeDelta);

	Engine::CGameObject::Update_Object(fTimeDelta);
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	return OBJ_NOEVENT;
}

_int CGeneratorLever::LateUpdate_Object(const _float & fTimeDelta)
{
	return _int();
}

void CGeneratorLever::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);			//	1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
	m_pMeshCom->Render_Meshes(pEffect, 8);	//	pEffect->BeginPass(0);
											//	����ƽ�Ž�8
											//	���̳���6
	pEffect->End();

	m_pBox->Render_Collider(g_bRenderBox, pEffect);

	Safe_Release(pEffect);
}

void CGeneratorLever::Move(const _float & fTimeDelta)
{
	if (!m_bMove)
		return;


	if (m_fAngle >= 0.f)
	{
		m_pTransformCom->Rotation(ROT_Y, -D3DXToRadian(5.f));
		m_fAngle -= D3DXToRadian(5.f);
	}
	else
	{
		m_bMove = false;
		m_bMoveEnd = true;
	}

}

void CGeneratorLever::MoveRetrun(const _float & fTimeDelta)
{
	//if (!m_bMoveReturn)
	//	return;

	//if (m_fAngle >= 0.f)
	//{
	//	m_pTransformCom->Rotation(ROT_Y, -D3DXToRadian(2.f));
	//	m_fAngle -= D3DXToRadian(2.f);
	//}
	//else if(m_fAngle <= 20.f)
	//{
	//	
	//}


}

HRESULT CGeneratorLever::Add_Component(void * pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO tTemp;
	if (pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}



	pComponent = m_pMeshCom = static_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(tTemp.eSceneID, L"GeneratorLever"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = static_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	m_pTransformCom->Set_Scale(tTemp.vScale);
	m_pTransformCom->Rotation(ROT_X, D3DXToRadian(tTemp.vAngle.x));
	m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(tTemp.vAngle.y));
	m_pTransformCom->Rotation(ROT_Z, D3DXToRadian(tTemp.vAngle.z));
	m_pTransformCom->Set_Pos(tTemp.vPos);

	// Collider
	pComponent = m_pBox = CBoundingBox::Create(m_pGraphicDev, m_vTriggerScale * 2.0f, _vec4(0.0f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);
	m_pBox->Set_Pos(m_vTriggerPos);




	return S_OK;
}

HRESULT CGeneratorLever::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	return S_OK;
}

CGeneratorLever * CGeneratorLever::Create(LPDIRECT3DDEVICE9 pGraphicDev, void * pArg, _vec3 TriggerPos, _vec3 StartPos)
{
	CGeneratorLever*	pInstance = new CGeneratorLever(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg, TriggerPos, StartPos)))
	{
		Safe_Release(pInstance);
	}
	return pInstance;
}

void CGeneratorLever::Free(void)
{
	Engine::CGameObject::Free();
}
