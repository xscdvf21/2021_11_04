#include "stdafx.h"
#include "ChessPawn.h"
#include "ChessTile.h"
#include "PawnBullet.h"
#include "CollisionMgr.h"
#include "Export_Function.h"
#include "MainCamera.h"

CChessPawn::CChessPawn(LPDIRECT3DDEVICE9 pGraphicDev)
	: CEnermy(pGraphicDev)
	,m_iUnitName(0)
{
}

CChessPawn::~CChessPawn()
{
}

HRESULT CChessPawn::Ready_Object(_uint iTileIndex, _uint iUnitName)
{
	m_iHP = 15;
	m_fColDis = 1.5f;

	// �ݶ��̴�
	ZeroMemory(&m_tColInfo, sizeof(SPHERE_INFO));
	m_tColInfo.fRadius = m_fColDis;

	FAILED_CHECK_RETURN(Add_Component(), E_FAIL);

	m_iUnitName = iUnitName;
	CHESSTILE tTemp;
	ZeroMemory(&tTemp, sizeof(tTemp));
	tTemp = CChessTile::GetInstance()->Get_TileIndex(iTileIndex);

	m_pTransformCom->Set_Scale(_vec3(0.01f, 0.01f, 0.01f));
	m_pTransformCom->Set_Pos(tTemp.vPos);

	m_pMeshCom->Set_Animationset((animID::Enemy_PlayRoom_ChessPawn_Summon));
	m_iAniNum = m_pMeshCom->Get_AniIndex();

	PhysicsCreate();

	if (!m_bSound[Ready1])
	{
		Engine::StopSound(CSoundMgr::CHANNELID::ChessPawn);
		Engine::PlaySoundW(L"ChessPawn_Ready1.wav", CSoundMgr::CHANNELID::ChessPawn, 0.3f);
		m_bSound[Ready1] = true;
	}

	return S_OK;
}

_int CChessPawn::Update_Object(const _float & fTimeDelta)
{
	if (m_bDead)
	{
		Dead_Effect2(false);
		m_pRigidActor->setActorFlag(PxActorFlag::eDISABLE_SIMULATION, true);
		return OBJ_DEAD;
	}
	if (m_iHP <= 0)
	{
		Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);
		Dead_State(fTimeDelta);

		return OBJ_NOEVENT;
	}


	Engine::CGameObject::Update_Object(fTimeDelta);

	Move(fTimeDelta);

	m_pMeshCom->Play_Animationset(fTimeDelta);

	Tick_Damage(fTimeDelta);
	CCollisionMgr::GetInstance()->Add_EnermyList(this);
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);
	return OBJ_NOEVENT;
}

_int CChessPawn::LateUpdate_Object(const _float & fTimeDelta)
{
	_vec3 vPos = m_pTransformCom->Get_Position();

	PxTransform pxTransform = m_pRigidActor->getGlobalPose();
	pxTransform.p.x = vPos.x;
	pxTransform.p.y = vPos.y + 1.0f;
	pxTransform.p.z = vPos.z;
	m_pRigidActor->setGlobalPose(pxTransform);


	return _int();
}

void CChessPawn::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes_VTF(pEffect, 0);

	pEffect->End();

	Safe_Release(pEffect);

	CMainCamera* pCamera = (CMainCamera*)Engine::Get_GameObject(L"GameObject", L"MainCamera");
	pCamera->Update_View_Proj();

	const D3DXFRAME_DERIVED* pBone = m_pMeshCom->Get_FrameByName("Spine2");
	_float4x4 matBoneMatrix = pBone->CombinedTranformationMatrix;

	//Spine2
	m_tColInfo.matWorld = matBoneMatrix * *m_pTransformCom->Get_WorldMatrix();
	m_pColliderCom->Render_Collider(m_tColInfo.matWorld, false);
}

HRESULT CChessPawn::Add_Component()
{
	Engine::CComponent*		pComponent = nullptr;

	// CDynamicMesh
	pComponent = m_pMeshCom = dynamic_cast<Engine::CDynamicMesh*>(Engine::Clone_Resource(RESOURCE_CB, L"Chess_Pawn"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = dynamic_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_fColDis, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = dynamic_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_VTF"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	return S_OK;
}

HRESULT CChessPawn::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	pEffect->SetVector("g_vColor", &_vec4(255.f, 255.f, 255.f, 255.f));
	pEffect->CommitChanges();

	return S_OK;
}

void CChessPawn::Move(const _float & fTimeDelta)
{
	m_iAniNum = m_pMeshCom->Get_AniIndex();


	m_fAttackTime += fTimeDelta;
	//�ʿ������𸣰���.
	Engine::CTransform*		pMayTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Get_Component(L"GameObject", L"May", L"Com_Transform", Engine::ID_DYNAMIC));
	Engine::CTransform*		pCodyTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Get_Component(L"GameObject", L"Cody", L"Com_Transform", Engine::ID_DYNAMIC));

	_vec3 vMayPos; //���� ��ġ
	_vec3 vCodyPos; //�ڵ� ��ġ
	_vec3 vPos; //���� ����(�ڽ�)	��ġ.
	_vec3 vLook; //���� ����(�ڽ�)	�����
	_vec3 vRight; //���� ����(�ڽ�) ����Ʈ
	_vec3 vLeft; //���� ����(�ڽ�) ����Ʈ

	m_pTransformCom->Get_Info(INFO_LOOK, &vLook);
	m_pTransformCom->Get_Info(INFO_RIGHT, &vRight);

	vMayPos = pMayTransformCom->Get_Position();
	vCodyPos = pCodyTransformCom->Get_Position();
	vPos = m_pTransformCom->Get_Position();

	_vec3 vMayDir;	//���̿��� �Ÿ�
	_vec3 vCodyDir; //�ڵ���� �Ÿ�

	_float fMayDir;
	_float fCodyDir;

	vMayDir = vMayPos - vPos;
	vCodyDir = vCodyPos - vPos;

	fMayDir = D3DXVec3Length(&vMayDir);
	fCodyDir = D3DXVec3Length(&vCodyDir);


	D3DXVec3Normalize(&vLook, &vLook);
	D3DXVec3Normalize(&vRight, &vRight);
	vLeft = vRight * -1.f;

	if (m_iAniNum == animID::Enemy_PlayRoom_ChessPawn_Summon && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::Enemy_PlayRoom_ChessBishop_Anticipation_mh_Max, 1.0F, 0.08F);
	}
	else if (m_iAniNum == animID::Enemy_PlayRoom_ChessPawn_Summon && m_pMeshCom->Is_AnimationSetEnd(1.f))
	{
		if (!m_bSound[Ready0])
		{
			Engine::StopSound(CSoundMgr::CHANNELID::ChessPawn);
			Engine::PlaySoundW(L"ChessPawn_Ready0.wav", CSoundMgr::CHANNELID::ChessPawn, 0.3f);
			m_bSound[Ready0] = true;
		}
	}

	//�ʹ� �ִϸ��̼��� ��ٽ����� ��� ���� �ϸ� ��������.
	if (m_iAniNum == animID::Enemy_PlayRoom_ChessBishop_Anticipation_mh_Max && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		if (!m_bSound[Attack])
		{
			Engine::StopSound(CSoundMgr::CHANNELID::ChessPawn);
			Engine::PlaySoundW(L"ChessPawn_Attack0.wav", CSoundMgr::CHANNELID::ChessPawn, 0.3f);
			m_bSound[Attack] = true;
		}

		m_pMeshCom->Set_Animationset(animID::Enemy_PlayRoom_ChessPawn_Anticipation_mh_Max);
		m_iAniNum = m_pMeshCom->Get_AniIndex();

	}

	if (m_iAniNum == animID::Enemy_PlayRoom_ChessPawn_Anticipation_mh_Max && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::Enemy_PlayRoom_ChessPawn_Attack_mh);
		m_iAniNum = m_pMeshCom->Get_AniIndex();
	}

	if (m_iAniNum == animID::Enemy_PlayRoom_ChessPawn_Attack_mh && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_pMeshCom->Set_Animationset(animID::Enemy_PlayRoom_ChessPawn_Attack_Start);
		m_iAniNum = m_pMeshCom->Get_AniIndex();
	}

	if (m_iAniNum == animID::Enemy_PlayRoom_ChessPawn_Attack_Start && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		m_bDead = true;

		CLayer*				pLayer = nullptr;
		pLayer = Engine::Get_Layer(L"GameObject");
		Engine::CGameObject*		pGameObject = nullptr;
		///////////////////////////����
		_vec3 vLook;
		_vec3 vPos;


		_tchar tagTemp[MAX_PATH];
		wsprintf(tagTemp, L"ChessPawn_Bullet %d", m_iUnitName);

		vPos = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook);
		D3DXVec3Normalize(&vLook, &vLook);
		vLook = vLook * 2.8f;
		vPos = vPos + vLook;
		D3DXVec3Normalize(&vLook, &vLook);


		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos);
		pLayer->Add_GameObject(tagTemp, pGameObject);
		/////////////////////////////45��


		wsprintf(tagTemp, L"ChessPawn_Bullet1 %d", m_iUnitName);
		_vec3 vLook1;
		_vec3 vPos1;
		_matrix matRotY;
		D3DXMatrixRotationY(&matRotY, D3DXToRadian(45));
		vPos1 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook1);
		D3DXVec3Normalize(&vLook1, &vLook1);
		D3DXVec3TransformNormal(&vLook1, &vLook1, &matRotY);

		vLook1 = vLook1 * 4.2f;
		vPos1 = vPos1 + vLook1;
		D3DXVec3Normalize(&vLook1, &vLook1);

		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos1);
		pLayer->Add_GameObject(tagTemp, pGameObject);
		///////////////////////////////-45��.

		wsprintf(tagTemp, L"ChessPawn_Bullet2 %d", m_iUnitName);
		_vec3 vLook2;
		_vec3 vPos2;
		_matrix matRotY2;
		D3DXMatrixRotationY(&matRotY2, D3DXToRadian(90));
		vPos2 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook2);
		D3DXVec3Normalize(&vLook2, &vLook2);
		D3DXVec3TransformNormal(&vLook2, &vLook2, &matRotY2);

		vLook2 = vLook2 * 2.8f;
		vPos2 = vPos2 + vLook2;
		D3DXVec3Normalize(&vLook2, &vLook2);

		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos2);
		pLayer->Add_GameObject(tagTemp, pGameObject);


		wsprintf(tagTemp, L"ChessPawn_Bullet3 %d", m_iUnitName);
		_vec3 vLook3;
		_vec3 vPos3;
		_matrix matRotY3;
		D3DXMatrixRotationY(&matRotY3, D3DXToRadian(135));
		vPos3 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook3);
		D3DXVec3Normalize(&vLook3, &vLook3);
		D3DXVec3TransformNormal(&vLook3, &vLook3, &matRotY3);

		vLook3 = vLook3 * 4.2f;
		vPos3 = vPos3 + vLook3;
		D3DXVec3Normalize(&vLook3, &vLook3);

		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos3);
		pLayer->Add_GameObject(tagTemp, pGameObject);

		wsprintf(tagTemp, L"ChessPawn_Bullet4 %d", m_iUnitName);
		_vec3 vLook4;
		_vec3 vPos4;
		_matrix matRotY4;
		D3DXMatrixRotationY(&matRotY4, D3DXToRadian(180));
		vPos4 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook4);
		D3DXVec3Normalize(&vLook4, &vLook4);
		D3DXVec3TransformNormal(&vLook4, &vLook4, &matRotY4);

		vLook4 = vLook4 * 2.8f;
		vPos4 = vPos4 + vLook4;
		D3DXVec3Normalize(&vLook4, &vLook4);

		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos4);

		pLayer->Add_GameObject(tagTemp, pGameObject);


		wsprintf(tagTemp, L"ChessPawn_Bullet5 %d", m_iUnitName);
		_vec3 vLook5;
		_vec3 vPos5;
		_matrix matRotY5;
		D3DXMatrixRotationY(&matRotY5, D3DXToRadian(225));
		vPos5 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook5);
		D3DXVec3Normalize(&vLook5, &vLook5);
		D3DXVec3TransformNormal(&vLook5, &vLook5, &matRotY5);

		vLook5 = vLook5 * 4.2f;
		vPos5 = vPos5 + vLook5;
		D3DXVec3Normalize(&vLook5, &vLook5);

		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos5);
		pLayer->Add_GameObject(tagTemp, pGameObject);

		wsprintf(tagTemp, L"ChessPawn_Bullet6 %d", m_iUnitName);
		_vec3 vLook6;
		_vec3 vPos6;
		_matrix matRotY6;
		D3DXMatrixRotationY(&matRotY6, D3DXToRadian(270));
		vPos6 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook6);
		D3DXVec3Normalize(&vLook6, &vLook6);
		D3DXVec3TransformNormal(&vLook6, &vLook6, &matRotY6);

		vLook6 = vLook6 * 2.8f;
		vPos6 = vPos6 + vLook6;
		D3DXVec3Normalize(&vLook6, &vLook6);

		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos6);
	
		pLayer->Add_GameObject(tagTemp, pGameObject);

		wsprintf(tagTemp, L"ChessPawn_Bullet7 %d", m_iUnitName);
		_vec3 vLook7;
		_vec3 vPos7;
		_matrix matRotY7;
		D3DXMatrixRotationY(&matRotY7, D3DXToRadian(315));
		vPos7 = m_pTransformCom->Get_Position();
		m_pTransformCom->Get_Info(INFO_LOOK, &vLook7);
		D3DXVec3Normalize(&vLook7, &vLook7);
		D3DXVec3TransformNormal(&vLook7, &vLook7, &matRotY7);

		vLook7 = vLook7 * 4.2f;
		vPos7 = vPos7 + vLook7;
		D3DXVec3Normalize(&vLook7, &vLook7);

		pGameObject = CPawnBullet::Create(m_pGraphicDev, vPos7);
	
		pLayer->Add_GameObject(tagTemp, pGameObject);
	}

	
}

void CChessPawn::Set_Damage(_int iDamage)
{
	CEnermy::Set_Damage(iDamage);

	Hit_Effect(m_pTransformCom->Get_Position() + _vec3(0.f, 1.f, 0.f), 5.f);
}

void CChessPawn::Dead_State(const _float & fTimeDelta)
{
	m_bDead = true;
}

void CChessPawn::PhysicsCreate()
{
	auto* pPhysics = Engine::Get_Physics();
	_vec3 vPos = m_pTransformCom->Get_Position();
	PxTransform tTransform(vPos.x, vPos.y, vPos.z);

	PxMaterial* pMaterial = pPhysics->createMaterial(0.5f, 0.5f, 0.0f);

	PxShape* pShape = pPhysics->createShape(PxBoxGeometry(1, 1, 1), *pMaterial, true);
	//�� �ΰ��� �ϳ��� false �Ѵ� true��?
	pShape->setFlag(PxShapeFlag::eSIMULATION_SHAPE, true);
	pShape->setFlag(PxShapeFlag::eTRIGGER_SHAPE, false);

	pShape->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);
	m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pShape, 1);

	auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	// �׷���Ƽ�� ����.
	pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, false);

	// ��������
	pBody->setRigidDynamicLockFlags(PxRigidDynamicLockFlag::eLOCK_ANGULAR_X | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Y | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z);
	pBody->setName((char*)this);
	pShape->setName((char*)this);
}

CChessPawn * CChessPawn::Create(LPDIRECT3DDEVICE9 pGraphicDev, _uint iTileIndex , _uint iUnitName)
{
	CChessPawn*	pInstance = new CChessPawn(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(iTileIndex, iUnitName)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void CChessPawn::Free(void)
{
	CEnermy::Free();
}
