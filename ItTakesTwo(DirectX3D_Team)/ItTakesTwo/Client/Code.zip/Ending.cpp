#include "stdafx.h"
#include "Ending.h"
#include "Export_Function.h"
#include "BubbleUI.h"
#include "FadeUI.h"


CEnding::CEnding(LPDIRECT3DDEVICE9 pDevice)
	: CScene(pDevice), m_bChange(false), m_bLock(false), m_bSelMenu(false), m_fLock(0.f), m_bLock2(false)
	, m_bSceneChange(false)
{
}

CEnding::~CEnding()
{
	Safe_Release(m_pEnding);
}

HRESULT CEnding::Ready_Scene()
{
	g_vBackBufferColor = _vec3(0.f, 0.f, 0.f);
	
	FAILED_CHECK_RETURN(Ready_GameObject_Layer(L"GameObject"), E_FAIL);

	Engine::PlayBGM(L"BG_JFF.ogg");


	return S_OK;
}

_int CEnding::Update_Scene(const _float & fTimeDelta)
{
	_int iExit = Engine::CScene::Update_Scene(fTimeDelta);

	_float fY = static_cast<CUI*>(m_pEnding)->Get_UIPos().y;

	if (fY <= -1150.f)
		return 0;

	static_cast<CUI*>(m_pEnding)->Set_UIAddPos(0.f, -fTimeDelta * 300.f);

	return iExit;
}

_int CEnding::LateUpdate_Scene(const _float & fTimeDelta)
{
	if (m_bSceneChange)
		return 0;

	_int iExit = Engine::CScene::LateUpdate_Scene(fTimeDelta);

	return iExit;
}

void CEnding::Render_Scene()
{
}

HRESULT CEnding::Ready_GameObject_Layer(const _tchar * pLayerTag)
{
	Engine::CLayer*			pLayer = Engine::CLayer::Create();
	NULL_CHECK_RETURN(pLayer, E_FAIL);

	// ������Ʈ �߰�
	Engine::CGameObject*		pGameObject = nullptr;

	// dynamicCamera
	pGameObject = CMainCamera::Create(m_pGraphicDev, &_vec3(0.f, 10.f, -5.f), &_vec3(0.f, 0.f, 1.f), &_vec3(0.f, 1.f, 0.f), D3DXToRadian(60.f), _float(WINCX) / WINCY, 0.1f, 1000.f);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"MainCamera", pGameObject), E_FAIL);

	GUI ui;
	ui.PosXY = { 640.f, 2500.f };
	ui.SizeXY = { 186.f, 3053.f };
	ui.iRender = 5;
	lstrcpy(ui.tagTexture, L"EndingText");

	pGameObject = CUI::Create(m_pGraphicDev, &ui);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"EndingText", pGameObject), E_FAIL);
	m_pEnding = pGameObject;
	m_pEnding->AddRef();

	ui.PosXY = { 640.f, 360.f };
	ui.SizeXY = { 1280.f, 720.f };
	ui.iRender = 3;
	lstrcpy(ui.tagTexture, L"LoadBG");

	// LoadingBg
	pGameObject = CUI::Create(m_pGraphicDev, &ui);
	NULL_CHECK_RETURN(pGameObject, E_FAIL);
	FAILED_CHECK_RETURN(pLayer->Add_GameObject(L"Load", pGameObject), E_FAIL);

	m_mapLayer.emplace(pLayerTag, pLayer);

	return S_OK;
}

CEnding * CEnding::Create(LPDIRECT3DDEVICE9 pGraphicDev)
{
	CEnding*		pInstance = new CEnding(pGraphicDev);

	if (FAILED(pInstance->Ready_Scene()))
		Safe_Release(pInstance);

	return pInstance;
}

void CEnding::Free(void)
{
	Engine::CScene::Free();
}