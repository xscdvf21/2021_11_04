#include "stdafx.h"
#include "CameraSpace.h"
#include "Export_Function.h"
#include "MainCamera.h"
#include "..\Engine\Resources\Code\PhysXMesh.h"
#include "Logo.h"
#include "BoundingBox.h"
#include "TestMove.h"


CCameraSpace::CCameraSpace(LPDIRECT3DDEVICE9 pGraphicDev)
	: Engine::CGameObject(pGraphicDev)
{

}

CCameraSpace::~CCameraSpace(void)
{
}

_bool CCameraSpace::Fade_Out(const _float& fTimeDelta)
{
	return false;
}

HRESULT CCameraSpace::Ready_Object(void* pArg)
{
#ifdef _DEBUG
	//CTestMove::GetInstance()->Set(L"Camera", true);
#endif // _DEBUG

	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);

	OBJINFO Temp;
	if (pArg)
	{
		memcpy(&Temp, pArg, sizeof(OBJINFO));
	}
	m_tObjInfo = Temp;
	return S_OK;
}

Engine::_int CCameraSpace::Update_Object(const _float& fTimeDelta)
{
#ifdef _DEBUG
	//CTestMove::GetInstance()->MoveTrigger(m_pBox, fTimeDelta, L"Camera");
#endif // _DEBUG

	if (m_bDead)
		return OBJ_DEAD;
	if (m_bStart)
	{
		m_pTrigger = CTrigger::CreateBoxTrigger(m_pScene, this, m_vPos, m_vScale.x, m_vScale.y, m_vScale.z, TRIGGER_CAMERA_CHANGE);
		m_bStart = false;
	}
	
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);
	return OBJ_NOEVENT;
}

_int CCameraSpace::LateUpdate_Object(const _float & fTimeDelta)
{

	return _int();
}

void CCameraSpace::Render_Object(const _int& iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);

	_matrix			matWorld, matView, matProj;
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	m_pBox->Render_Collider(g_bRenderBox, pEffect);
}

void* CCameraSpace::On_Trigger_Active(void* pTrigger)
{
	return nullptr;
}

void CCameraSpace::Set_Fix(_vec3 vEye, _vec3 vAt)
{
	m_eCameraMode = CAMERA_FIX;
	m_vEye = vEye;
	m_vAt = vAt;
}

CCameraSpace* CCameraSpace::Create(LPDIRECT3DDEVICE9 pGraphicDev,  const _vec3& vPos, const _float& fX, const _float& fY, const _float& fZ, void* pArg)
{
	CCameraSpace*	pInstance = new CCameraSpace(pGraphicDev);

	pInstance->Set_Pos(vPos);
	pInstance->Set_Scale(fX, fY, fZ);

	if (FAILED(pInstance->Ready_Object(pArg)))
	{
		Safe_Release(pInstance);
		return nullptr;
	}

	return pInstance;
}

CCameraSpace* CCameraSpace::Create(LPDIRECT3DDEVICE9 pGraphicDev,  const _vec3& vPos, const _float& fHalf, void* pArg)
{
	CCameraSpace*	pInstance = new CCameraSpace(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg)))
	{
		Safe_Release(pInstance);
		return nullptr;
	}
	pInstance->Set_Pos(vPos);
	pInstance->Set_Scale(fHalf);
	return pInstance;
}

void CCameraSpace::Free(void)
{
	Engine::CGameObject::Free();
}

HRESULT CCameraSpace::Add_Component(void* pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO Temp;

	if (pArg)
	{
		memcpy(&Temp, pArg, sizeof(OBJINFO));
	}
	//Temp.eSceneID = RESOURCE_STATIC;
	//m_pUI = CImageUI::Create(m_pGraphicDev,&Temp,false);
	//NULL_CHECK_RETURN(m_pUI, E_FAIL);
	//m_pUI->Set_RenderID(RENDER_UI);
	//m_pUI->Set_Image(L"White_Bg");

	// Shader
	pComponent = m_pShaderCom = dynamic_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	// Collider
	pComponent = m_pBox = CBoundingBox::Create(m_pGraphicDev, m_vScale * 2.0f, _vec4(0.0f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);
	m_pBox->Set_Pos(m_vPos);
	return S_OK;
}