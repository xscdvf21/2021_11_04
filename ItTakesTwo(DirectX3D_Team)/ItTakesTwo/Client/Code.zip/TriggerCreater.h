#pragma once
#ifndef TriggerCreater_h__

#include "Base.h"
class CTriggerCreater :
	public CBase
{
public:
	explicit CTriggerCreater();
	virtual ~CTriggerCreater();

public:
	/*virtual void Free() override*/;
};

#define TriggerCreater_h__
#endif