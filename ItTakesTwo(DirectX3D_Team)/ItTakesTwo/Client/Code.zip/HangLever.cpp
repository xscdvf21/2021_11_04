#include "stdafx.h"
#include "HangLever.h"


CHangLever::CHangLever()
{
}


CHangLever::~CHangLever()
{
}
