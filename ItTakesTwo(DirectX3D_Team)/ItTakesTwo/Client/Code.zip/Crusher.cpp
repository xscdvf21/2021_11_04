#include "stdafx.h"
#include "Crusher.h"
#include "MainCamera.h"
#include "ChessDoorSwitch.h"
#include "CrusherBreakWall.h"
#include "Export_Function.h"
#include "CrusherBridge.h"

CCrusher::CCrusher(LPDIRECT3DDEVICE9 pGraphicDev)
	: CGameObject(pGraphicDev)
	, m_bMove(false)
	, m_bDeadAni(false)
	, m_iAniIndex(0)
	, m_bMoveStart(false)
	, m_bMoveReady(false)
	, m_iHitPointCount(0)
	, m_bDeadMove(false)
	, m_fCurTime(0.f)
{
}

CCrusher::~CCrusher()
{
}

HRESULT CCrusher::Ready_Object(void * pArg)
{
	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);

	OBJINFO tTemp;
	ZeroMemory(&tTemp, sizeof(OBJINFO));

	if (nullptr != pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}

	if (!m_bSound[BGM])
	{
		StopAll();
		PlayBGM(L"ChessOgre_BGM.wav");
		m_bSound[BGM] = true;
	}

	m_pMeshCom->Set_Animationset(animID::ToyCrusher_MH);
	return S_OK;
}

_int CCrusher::Update_Object(const _float & fTimeDelta)
{
	m_iAniIndex = m_pMeshCom->Get_AniIndex();
	if (m_bDead)
	{
		CCrusherBreakWall* pWall = (CCrusherBreakWall*)Engine::Get_GameObject(L"GameObject", L"CrusherBreakWall5");
		if (pWall)
			pWall->Set_Dead();

		pWall = (CCrusherBreakWall*)Engine::Get_GameObject(L"GameObject", L"CrusherBreakWall6");
		if (pWall)
			pWall->Set_Dead();

		StopAll();
		PlayBGM(L"ChessField_BGM.wav");


		return OBJ_DEAD;
	}
	if (m_iHitPointCount == 4)
	{
		Dead(fTimeDelta);
	}

	if (m_bMove && !m_bDeadAni)
	{
		Move(fTimeDelta);
	}


	m_pMeshCom->Play_Animationset(fTimeDelta);

	Engine::CGameObject::Update_Object(fTimeDelta);
	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);

	_vec3 vPos;

	vPos = m_pTransformCom->Get_Position();

	PxTransform pxTransform = m_pRigidActor->getGlobalPose();
	pxTransform.p.x = vPos.x;
	pxTransform.p.y = vPos.y;
	pxTransform.p.z = vPos.z;
	m_pRigidActor->setGlobalPose(pxTransform);

	return OBJ_NOEVENT;
}

_int CCrusher::LateUpdate_Object(const _float & fTimeDelta)
{
	PxTransform pxTransform = m_pRigidActor->getGlobalPose();
	m_pTransformCom->Set_Pos(pxTransform);

	return _int();
}

void CCrusher::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes_VTF(pEffect, 0);

	pEffect->End();

	Safe_Release(pEffect);
}

HRESULT CCrusher::Add_Component(void * pArg)
{
	Engine::CComponent*		pComponent = nullptr;

	OBJINFO tTemp;
	if (pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}


	pComponent = m_pMeshCom = static_cast<Engine::CDynamicMesh*>(Engine::Clone_Resource(tTemp.eSceneID, L"ToyCrusher"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);
	// Transform
	pComponent = m_pTransformCom = static_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = static_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_fColDis, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_VTF"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);


	m_pTransformCom->Set_Scale(tTemp.vScale);
	m_pTransformCom->Rotation(ROT_X, D3DXToRadian(tTemp.vAngle.x));
	m_pTransformCom->Rotation(ROT_Y, D3DXToRadian(tTemp.vAngle.y));
	m_pTransformCom->Rotation(ROT_Z, D3DXToRadian(tTemp.vAngle.z));
	m_pTransformCom->Set_Pos(tTemp.vPos);


	auto* pPhysics = Engine::Get_Physics();
	_vec3 vPos = m_pTransformCom->Get_Position();
	PxTransform tTransform(vPos.x, vPos.y, vPos.z);

	PxMaterial* pMaterial = pPhysics->createMaterial(0.5f, 0.5f, 0.0f);

	PxShape* pShape = pPhysics->createShape(PxBoxGeometry(0.5f, 0.5f, 0.5f), *pMaterial, true);
	//�� �ΰ��� �ϳ��� false �Ѵ� true��?
	pShape->setFlag(PxShapeFlag::eSIMULATION_SHAPE, true);
	pShape->setFlag(PxShapeFlag::eTRIGGER_SHAPE, false);
	pShape->setFlag(PxShapeFlag::eSCENE_QUERY_SHAPE, true);
	m_pRigidActor = PxCreateDynamic(*pPhysics, tTransform, *pShape, 1);

	auto* pBody = static_cast<PxRigidDynamic*>(m_pRigidActor);

	// Ʈ�������� ������������ �������� �ʴ¾ֵ�
	pBody->setRigidBodyFlag(PxRigidBodyFlag::eKINEMATIC, true);

	// �׷���Ƽ�� ����.

	pBody->setActorFlag(PxActorFlag::eDISABLE_GRAVITY, false);

	// ��������
	pBody->setMass(5);
	pBody->setName("Crusher");
	pBody->setRigidDynamicLockFlags(PxRigidDynamicLockFlag::eLOCK_ANGULAR_X | PxRigidDynamicLockFlag::eLOCK_ANGULAR_Z);
	//�̵� ������
	pBody->setLinearDamping(0.05f);


	return S_OK;
}

HRESULT CCrusher::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	pEffect->SetVector("g_vColor", &_vec4(255.f, 255.f, 255.f, 255.f));
	pEffect->SetFloat("g_fAmount", 0.f);
	pEffect->CommitChanges();

	return S_OK;
}

void CCrusher::Move(const _float & fTimeDelta)
{

	_vec3 vLook;
	
	if (!m_bMoveStart)
	{

		CCrusherBreakWall* pWall = (CCrusherBreakWall*)Engine::Get_GameObject(L"GameObject", L"CrusherBreakWall1");
		if(pWall)
			pWall->Set_Dead();

		pWall = (CCrusherBreakWall*)Engine::Get_GameObject(L"GameObject", L"CrusherBreakWall2");
		if (pWall)
			pWall->Set_Dead();

		m_pMeshCom->Set_Animationset(animID::PlayRoom_Castle_Dungeon_CrusherIntro_ToyCrusher);
	}
	if (m_iAniIndex == animID::PlayRoom_Castle_Dungeon_CrusherIntro_ToyCrusher && m_pMeshCom->Is_AnimationSetEnd(0.1f))
	{
		CCrusherBreakWall* pWall = (CCrusherBreakWall*)Engine::Get_GameObject(L"GameObject", L"CrusherBreakWall3");
		if (pWall)
			pWall->Set_Hit(true);

		pWall = (CCrusherBreakWall*)Engine::Get_GameObject(L"GameObject", L"CrusherBreakWall4");
		if (pWall)
			pWall->Set_Hit(true);

		m_bMoveStart = true;
	}
	if (m_bMoveStart)
	{

		m_pMeshCom->Set_Animationset(animID::ToyCrusher_Smash);

		m_pTransformCom->Get_Info(INFO_LOOK, &vLook);
		D3DXVec3Normalize(&vLook, &vLook);
		m_pTransformCom->Move_Pos(&vLook, 2.f, fTimeDelta);

		if (m_pMeshCom->Is_AnimationSetEnd(0.1f))
		{
			//CMainCamera*	pCamera = static_cast<CMainCamera*>(Engine::Get_GameObject(L"GameObject", L"MainCamera"));
			//pCamera->Set_Shake();
		}
	}
}

void CCrusher::Dead(const _float & fTimeDelta)
{

	if (!m_bDeadMove)
	{
		m_vMoveStartPos = m_pTransformCom->Get_Position();
		m_vMoveEndPos = { 68.f, 0.f, -141.8f };
		m_bDeadMove = true;
	}


	if(!m_bDeadAni)
		DeadMove(fTimeDelta, 2.f, m_vMoveStartPos, m_vMoveEndPos);
	else if (m_bDeadAni)
	{
		m_pMeshCom->Set_Animationset(animID::PlayRoom_Castle_Dungeon_BridgeCollapse_ToyCrusher);

		CCrusherBridge*		pBridge = (CCrusherBridge*)Engine::Get_GameObject(L"GameObject", L"CrusherBridge");
		pBridge->Set_Move();
		if (m_iAniIndex == animID::PlayRoom_Castle_Dungeon_BridgeCollapse_ToyCrusher&& m_pMeshCom->Is_AnimationSetEnd(0.1f))
		{
			m_bDead = true;
		}
	}
}

void CCrusher::DeadMove(const _float & fTimeDelta, const _float & fMoveTime, _vec3 vStartPos, _vec3 vEndPos)
{
	m_fMoveTime = fMoveTime;
	m_vStartPos = vStartPos;
	m_vEndPos = vEndPos;


	m_fCurTime += fTimeDelta;
	m_pTransformCom->Set_Pos
	(
		(((m_vStartPos.x + ((((m_vEndPos.x) - (m_vStartPos.x)) / m_fMoveTime)*m_fCurTime)))),
		(((m_vStartPos.y + ((((m_vEndPos.y) - (m_vStartPos.y)) / m_fMoveTime)*m_fCurTime)))),
		(((m_vStartPos.z + ((((m_vEndPos.z) - (m_vStartPos.z)) / m_fMoveTime)*m_fCurTime))))
	);


	if (m_fMoveTime < m_fCurTime)
	{
		m_fCurTime = 0.f;
		m_bDeadAni = true;
	}
}

CCrusher * CCrusher::Create(LPDIRECT3DDEVICE9 pGraphicDev, void * pArg)
{
	CCrusher*	pInstance = new CCrusher(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(pArg)))
	{
		Safe_Release(pInstance);
	}
	return pInstance;
}

void CCrusher::Free(void)
{
	Engine::CGameObject::Free();
}
