#include "stdafx.h"
#include "RookMoveBullet.h"
#include "ChessTile.h"
#include "RookStopBullet.h"
#include "Export_Function.h"


CRookMoveBullet::CRookMoveBullet(LPDIRECT3DDEVICE9 pGraphicDev)
	: Engine::CGameObject(pGraphicDev)
	, m_iBulletCount(0)
	, m_iBulletName(0)
{
}

CRookMoveBullet::~CRookMoveBullet()
{
}

HRESULT CRookMoveBullet::Ready_Object(_vec3 vPos, _vec3 vDir, _uint iCount)
{
	FAILED_CHECK_RETURN(Add_Component(), E_FAIL);

	m_vCurrentPos = vPos;

	m_pTransformCom->Set_Scale(_vec3(0.01f, 0.01f, 0.01f));
	m_pTransformCom->Set_Pos(vPos);

	m_iBulletName = iCount;
	m_vDir = vDir;
	D3DXVec3Normalize(&m_vDir, &m_vDir); //Ȥ�� ���� �ѹ�������, ���ʿ� ���ڷ� ������ �븻������ ���ֱ��Ұ�.


	return S_OK;
}

_int CRookMoveBullet::Update_Object(const _float & fTimeDelta)
{
	m_fLifeTime += fTimeDelta;

	_vec3	vPos;
	_vec3	vDir;
	_float	fDir;
	vPos = m_pTransformCom->Get_Position();

	vDir = vPos - m_vCurrentPos;
	fDir = D3DXVec3Length(&vDir);

	if (fDir >= 2.7f)
	{

		CHESSTILE	tTemp;
		ZeroMemory(&tTemp, sizeof(CHESSTILE));

		tTemp = CChessTile::GetInstance()->Get_Index(vPos);

		_tchar tagTemp[MAX_PATH];

		wsprintf(tagTemp, L"RookStopBullet %d %d", m_iBulletCount, m_iBulletName);

		CLayer*				pLayer = nullptr;
		pLayer = Engine::Get_Layer(L"GameObject");
		Engine::CGameObject*		pGameObject = nullptr;

		//pGameObject = CBiShopStopBullet::Create(m_pGraphicDev, tTemp.vPos);
		//pLayer->Add_GameObject(tagTemp, pGameObject);
		//m_iBulletCount++;

		//m_vCurrentPos = m_pTransformCom->Get_Position();


		pGameObject = CRookStopBullet::Create(m_pGraphicDev, vPos);
		pLayer->Add_GameObject(tagTemp, pGameObject);
		m_iBulletCount++;

		m_vCurrentPos = m_pTransformCom->Get_Position();
	}
	if (vPos.x <= -10.f || vPos.z <= -10.f || vPos.x > 10.f || vPos.z > 10.f)
	{
		m_bDead = true;
	}


	if (m_fLifeTime > 5.f) // ����� ������Ÿ��  2�ʷ� �����ص�. ���߿� �÷��̾ ���浹�ϸ� ���������ؾ��ҵ�
	{
		m_bDead = true;
	}

	if (m_bDead)
		return OBJ_DEAD;


	m_pTransformCom->Move_Pos(&m_vDir, 10.f, fTimeDelta);

	Engine::CGameObject::Update_Object(fTimeDelta);

	Engine::Add_RenderGroup(Engine::RENDER_NONALPHA, this);


	return OBJ_NOEVENT;
}

_int CRookMoveBullet::LateUpdate_Object(const _float & fTimeDelta)
{
	return _int();
}

void CRookMoveBullet::Render_Object(const _int & iIndex)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMeshCom->Render_Meshes(pEffect, 8);

	pEffect->End();

	Safe_Release(pEffect);
}

HRESULT CRookMoveBullet::Add_Component()
{
	Engine::CComponent*		pComponent = nullptr;

	// CStaticMesh
	pComponent = m_pMeshCom = dynamic_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(RESOURCE_PLAYER, L"IceOrb"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Mesh", pComponent);

	// Transform
	pComponent = m_pTransformCom = dynamic_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Calculator
	pComponent = m_pCalculatorCom = dynamic_cast<Engine::CCalculator*>(Engine::Clone_Prototype(L"Proto_Calculator"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Calculator", pComponent);

	// Collider
	pComponent = m_pColliderCom = Engine::CCollider::Create(m_pGraphicDev, m_fColDis, _vec4(50.f, 244.f, 234.f, 0.f));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Collider", pComponent);

	// Shader
	pComponent = m_pShaderCom = dynamic_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_All"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	return S_OK;
}

HRESULT CRookMoveBullet::SetUp_ConstantTable(LPD3DXEFFECT & pEffect, const _int & iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	return S_OK;
}

void CRookMoveBullet::Move(const _float & fTimeDelta)
{

}

CRookMoveBullet * CRookMoveBullet::Create(LPDIRECT3DDEVICE9 pGraphicDev, _vec3 vPos, _vec3 vDir, _uint iCount)
{
	CRookMoveBullet*	pInstance = new CRookMoveBullet(pGraphicDev);

	if (FAILED(pInstance->Ready_Object(vPos, vDir, iCount)))
	{
		Safe_Release(pInstance);
	}

	return pInstance;
}

void CRookMoveBullet::Free(void)
{
	Engine::CGameObject::Free();
}
