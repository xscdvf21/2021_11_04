#include "stdafx.h"
#include "Blow.h"

CBlow::CBlow(LPDIRECT3DDEVICE9 pDevice)
	:CGameObject(pDevice), m_fTimeDelta(0.f)
{

}

CBlow::~CBlow()
{
}

HRESULT CBlow::Ready_Object(void* pArg /*= nullptr*/)
{
	FAILED_CHECK_RETURN(Add_Component(pArg), E_FAIL);
	return S_OK;
}

Engine::_int CBlow::Update_Object(const _float& TimeDelta)
{
	m_fTimeDelta += TimeDelta;

	CGameObject::Update_Object(TimeDelta);
	return OBJ_NOEVENT;
}

Engine::_int CBlow::LateUpdate_Object(const _float & TimeDelta)
{
	CGameObject::LateUpdate_Object(TimeDelta);
	Engine::Add_RenderGroup(RENDER_ALPHA, this);

	m_fEffectTime += TimeDelta;


	


	return OBJ_NOEVENT;
}

void CBlow::Render_Object(const _int& iIndex /*= 0*/)
{
	LPD3DXEFFECT	pEffect = m_pShaderCom->Get_EffectHandle();
	NULL_CHECK(pEffect);
	pEffect->AddRef();

	FAILED_CHECK_RETURN(SetUp_ConstantTable(pEffect, iIndex), );

	_uint	iPassMax = 0;

	pEffect->Begin(&iPassMax, 0);		// 1���� : ���� ���̴� ������ ���� �ִ� pass�� �ִ� ����, 2���� : �����ϴ� ���(default)
										//pEffect->BeginPass(0);
	m_pMesh->Render_Meshes(pEffect, 2);

	pEffect->End();

	Safe_Release(pEffect);
}

CBlow* CBlow::Create(LPDIRECT3DDEVICE9 pDevice, void* pArg)
{
	CBlow* pInstance = new CBlow(pDevice);
	if (FAILED(pInstance->Ready_Object(pArg)))
	{
		Safe_Release(pInstance);
		return nullptr;
	}
	//	pInstance->Get_Transform()->Set_ParentMatrix(Parent);
	return pInstance;
}

void CBlow::Free()
{
	CGameObject::Free();
}

void CBlow::Set_Parent(const Engine::_mat& matParent)
{
	m_pTransformCom->Set_ParentMatrix(matParent);
}

HRESULT CBlow::Add_Component(void* pArg)
{
	OBJINFO tTemp;
	if (pArg)
	{
		memcpy(&tTemp, pArg, sizeof(OBJINFO));
	}
	// CDynamicMesh
	CComponent* pComponent = nullptr;
	pComponent = m_pMesh = static_cast<Engine::CStaticMesh*>(Engine::Clone_Resource(tTemp.eSceneID, L"VacuumBlow"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_MeshBlow", pComponent);

	// Transform
	pComponent = m_pTransformCom = static_cast<Engine::CTransform*>(Engine::Clone_Prototype(L"Proto_Transform"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_DYNAMIC].emplace(L"Com_Transform", pComponent);

	// Shader
	pComponent = m_pShaderCom = static_cast<Engine::CShader*>(Engine::Clone_Prototype(L"Shader_Effect"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Shader", pComponent);

	// Texture
	pComponent = m_pTextureCom = dynamic_cast<Engine::CTexture*>(Engine::Clone_Resource(RESOURCE_STATIC, L"Gradient"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Texture", pComponent);

	// Texture2
	pComponent = m_pTextureCom2 = dynamic_cast<Engine::CTexture*>(Engine::Clone_Resource(RESOURCE_STATIC, L"Particle"));
	NULL_CHECK_RETURN(pComponent, E_FAIL);
	m_mapComponent[Engine::ID_STATIC].emplace(L"Com_Texture2", pComponent);

	//m_pTransformCom->Set_Scale(0.01f);


	return S_OK;
}


HRESULT CBlow::SetUp_ConstantTable(LPD3DXEFFECT pEffect, const _int& iIndex)
{
	_matrix			matWorld, matView, matProj;

	m_pTransformCom->Get_WorldMatrix(&matWorld);
	m_pGraphicDev->GetTransform(D3DTS_VIEW, &matView);
	m_pGraphicDev->GetTransform(D3DTS_PROJECTION, &matProj);

	pEffect->SetMatrix("g_matWorld", &matWorld);
	pEffect->SetMatrix("g_matView", &matView);
	pEffect->SetMatrix("g_matProj", &matProj);

	if (m_bUp)
		pEffect->SetFloat("g_TimeDelta", m_fTimeDelta);
	else
		pEffect->SetFloat("g_TimeDelta", -m_fTimeDelta);

	m_pTextureCom->Set_Texture(pEffect, "g_Add1Texture", 7);
	m_pTextureCom2->Set_Texture(pEffect, "g_Add2Texture", 38);
	m_pTextureCom2->Set_Texture(pEffect, "g_Add3Texture", 15);
	return S_OK;
}


